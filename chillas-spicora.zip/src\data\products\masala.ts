import { Product } from "@/types";

export const MASALA_PRODUCTS: Product[] = [
  {
    id: "spicora-mas-garam",
    name: "Garam Masala",
    slug: "garam-masala",
    tagline: "Stone-Ground 16-Spice Royal Blend",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Heritage recipe featuring roasted whole cloves, green cardamom, black cardamom, cinnamon, and star anise ground cold to preserve aroma.",
    description: "CHILLA'S SPICORA Garam Masala is a balanced blend of 16 hand-selected spices slow-roasted over low fire to awaken their natural essential oils before being stone-ground. Unlike commercial powders stuffed with cheap fillers, every pinch provides intoxicating depth and warm finishing notes to curries, gravies, and biryanis.",
    images: [
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-garam-50g", size: "50 g", price: 65, compareAtPrice: 80, inStock: true, sku: "SPIC-MAS-GAR-50" },
      { id: "mas-garam-100g", size: "100 g", price: 119, compareAtPrice: 150, inStock: true, sku: "SPIC-MAS-GAR-100" },
      { id: "mas-garam-200g", size: "200 g", price: 219, compareAtPrice: 280, inStock: true, sku: "SPIC-MAS-GAR-200" },
      { id: "mas-garam-500g", size: "500 g", price: 499, compareAtPrice: 650, inStock: true, sku: "SPIC-MAS-GAR-500" }
    ],
    status: "Active",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["Sweet Clove", "Smoky Black Cardamom", "Nutty Coriander", "Balsamic Cinnamon"],
    ingredients: ["Coriander", "Cumin", "Black Pepper", "Green Cardamom", "Black Cardamom", "Clove", "Cinnamon", "Mace", "Nutmeg", "Bay Leaves", "Star Anise"],
    storageInstructions: "Store in an airtight container in a dark cabinet. Use within 6 months of unsealing.",
    complianceNotice: "Proposed formulation. Product under pilot batch laboratory evaluation.",
    rating: 4.9,
    reviewCount: 52,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["Paneer Butter Masala", "North Indian Curries", "Dal Makhani", "Dum Aloo"]
  },
  {
    id: "spicora-mas-chicken",
    name: "Chicken Masala",
    slug: "chicken-masala",
    tagline: "Hearty Andhra & South Indian Curry Perfection",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Robust roasted spice powder balanced with Guntur red chillies, fennel seeds, and roasted garlic notes for mouthwatering chicken curries.",
    description: "Crafted specifically to penetrate poultry meat during cooking, this masala delivers deep russet color, thick aromatic gravy, and the fiery yet comforting soul of authentic Southern chicken preparations.",
    images: [
      "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-chick-50g", size: "50 g", price: 59, compareAtPrice: 75, inStock: true, sku: "SPIC-MAS-CHK-50" },
      { id: "mas-chick-100g", size: "100 g", price: 109, compareAtPrice: 140, inStock: true, sku: "SPIC-MAS-CHK-100" },
      { id: "mas-chick-200g", size: "200 g", price: 199, compareAtPrice: 260, inStock: true, sku: "SPIC-MAS-CHK-200" },
      { id: "mas-chick-500g", size: "500 g", price: 449, compareAtPrice: 590, inStock: true, sku: "SPIC-MAS-CHK-500" }
    ],
    status: "Active",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["Roasted Fennel", "Pungent Guntur Chilli", "Earthy Turmeric", "Savory Cumin"],
    ingredients: ["Guntur Red Chilli", "Coriander", "Cumin", "Fennel", "Turmeric", "Black Pepper", "Dry Ginger", "Garlic Powder", "Curry Leaves"],
    storageInstructions: "Keep sealed tightly away from steam and moisture.",
    complianceNotice: "Proposed blend specifications. Certified validation prior to commercial sale.",
    rating: 4.8,
    reviewCount: 34,
    isFeatured: true,
    suggestedPairings: ["Country Chicken Curry", "Kodi Kura", "Chicken Salna", "Pepper Gravy"]
  },
  {
    id: "spicora-mas-mutton",
    name: "Mutton Masala",
    slug: "mutton-masala",
    tagline: "Rich, Deep Flavour for Slow-Braised Meat",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Intensely aromatic blend formulated with stone-ground stone flower (kalpasi), star anise, and black cardamom for tender, succulent mutton.",
    description: "Mutton requires bold, deep spices that can infuse dense meat fibers during slow braising. SPICORA Mutton Masala harmonizes the umami richness of dagad phool with cloves and black pepper to create an irresistible dark, thick, gelatinous gravy.",
    images: [
      "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-mutt-50g", size: "50 g", price: 69, compareAtPrice: 90, inStock: true, sku: "SPIC-MAS-MUT-50" },
      { id: "mas-mutt-100g", size: "100 g", price: 129, compareAtPrice: 165, inStock: true, sku: "SPIC-MAS-MUT-100" },
      { id: "mas-mutt-200g", size: "200 g", price: 239, compareAtPrice: 310, inStock: true, sku: "SPIC-MAS-MUT-200" },
      { id: "mas-mutt-500g", size: "500 g", price: 549, compareAtPrice: 700, inStock: true, sku: "SPIC-MAS-MUT-500" }
    ],
    status: "Active",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["Stone Flower (Kalpasi)", "Smoky Peppery Heat", "Nutmeg Warmth"],
    ingredients: ["Coriander", "Cumin", "Chilli", "Black Pepper", "Kalpasi", "Star Anise", "Cardamom", "Nutmeg", "Cassia Bark", "Cloves"],
    storageInstructions: "Store sealed in cool dry pantry.",
    complianceNotice: "Proposed formulation. Product undergoes laboratory quality testing.",
    rating: 4.9,
    reviewCount: 41,
    suggestedPairings: ["Mutton Rogan Josh", "Andhra Mamsam Kura", "Nalli Nihari", "Mutton Sukka"]
  },
  {
    id: "spicora-mas-biryani",
    name: "Biryani Masala",
    slug: "biryani-masala",
    tagline: "Authentic Nizam & Nawabi Dum Blend",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "A regal symphony of shahi jeera, javitri, green cardamom, and bay leaves crafted for unforgettable rice feasts.",
    description: "Every household in Andhra Pradesh knows that the soul of biryani is in the slow dum aroma. Our Biryani Masala balances floral notes and warming spices so every grain of basmati rice glistens with royal flavor.",
    images: [
      "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-biry-50g", size: "50 g", price: 65, compareAtPrice: 85, inStock: true, sku: "SPIC-MAS-BIR-50" },
      { id: "mas-biry-100g", size: "100 g", price: 119, compareAtPrice: 155, inStock: true, sku: "SPIC-MAS-BIR-100" },
      { id: "mas-biry-200g", size: "200 g", price: 229, compareAtPrice: 290, inStock: true, sku: "SPIC-MAS-BIR-200" },
      { id: "mas-biry-500g", size: "500 g", price: 519, compareAtPrice: 680, inStock: true, sku: "SPIC-MAS-BIR-500" }
    ],
    status: "Active",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["Shahi Jeera", "Sweet Javitri (Mace)", "Green Cardamom", "Nutmeg"],
    ingredients: ["Caraway Seeds (Shahi Jeera)", "Cardamom", "Mace", "Nutmeg", "Coriander", "Cinnamon", "Cloves", "Bay Leaf", "Fennel"],
    storageInstructions: "Store sealed in an airtight tin.",
    complianceNotice: "Proposed formulation. Validation pending prior to retail distribution.",
    rating: 4.9,
    reviewCount: 47,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["Hyderabadi Chicken Biryani", "Vegetable Dum Biryani", "Egg Biryani", "Jeera Rice"]
  },
  {
    id: "spicora-mas-sambar",
    name: "Sambar Powder",
    slug: "sambar-powder",
    tagline: "Soulful Madras & Rayalaseema Style Sambar",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Slow-roasted chana dal, urad dal, coriander, fenugreek, and Guntur chillies for comforting, thick, homestyle sambar.",
    description: "The secret to restaurant-standard tiffin sambar lies in the roasted lentil-spice matrix. SPICORA Sambar Powder delivers unmistakable aroma the instant it hits boiling toor dal and drumsticks.",
    images: [
      "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-sam-100g", size: "100 g", price: 89, compareAtPrice: 110, inStock: true, sku: "SPIC-MAS-SAM-100" },
      { id: "mas-sam-200g", size: "200 g", price: 169, compareAtPrice: 210, inStock: true, sku: "SPIC-MAS-SAM-200" },
      { id: "mas-sam-500g", size: "500 g", price: 389, compareAtPrice: 480, inStock: true, sku: "SPIC-MAS-SAM-500" }
    ],
    status: "Active",
    origin: "Guntur & Godavari Heritage",
    flavourNotes: ["Roasted Fenugreek Bitterness", "Nutty Chana Dal", "Warm Coriander", "Mild Guntur Zing"],
    ingredients: ["Coriander Seeds", "Red Chilli", "Bengal Gram (Chana Dal)", "Black Gram (Urad Dal)", "Fenugreek", "Cumin", "Asafoetida", "Curry Leaves"],
    storageInstructions: "Store in a dry cupboard away from water drops.",
    complianceNotice: "Proposed blend recipe. Under quality assurance pilot.",
    rating: 4.8,
    reviewCount: 28,
    suggestedPairings: ["Idli & Dosa Sambar", "Rice Sambar with Shallots", "Mixed Veg Stew"]
  },
  {
    id: "spicora-mas-rasam",
    name: "Rasam Powder",
    slug: "rasam-powder",
    tagline: "Therapeutic Peppery & Tangy Elixir",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Coarsely ground black pepper, cumin seeds, roasted coriander, and hing for rejuvenating South Indian rasam broth.",
    description: "Brewed for comfort and digestion, a piping bowl of rasam made with SPICORA Rasam Powder awakens your palate. The coarse grind releases essential oils steadily into hot tamarind-tomato water.",
    images: [
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-ras-100g", size: "100 g", price: 95, compareAtPrice: 120, inStock: true, sku: "SPIC-MAS-RAS-100" },
      { id: "mas-ras-200g", size: "200 g", price: 179, compareAtPrice: 230, inStock: true, sku: "SPIC-MAS-RAS-200" },
      { id: "mas-ras-500g", size: "500 g", price: 410, compareAtPrice: 520, inStock: true, sku: "SPIC-MAS-RAS-500" }
    ],
    status: "Active",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["High-Piperine Pepper Warmth", "Earthy Cumin", "Fragrant Asafoetida"],
    ingredients: ["Coriander", "Black Pepper", "Cumin", "Turmeric", "Red Chilli", "Asafoetida (Hing)"],
    storageInstructions: "Keep in dry container.",
    complianceNotice: "Proposed blend specifications. Tested for laboratory safety.",
    rating: 4.7,
    reviewCount: 22,
    suggestedPairings: ["Tomato Rasam", "Pepper Garlic Rasam", "Steamed Hot Rice with Ghee"]
  },
  {
    id: "spicora-mas-red-chilli",
    name: "Red Chilli Powder",
    slug: "red-chilli-powder",
    tagline: "Direct from the World Capital of Chillies: Guntur Sannam",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "100% pure authentic Guntur Sannam chillies sun-dried on river plains and stem-destemmed before single-pass micro-milling.",
    description: "Guntur in Andhra Pradesh is universally revered as India's spice heartland. CHILLA'S SPICORA Red Chilli Powder is our flagship crown jewel: vibrant natural crimson red, clean fiery capsaicin kick, and zero artificial colors, oils, or adulterants.",
    images: [
      "https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-rc-100g", size: "100 g", price: 75, compareAtPrice: 95, inStock: true, sku: "SPIC-MAS-RC-100" },
      { id: "mas-rc-200g", size: "200 g", price: 145, compareAtPrice: 185, inStock: true, sku: "SPIC-MAS-RC-200" },
      { id: "mas-rc-500g", size: "500 g", price: 349, compareAtPrice: 440, inStock: true, sku: "SPIC-MAS-RC-500" }
    ],
    status: "Active",
    origin: "Guntur Agricultural Heartland, Andhra Pradesh",
    flavourNotes: ["Bold Capsaicin Heat", "Sun-Dried Earthiness", "Natural Sweet Red Undertone"],
    ingredients: ["100% Pure Guntur Sannam & Teja Chillies (Stem-removed)"],
    storageInstructions: "Store sealed tightly away from light to prevent natural color fading.",
    complianceNotice: "Proposed single-origin spice product. Lab tested for aflatoxin and pesticide parameters.",
    rating: 5.0,
    reviewCount: 65,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["Andhra Pickles", "Guntur Mirchi Bajji", "Fiery Curries", "Tandoori Marinades"]
  },
  {
    id: "spicora-mas-turmeric",
    name: "Turmeric Powder",
    slug: "turmeric-powder",
    tagline: "High-Curcumin (5%+) Golden Heritage Haldi",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Pure indigenous turmeric fingers sun-cured and slow-milled for rich golden color, earthy aroma, and elevated natural curcumin.",
    description: "Sourced from fertile Andhra and Telangana rhizome belts, SPICORA Turmeric Powder undergoes stringent testing to ensure high active curcumin content. Deep golden-orange hue that stains lightly and delivers genuine Ayurvedic therapeutic value.",
    images: [
      "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-tur-100g", size: "100 g", price: 65, compareAtPrice: 85, inStock: true, sku: "SPIC-MAS-TUR-100" },
      { id: "mas-tur-200g", size: "200 g", price: 125, compareAtPrice: 160, inStock: true, sku: "SPIC-MAS-TUR-200" },
      { id: "mas-tur-500g", size: "500 g", price: 299, compareAtPrice: 380, inStock: true, sku: "SPIC-MAS-TUR-500" }
    ],
    status: "Active",
    origin: "Duggirala & Guntur Region, Andhra Pradesh",
    flavourNotes: ["Warm Earthy", "Subtle Peppery Woodiness", "Vibrant Golden Glow"],
    ingredients: ["100% Single-Origin Turmeric Rhizome"],
    storageInstructions: "Keep in a dark, airtight jar.",
    complianceNotice: "Proposed product specifications. Tested for curcumin active content.",
    rating: 4.9,
    reviewCount: 39,
    isFeatured: true,
    suggestedPairings: ["Golden Turmeric Latte", "Daily Indian Dal", "Curry Foundations", "Face Mask Ubtan"]
  },
  {
    id: "spicora-mas-coriander",
    name: "Coriander Powder",
    slug: "coriander-powder",
    tagline: "Fragrant Slow-Roasted Dhania Powder",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Selected green-tinged coriander seeds roasted gently to release pleasant citrus-floral oils before stone-milling.",
    description: "Coriander powder forms the gentle, cooling backbone of Indian curries. Our slow-roasting technique activates the linalool essential oils, creating a velvety gravy base with uplifting floral nuances.",
    images: [
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-cor-100g", size: "100 g", price: 59, compareAtPrice: 75, inStock: true, sku: "SPIC-MAS-COR-100" },
      { id: "mas-cor-200g", size: "200 g", price: 110, compareAtPrice: 140, inStock: true, sku: "SPIC-MAS-COR-200" },
      { id: "mas-cor-500g", size: "500 g", price: 259, compareAtPrice: 330, inStock: true, sku: "SPIC-MAS-COR-500" }
    ],
    status: "Active",
    origin: "Guntur & Rajasthan Harvest",
    flavourNotes: ["Sweet Citrus", "Subtle Nutty", "Fresh Herbal"],
    ingredients: ["100% Pure Coriander (Dhania) Seeds"],
    storageInstructions: "Seal after every use to lock in citrus fragrance.",
    complianceNotice: "Proposed formulation. Under standard quality evaluation.",
    rating: 4.8,
    reviewCount: 21,
    suggestedPairings: ["Curry Bases", "Sambar", "Sabzi Tadka", "Dry Roasts"]
  },
  {
    id: "spicora-mas-cumin",
    name: "Cumin Powder",
    slug: "cumin-powder",
    tagline: "Intensely Roasted Jeera Powder",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Evenly pan-roasted Indian cumin seeds stone-ground to unlock deep smoky, earthy notes for raitas, chaats, and curries.",
    description: "Nothing compares to the aroma of freshly roasted cumin. SPICORA Cumin Powder eliminates the hassle of pan-toasting at home, bringing you perfectly roasted jeera notes in every sprinkle.",
    images: [
      "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-cum-100g", size: "100 g", price: 85, compareAtPrice: 105, inStock: true, sku: "SPIC-MAS-CUM-100" },
      { id: "mas-cum-200g", size: "200 g", price: 160, compareAtPrice: 200, inStock: true, sku: "SPIC-MAS-CUM-200" },
      { id: "mas-cum-500g", size: "500 g", price: 389, compareAtPrice: 490, inStock: true, sku: "SPIC-MAS-CUM-500" }
    ],
    status: "Active",
    origin: "Gujarat & Guntur Processing",
    flavourNotes: ["Warm Earthy", "Toasted Smoky", "Nutty Finish"],
    ingredients: ["100% Roasted Cumin Seeds (Jeera)"],
    storageInstructions: "Store sealed in cool dry place.",
    complianceNotice: "Proposed single-origin spice product under pilot testing.",
    rating: 4.8,
    reviewCount: 27,
    suggestedPairings: ["Cucumber Raita", "Chaat Toppings", "Buttermilk (Chaas)", "Jeera Aloo"]
  },
  {
    id: "spicora-mas-chai-powder",
    name: "Chai Masala Powder",
    slug: "chai-masala-powder",
    tagline: "Hand-Crushed Kadak Tea Botanical Masala",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "Dry ginger (sonth), green elaichi, dalchini, lavang, and javitri coarsely ground for a soul-warming cup of Indian tea.",
    description: "The quintessential Indian morning ritual perfected. Just 1/4 teaspoon simmered with your tea leaves creates an invigorating cup that soothes the throat and uplifts the mind.",
    images: [
      "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-cp-50g", size: "50 g", price: 89, compareAtPrice: 110, inStock: true, sku: "SPIC-MAS-CP-50" },
      { id: "mas-cp-100g", size: "100 g", price: 169, compareAtPrice: 215, inStock: true, sku: "SPIC-MAS-CP-100" },
      { id: "mas-cp-200g", size: "200 g", price: 319, compareAtPrice: 410, inStock: true, sku: "SPIC-MAS-CP-200" }
    ],
    status: "Active",
    origin: "Guntur Blend Kitchen",
    flavourNotes: ["Spicy Dry Ginger", "Aromatic Cardamom", "Clove Tingle", "Sweet Cinnamon"],
    ingredients: ["Dry Ginger (Sonth)", "Green Cardamom", "Cinnamon", "Cloves", "Black Pepper", "Nutmeg", "Mace"],
    storageInstructions: "Store tightly sealed to protect essential oils.",
    complianceNotice: "Proposed formulation. Under standard quality evaluation.",
    rating: 4.9,
    reviewCount: 35,
    isFeatured: true,
    suggestedPairings: ["Morning Masala Chai", "Ginger Milk", "Spiced Hot Chocolate"]
  },
  {
    id: "spicora-mas-kitchen-king",
    name: "Kitchen King Masala",
    slug: "kitchen-king-masala",
    tagline: "The All-Purpose Master Gravy Secret",
    categoryId: "masala-powders",
    categoryName: "Traditional Masala Powders",
    packagingType: "powder",
    shortDescription: "A versatile 20-spice culinary blend that elevates any vegetarian dish, dal, or paneer curry to restaurant excellence.",
    description: "When you want an instant burst of balanced flavor without measuring individual spices, Kitchen King Masala is your chef secret. Perfectly harmonizes sweet, pungent, and savory spice profiles.",
    images: [
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "mas-kk-100g", size: "100 g", price: 95, compareAtPrice: 125, inStock: true, sku: "SPIC-MAS-KK-100" },
      { id: "mas-kk-200g", size: "200 g", price: 179, compareAtPrice: 235, inStock: true, sku: "SPIC-MAS-KK-200" },
      { id: "mas-kk-500g", size: "500 g", price: 419, compareAtPrice: 530, inStock: true, sku: "SPIC-MAS-KK-500" }
    ],
    status: "Development",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["Balanced Savory", "Warm Garam Masala Undercurrent", "Fenugreek Leaf Finish"],
    ingredients: ["Coriander", "Cumin", "Turmeric", "Chilli", "Kasuri Methi", "Cardamom", "Nutmeg", "Black Pepper", "Dry Mango (Amchur)", "Mustard"],
    storageInstructions: "Store in a cool dry pantry.",
    complianceNotice: "Currently in formulation and taste panel review.",
    rating: 4.7,
    reviewCount: 16,
    suggestedPairings: ["Mixed Veg Curry", "Paneer Lababdar", "Aloo Gobi", "Mutter Mushroom"]
  }
];
