import { Product } from "@/types";

export const LIQUID_PRODUCTS: Product[] = [
  {
    id: "spicora-liq-chai",
    name: "Traditional Chai Masala Liquid",
    slug: "traditional-chai-masala-liquid",
    tagline: "2 Drops for Royal Kadak Chai Essence",
    categoryId: "liquid-flavours",
    categoryName: "Signature Liquid Flavours",
    packagingType: "liquid",
    isLiquidFlagship: true,
    discountBadge: "FLAGSHIP HERO",
    shortDescription: "Pure cold-extracted botanical blend of green cardamom, sun-cured ginger, Ceylon cinnamon, and clove drops for instant cafe-grade chai.",
    description: "CHILLA'S SPICORA Traditional Chai Masala Liquid is our crown jewel innovation. Just 2 to 3 concentrated drops transform boiling milk and black tea into an intoxicatingly fragrant, authentic cup of Kadak Masala Chai. Engineered using proprietary ultrasonic cold-infusion to retain the volatile aromatic terpenes without bitter tannins.",
    images: [
      "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "liq-chai-30ml", size: "30 ml (approx. 600 drops)", price: 199, compareAtPrice: 249, inStock: true, sku: "SPIC-LQ-CHAI-30" },
      { id: "liq-chai-50ml", size: "50 ml (approx. 1000 drops)", price: 299, compareAtPrice: 380, inStock: true, sku: "SPIC-LQ-CHAI-50" }
    ],
    status: "Active",
    origin: "Guntur Culinary Lab, Andhra Pradesh",
    flavourNotes: ["Warm Ginger Pungency", "Fragrant Green Cardamom", "Sweet Ceylon Cinnamon", "Clove Undercurrent"],
    ingredients: ["Proprietary cold-pressed spice extracts (Cardamom, Ginger, Cinnamon, Clove, Black Pepper, Nutmeg)", "Plant-derived culinary solubilizer (vegetable glycerin)", "Natural antioxidant (mixed tocopherols)"],
    storageInstructions: "Store in a cool, dry place away from direct sunlight. Do not refrigerate. Shake gently before use.",
    complianceNotice: "Proposed formulation. Product undergoes laboratory quality testing and validation prior to commercial dispatch. FSSAI registration in progress.",
    rating: 4.9,
    reviewCount: 38,
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: true,
    suggestedPairings: ["Assam CTC Tea", "Hot Milk", "Spiced Chai Latte", "Baked Tea Cakes"],
    tags: ["Hero Product", "Flagship Liquid", "Chai Drops", "Zero Residue"],
    offerDetails: "Buy with Chai Lovers Kit or get 20% off when buying 2 liquids!"
  },
  {
    id: "spicora-liq-biryani",
    name: "Biryani Flavour Liquid",
    slug: "biryani-flavour-liquid",
    tagline: "The Secret Royal Dum Aroma in Every Drop",
    categoryId: "liquid-flavours",
    categoryName: "Signature Liquid Flavours",
    packagingType: "liquid",
    isLiquidFlagship: true,
    discountBadge: "TOP SELLER",
    shortDescription: "Concentrated Mughlai & Hyderabadi aromatic essence with mace, star anise, saffron extracts, and kewra nuances for dum cooking.",
    description: "Capture that unforgettable, room-filling fragrance of freshly unsealed Degchi biryani. Designed specifically for biryani connoisseurs, caterers, and home chefs, this liquid drops effortlessly distribute essential spice oils evenly through rice grains without leaving gritty uncrushed spices between the teeth.",
    images: [
      "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "liq-biry-30ml", size: "30 ml (approx. 600 drops)", price: 229, compareAtPrice: 289, inStock: true, sku: "SPIC-LQ-BIRY-30" },
      { id: "liq-biry-50ml", size: "50 ml (approx. 1000 drops)", price: 349, compareAtPrice: 429, inStock: true, sku: "SPIC-LQ-BIRY-50" }
    ],
    status: "Active",
    origin: "Guntur & Hyderabad Culinary Research",
    flavourNotes: ["Kashmiri Saffron floral", "Sweet Mace (Javitri)", "Star Anise warmth", "Royal Kewra hint"],
    ingredients: ["Distilled Mace extract", "Star Anise oleoresin", "Kashmiri saffron distillate", "Cardamom extract", "Black cumin extract", "Edible carrier medium"],
    storageInstructions: "Store capped tightly in ambient conditions. Avoid damp environments.",
    complianceNotice: "Proposed formulation. Under batch evaluation and pilot trial validation. FSSAI licensing pending confirmation.",
    rating: 4.8,
    reviewCount: 29,
    isFeatured: true,
    suggestedPairings: ["Dum Biryani Rice", "Ghee Rice", "Pulao", "Mutton Marination"],
    tags: ["Hero Product", "Flagship Liquid", "Dum Essence", "Chef Secret"],
    offerDetails: "Included in Biryani Special Kit — Save 25% on bundle!"
  },
  {
    id: "spicora-liq-ginger-garlic",
    name: "Ginger-Garlic Flavour Liquid",
    slug: "ginger-garlic-flavour-liquid",
    tagline: "Instant Pungency Without the Peeling or Burning",
    categoryId: "liquid-flavours",
    categoryName: "Signature Liquid Flavours",
    packagingType: "liquid",
    isLiquidFlagship: true,
    discountBadge: "KITCHEN HACK",
    shortDescription: "Zero-water, high-intensity cold extract of pure Indian ginger and roasted garlic that will not splatter or burn in hot oil.",
    description: "Traditional wet ginger-garlic paste splatters furiously, burns quickly, and sours in the fridge within days. SPICORA Ginger-Garlic Flavour Liquid utilizes lipid-phase micro-extracts that disperse smoothly into curries, marinades, and stir-fries, delivering pure pungency and allicin aroma instantly.",
    images: [
      "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "liq-gg-30ml", size: "30 ml (approx. 600 drops)", price: 179, compareAtPrice: 220, inStock: true, sku: "SPIC-LQ-GG-30" },
      { id: "liq-gg-50ml", size: "50 ml (approx. 1000 drops)", price: 269, compareAtPrice: 340, inStock: true, sku: "SPIC-LQ-GG-50" }
    ],
    status: "Active",
    origin: "Guntur Spices Park",
    flavourNotes: ["Sharp Fresh Ginger Heat", "Nutty Mellow Garlic", "Earthy Terpene Finish"],
    ingredients: ["Zingiber officinale (Ginger) extract", "Allium sativum (Garlic) oleoresin", "Cold-pressed sesame oil carrier"],
    storageInstructions: "Keep dropper clean. Store away from heat sources.",
    complianceNotice: "Currently in formulation and stability testing phase. Pre-order / notification available.",
    rating: 4.7,
    reviewCount: 14,
    isNewArrival: true,
    suggestedPairings: ["Curry Bases", "Tandoori Marinades", "Hakka Noodles", "Dal Tadka"],
    tags: ["Hero Product", "Flagship Liquid", "No-Splatter", "Cooking Innovation"]
  },
  {
    id: "spicora-liq-cardamom",
    name: "Cardamom Flavour Liquid",
    slug: "cardamom-flavour-liquid",
    tagline: "Pure Elaichi Essence from Idukki Green Pods",
    categoryId: "liquid-flavours",
    categoryName: "Signature Liquid Flavours",
    packagingType: "liquid",
    isLiquidFlagship: true,
    discountBadge: "PURE ESSENCE",
    shortDescription: "Ultra-pure botanical green cardamom liquid drops. One drop equals the aromatic punch of 6 crushed prime cardamom pods.",
    description: "Sourced from high-altitude shade-grown estates in the Western Ghats and concentrated in Guntur. Perfect for Indian mithai, kheer, payasam, badam milk, iced tea, and festive desserts without gritty husks or fibrous residue.",
    images: [
      "https://images.unsplash.com/photo-1599940824399-b87987ceb72a?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "liq-card-30ml", size: "30 ml (approx. 600 drops)", price: 249, compareAtPrice: 299, inStock: true, sku: "SPIC-LQ-CARD-30" },
      { id: "liq-card-50ml", size: "50 ml (approx. 1000 drops)", price: 389, compareAtPrice: 470, inStock: true, sku: "SPIC-LQ-CARD-50" }
    ],
    status: "Active",
    origin: "Idukki & Guntur Extraction Facility",
    flavourNotes: ["Eucalyptol crispness", "Floral Sweetness", "Balsamic Warmth"],
    ingredients: ["Green Cardamom (Elettaria cardamomum) oleoresin", "Plant-based edible emulsifier"],
    storageInstructions: "Store tightly sealed in dark ambient space.",
    complianceNotice: "Proposed formulation. Product undergoes quality testing prior to commercial release.",
    rating: 4.9,
    reviewCount: 42,
    isFeatured: true,
    suggestedPairings: ["Payasam", "Gulab Jamun Syrup", "Masala Chai", "Kheer", "Halwa"],
    tags: ["Hero Product", "Flagship Liquid", "Idukki Cardamom", "Dessert Drops"]
  },
  {
    id: "spicora-liq-tandoori",
    name: "Tandoori Flavour Liquid",
    slug: "tandoori-flavour-liquid",
    tagline: "Authentic Charcoal Smoky Tandoori Notes",
    categoryId: "liquid-flavours",
    categoryName: "Signature Liquid Flavours",
    packagingType: "liquid",
    isLiquidFlagship: true,
    discountBadge: "SMOKY CHAR",
    shortDescription: "Natural botanical liquid infusion of charcoal smoke, roasted cumin, Kashmiri chili oil, and fenugreek for restaurant-style tikkas.",
    description: "Recreate the distinct, appetizing char and deep aromatic glaze of a traditional coal tandoor oven on your domestic gas stovetop or home air fryer. Effortlessly blends into curd marinades for paneer, chicken, and mushrooms.",
    images: [
      "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "liq-tand-30ml", size: "30 ml (approx. 600 drops)", price: 219, compareAtPrice: 269, inStock: true, sku: "SPIC-LQ-TAND-30" },
      { id: "liq-tand-50ml", size: "50 ml (approx. 1000 drops)", price: 329, compareAtPrice: 399, inStock: true, sku: "SPIC-LQ-TAND-50" }
    ],
    status: "Active",
    origin: "Guntur, Andhra Pradesh",
    flavourNotes: ["Hickory and Coal Smoke", "Roasted Jeera", "Kasuri Methi Fragrance", "Mild Chili Bite"],
    ingredients: ["Naturally condensed wood smoke essence", "Kashmiri chilli extracts", "Roasted cumin extract", "Fenugreek leaf extract"],
    storageInstructions: "Store away from intense sunlight.",
    complianceNotice: "Proposed formulation. Under standard safety and shelf-life protocol.",
    rating: 4.6,
    reviewCount: 19,
    suggestedPairings: ["Paneer Tikka", "Chicken Tikka", "Grilled Vegetables", "Soya Chaap"],
    tags: ["Hero Product", "Flagship Liquid", "Smoky Essence", "Tikka Secret"]
  },
  {
    id: "spicora-liq-pepper",
    name: "Pepper Flavour Liquid",
    slug: "pepper-flavour-liquid",
    tagline: "Intense Tellicherry Black Pepper Kick",
    categoryId: "liquid-flavours",
    categoryName: "Signature Liquid Flavours",
    packagingType: "liquid",
    isLiquidFlagship: true,
    discountBadge: "BOLD PIPERINE",
    shortDescription: "High-piperine Malabar black pepper liquid concentrate. Delivers sudden, blooming peppery warmth to rasams, soups, and roasts.",
    description: "Derived from plump Malabar black peppercorns, this liquid delivers immediate piperine sharpness and complex woody-terpene notes without sediment settling at the bottom of the dish.",
    images: [
      "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80"
    ],
    variants: [
      { id: "liq-pep-30ml", size: "30 ml (approx. 600 drops)", price: 189, compareAtPrice: 239, inStock: true, sku: "SPIC-LQ-PEP-30" },
      { id: "liq-pep-50ml", size: "50 ml (approx. 1000 drops)", price: 279, compareAtPrice: 350, inStock: true, sku: "SPIC-LQ-PEP-50" }
    ],
    status: "Active",
    origin: "Malabar Coast & Guntur Facility",
    flavourNotes: ["Sharp Piperine Heat", "Cedar Wood Aromas", "Citrus Undertones"],
    ingredients: ["Black pepper (Piper nigrum) extract", "Natural edible triglyceride carrier"],
    storageInstructions: "Store at room temperature.",
    complianceNotice: "Scheduled for release post laboratory verification.",
    rating: 4.8,
    reviewCount: 8,
    isNewArrival: true,
    suggestedPairings: ["Pepper Chicken Fry", "Milagu Rasam", "Steaming Soups", "Egg Omelette"],
    tags: ["Hero Product", "Flagship Liquid", "Tellicherry Pepper", "Quick Infusion"]
  }
];
