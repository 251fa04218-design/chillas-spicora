import { Coupon } from "@/types";

export const DEFAULT_COUPONS: Coupon[] = [
  {
    code: "LIQUIDCOMBO25",
    discountPercent: 25,
    maxDiscount: 500,
    minOrderValue: 699,
    description: "25% OFF on Liquid Spices & Curated Combo Packs above ₹699",
    isActive: true
  },
  {
    code: "LIQUIDTRIO",
    discountPercent: 20,
    maxDiscount: 350,
    minOrderValue: 499,
    description: "20% OFF on Signature Liquid Spices & Flavours",
    isActive: true
  },
  {
    code: "SPICORA10",
    discountPercent: 10,
    maxDiscount: 250,
    minOrderValue: 499,
    description: "10% OFF on all orders above ₹499",
    isActive: true
  },
  {
    code: "GUNTURFIRST",
    discountPercent: 15,
    maxDiscount: 400,
    minOrderValue: 799,
    description: "15% OFF welcome discount for authentic spice connoisseurs",
    isActive: true
  },
  {
    code: "ROYAL20",
    discountPercent: 20,
    maxDiscount: 600,
    minOrderValue: 1299,
    description: "20% OFF on grand orders above ₹1299",
    isActive: true
  }
];
