import React from "react";
import Link from "next/link";

interface LogoProps {
  variant?: "light" | "dark" | "gold";
  size?: "sm" | "md" | "lg" | "xl";
  showTagline?: boolean;
}

export function Logo({
  variant = "light",
  size = "md",
  showTagline = true,
}: LogoProps) {
  const isDarkBg = variant === "light"; // On dark forest-green background, logo text should be gold/cream

  const iconSizes = {
    sm: "w-7 h-7",
    md: "w-9 h-9",
    lg: "w-12 h-12",
    xl: "w-16 h-16",
  };

  const titleSizes = {
    sm: "text-base tracking-wider",
    md: "text-xl tracking-widest",
    lg: "text-2xl tracking-[0.2em]",
    xl: "text-3xl tracking-[0.25em]",
  };

  const taglineSizes = {
    sm: "text-[8px] tracking-[0.2em]",
    md: "text-[10px] tracking-[0.25em]",
    lg: "text-xs tracking-[0.3em]",
    xl: "text-sm tracking-[0.35em]",
  };

  return (
    <Link href="/" className="group inline-flex items-center gap-3 select-none">
      {/* Royal Spice Crest SVG Icon */}
      <div
        className={`relative ${iconSizes[size]} flex items-center justify-center rounded-full bg-gradient-to-br from-[#D4A84F] via-[#F4E6BE] to-[#B3862D] p-[1.5px] shadow-md group-hover:scale-105 transition-transform duration-300`}
      >
        <div className="w-full h-full rounded-full bg-[#174D35] flex items-center justify-center p-1.5">
          <svg
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full text-[#D4A84F]"
          >
            {/* 8-point botanical spice star / star anise motif */}
            <circle cx="50" cy="50" r="44" stroke="#D4A84F" strokeWidth="2" strokeDasharray="3 3" opacity="0.6" />
            <path
              d="M50 10 C53 30, 70 47, 90 50 C70 53, 53 70, 50 90 C47 70, 30 53, 10 50 C30 47, 47 30, 50 10 Z"
              fill="url(#goldGradient)"
            />
            {/* Inner mortar flame / aroma petal */}
            <circle cx="50" cy="50" r="16" fill="#174D35" stroke="#D4A84F" strokeWidth="2" />
            <path
              d="M50 40 C54 46, 56 50, 50 58 C44 50, 46 46, 50 40 Z"
              fill="#D4A84F"
            />
            <defs>
              <linearGradient id="goldGradient" x1="10" y1="10" x2="90" y2="90" gradientUnits="userSpaceOnUse">
                <stop stopColor="#F7E7C4" />
                <stop offset="0.5" stopColor="#D4A84F" />
                <stop offset="1" stopColor="#9C7226" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col">
        <span
          className={`font-serif font-extrabold uppercase leading-none ${
            isDarkBg ? "text-white" : "text-[#174D35]"
          } ${titleSizes[size]}`}
        >
          CHILLA&apos;S{" "}
          <span className="text-[#D4A84F] group-hover:text-[#F3DC9B] transition-colors">
            SPICORA
          </span>
        </span>

        {showTagline && (
          <span
            className={`font-sans uppercase font-medium mt-1 leading-tight ${
              isDarkBg ? "text-[#D4A84F]" : "text-[#87571F]"
            } ${taglineSizes[size]}`}
          >
            THE ESSENCE OF INDIAN SPICES
          </span>
        )}
      </div>
    </Link>
  );
}
