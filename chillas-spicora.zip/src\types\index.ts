export type ProductStatus = 'Active' | 'Development' | 'Coming Soon' | 'Out of Stock' | 'Discontinued';

export type PackagingType = 'liquid' | 'powder' | 'whole' | 'combo';

export interface ProductVariant {
  id: string;
  size: string; // e.g., "30 ml", "50 ml", "50 g", "100 g", "200 g", "500 g", "Combo Box"
  price: number; // Proposed demo price
  compareAtPrice?: number;
  inStock: boolean;
  sku: string;
  isProposed?: boolean;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  tagline?: string;
  categoryId: string;
  categoryName: string;
  packagingType: PackagingType;
  shortDescription: string;
  description: string;
  images: string[];
  variants: ProductVariant[];
  status: ProductStatus;
  origin: string; // e.g. "Guntur, Andhra Pradesh"
  flavourNotes: string[];
  ingredients: string[];
  storageInstructions: string;
  complianceNotice: string;
  rating: number;
  reviewCount: number;
  isFeatured?: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  suggestedPairings?: string[];
  tags?: string[];
  commercialApprovalStatus?: 'Proposed Concept' | 'Formulation Stage' | 'Safety Testing' | 'Approved for Pilot' | 'Commercially Certified';
  bundleItems?: string[];
  discountBadge?: string;
  isLiquidFlagship?: boolean;
  offerDetails?: string;
  savingsAmount?: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  shortName: string;
  description: string;
  heroImage: string;
  itemCount: number;
  badge?: string;
}

export interface CartItem {
  id: string; // unique item id (productId + variantId)
  product: Product;
  variant: ProductVariant;
  quantity: number;
}

export interface Recipe {
  id: string;
  title: string;
  slug: string;
  category: 'Chai' | 'Biryani' | 'Seafood' | 'Poultry' | 'Andhra Curry' | 'Vegetarian' | 'Traditional Veg' | 'Traditional Non-Veg' | 'Meat & Mutton';
  dietary: 'Veg' | 'Non-Veg';
  prepTime: string;
  cookTime: string;
  servings: string;
  difficulty: 'Easy' | 'Medium' | 'Master';
  description: string;
  image: string;
  videoUrl?: string; // e.g., YouTube embed URL
  videoDuration?: string;
  videoThumbnail?: string;
  ingredients: string[];
  instructions: string[];
  spicoraPairing: {
    productId: string;
    productName: string;
    productSlug: string;
    tip: string;
  };
  verifiedTesting: boolean;
}

export interface B2BEnquiry {
  id: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  businessType: 'Restaurant' | 'Hotel' | 'Tea Shop / Cafe' | 'Caterer' | 'Retail Store' | 'Distributor' | 'Supermarket' | 'Other';
  gstin?: string;
  city: string;
  state: string;
  estimatedVolume: 'Under 25 kg/month' | '25 - 100 kg/month' | '100 - 500 kg/month' | '500+ kg/month' | 'Custom Liquid Batch';
  productInterests: string[];
  notes: string;
  createdAt: string;
  status: 'New' | 'Under Review' | 'Quotation Sent' | 'Active Customer';
}

export interface OrderCustomer {
  fullName: string;
  email: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customer: OrderCustomer;
  items: CartItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  shipping: number;
  total: number;
  paymentMethod: 'razorpay' | 'upi' | 'card' | 'netbanking' | 'cod';
  paymentStatus: 'Paid' | 'Pending' | 'Test Mode Completed' | 'COD Confirmed';
  orderStatus: 'Placed' | 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered' | 'Cancelled';
  trackingNumber?: string;
  createdAt: string;
  notes?: string;
}

export interface Review {
  id: string;
  productId: string;
  author: string;
  rating: number;
  title: string;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
  isDemo: boolean;
  status?: 'Approved' | 'Pending' | 'Flagged';
}

export interface Coupon {
  code: string;
  discountPercent: number;
  maxDiscount: number;
  minOrderValue: number;
  description: string;
  isActive: boolean;
}
