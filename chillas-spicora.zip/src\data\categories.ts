import { Category } from "@/types";

export const CATEGORIES: Category[] = [
  {
    id: "liquid-flavours",
    name: "Signature Liquid Flavours",
    shortName: "Liquid Flavours",
    slug: "signature-liquid-flavours",
    description: "Our flagship innovation: Ultrasonic cold-extracted liquid spice drops. 1 drop = 1 spoon of whole spices. Zero residue, instant aroma, and effortless culinary blending.",
    heroImage: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=1200&q=80",
    itemCount: 6,
    badge: "★ FLAGSHIP PRODUCT"
  },
  {
    id: "combo-packs",
    name: "Exclusive Combo Offers & Bundles",
    shortName: "Combo Offers",
    slug: "combo-packs",
    description: "Value-packed curated combos pairing our flagship liquid spices with stone-ground masalas and whole botanicals. Save up to 30% on curated bundles.",
    heroImage: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=1200&q=80",
    itemCount: 8,
    badge: "UP TO 30% OFF COMBOS"
  },
  {
    id: "masala-powders",
    name: "Traditional Masala Powders",
    shortName: "Masala Powders",
    slug: "traditional-masala-powders",
    description: "Stone-ground, slow-roasted aromatic spice powders perfected over generations using authentic Andhra and South Indian heritage recipes.",
    heroImage: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=80",
    itemCount: 12,
    badge: "Heritage Kitchen"
  },
  {
    id: "special-blends",
    name: "Special Spice Blends",
    shortName: "Special Blends",
    slug: "special-spice-blends",
    description: "Gourmet, chef-crafted spice blends curated for regional specialties from Andhra fry delicacies to Royal Hyderabadi biryanis.",
    heroImage: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=1200&q=80",
    itemCount: 10,
    badge: "Master Blends"
  },
  {
    id: "whole-spices",
    name: "Whole Spices",
    shortName: "Whole Spices",
    slug: "whole-spices",
    description: "Hand-picked, sun-dried, whole farm-fresh botanicals with intact essential volatile oils, rich aroma, and pure terroir.",
    heroImage: "https://images.unsplash.com/photo-1532336414038-cf19250c5757?auto=format&fit=crop&w=1200&q=80",
    itemCount: 14,
    badge: "100% Whole Grade A"
  }
];
