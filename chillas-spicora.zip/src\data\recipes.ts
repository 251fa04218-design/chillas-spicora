import { Recipe } from "@/types";

export const RECIPES: Recipe[] = [
  // 1. BEVERAGES & CHAI
  {
    id: "rec-chai",
    title: "Royal Kadak Masala Chai",
    slug: "royal-kadak-masala-chai",
    category: "Chai",
    dietary: "Veg",
    prepTime: "5 mins",
    cookTime: "10 mins",
    servings: "2 cups",
    difficulty: "Easy",
    description: "The quintessential Indian morning comfort. Robust Assam CTC black tea simmered gently with fresh milk and elevated by warming cardamom, sonth ginger, and clove aromatics.",
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/5-b0Qf8q4eE",
    videoDuration: "6:25",
    videoThumbnail: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "1 cup filtered water",
      "1 cup fresh whole milk",
      "2 tsp Assam CTC Black Tea leaves",
      "2-3 tsp raw cane sugar or jaggery (to taste)",
      "2 drops SPICORA Traditional Chai Masala Liquid OR 1/4 tsp Chai Masala Powder",
      "1 crushed green cardamom pod (optional flourish)"
    ],
    instructions: [
      "Bring 1 cup of water to a rolling boil in a heavy saucepan.",
      "Add black tea leaves and simmer for 2 minutes to release rich golden color.",
      "Pour in fresh whole milk and sugar. Bring back to a frothy boil over medium heat.",
      "Reduce heat and let it simmer for 3 minutes until a rich caramel-tan color develops.",
      "Remove saucepan from heat and immediately add 2 drops of SPICORA Traditional Chai Masala Liquid.",
      "Stir gently, strain through a fine tea sieve into clay kulhads, and serve piping hot."
    ],
    spicoraPairing: {
      productId: "spicora-liq-chai",
      productName: "Traditional Chai Masala Liquid",
      productSlug: "traditional-chai-masala-liquid",
      tip: "Suggested pairing: Add 2 drops off the heat right before straining so the delicate top-note volatile cardamoms do not boil off."
    },
    verifiedTesting: true
  },
  {
    id: "rec-kesar-badam-milk",
    title: "Shahi Kesar Badam Doodh",
    slug: "shahi-kesar-badam-doodh",
    category: "Chai",
    dietary: "Veg",
    prepTime: "15 mins",
    cookTime: "15 mins",
    servings: "3 glasses",
    difficulty: "Easy",
    description: "Royal Ayurvedic almond tonic infused with genuine Kashmiri Mongra saffron stigmas, green cardamom, and slivered pistachios.",
    image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/Pj15xZ7k4YQ",
    videoDuration: "5:40",
    videoThumbnail: "https://images.unsplash.com/photo-1599940824399-b87987ceb72a?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "3 cups full-cream buffalo or cow milk",
      "15 almonds (soaked, peeled and pureed into smooth paste)",
      "1 pinch SPICORA Kashmiri Mongra Saffron threads (steeped in 2 tbsp warm milk)",
      "2 drops SPICORA Cardamom Flavour Liquid (or 3 freshly cracked Idukki green pods)",
      "3 tbsp rock sugar (mishri) or raw cane sugar",
      "1 tbsp slivered pistachios and almonds for royal garnish"
    ],
    instructions: [
      "Heat milk in a thick-bottomed vessel until it comes to a slow boil.",
      "Stir in the smooth almond puree and cook on low heat for 8 minutes, stirring continuously to prevent scorching.",
      "Add rock sugar and the golden steeped saffron milk. Watch the drink turn into an exquisite sunset yellow.",
      "Remove from heat and add 2 drops of SPICORA Cardamom Flavour Liquid.",
      "Garnish with sliced pistachios and serve warm in winter or chilled in summer."
    ],
    spicoraPairing: {
      productId: "spicora-wh-saffron",
      productName: "Kashmiri Mongra Saffron & Cardamom Drops",
      productSlug: "saffron",
      tip: "Suggested pairing: Steeping Mongra saffron threads in lukewarm milk for 15 minutes before cooking releases maximum crocin gold color."
    },
    verifiedTesting: true
  },

  // 2. TRADITIONAL VEG RECIPES
  {
    id: "rec-gutti-vankaya",
    title: "Andhra Gutti Vankaya Kura (Stuffed Brinjal Curry)",
    slug: "andhra-gutti-vankaya-kura",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "25 mins",
    cookTime: "30 mins",
    servings: "4 servings",
    difficulty: "Medium",
    description: "The crown jewel of Telugu vegetarian cuisine. Tender purple baby eggplants slit four-ways and stuffed with a roasted spice paste of peanuts, white sesame, Guntur chillies, and tamarind.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/EwF0q0WkGk0",
    videoDuration: "11:15",
    videoThumbnail: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "8-10 small purple baby eggplants (vankayalu)",
      "3 tbsp roasted groundnuts (peanuts)",
      "2 tbsp white sesame seeds (til)",
      "1.5 tbsp SPICORA Coriander Powder (Dhania)",
      "1 tbsp SPICORA Cumin Seeds (Jeera)",
      "1.5 tbsp SPICORA Red Chilli Powder (Guntur Sannam)",
      "1/2 tsp SPICORA Turmeric Powder",
      "1 tbsp dry desiccated coconut (kopra)",
      "1 small lemon-sized tamarind extracted in 1/2 cup warm water",
      "4 tbsp peanut oil for slow braising",
      "Fresh curry leaves and cilantro"
    ],
    instructions: [
      "Slit baby brinjals in a plus (+) shape keeping the green stem intact. Soak in salted water to avoid discoloration.",
      "Dry roast peanuts, sesame seeds, cumin, coriander seeds, and dry coconut until fragrant. Grind with red chilli, turmeric, garlic, salt, and tamarind pulp into a thick stuffing paste.",
      "Stuff each brinjal generously with the spice paste, reserving 2 tablespoons of paste for the gravy.",
      "Heat peanut oil in a wide heavy kadai. Add mustard seeds and curry leaves until spluttering.",
      "Carefully arrange stuffed brinjals in a single layer. Cover and cook on medium-low flame for 12 minutes, turning gently every few minutes.",
      "Pour in the remaining spice paste mixed with 1 cup of warm water. Simmer on low flame for another 15 minutes until brinjals are melt-in-mouth tender and spiced oil floats to the top.",
      "Serve piping hot with steamed sona masoori rice and a dollop of pure cow ghee."
    ],
    spicoraPairing: {
      productId: "spicora-mas-red-chilli",
      productName: "Guntur Sannam Red Chilli & Coriander Powder",
      productSlug: "red-chilli-powder",
      tip: "Suggested pairing: Authentic Telugu Gutti Vankaya requires the sharp capsaicin warmth of Guntur Sannam chillies to cut through the rich peanut-sesame base."
    },
    verifiedTesting: true
  },
  {
    id: "rec-gongura-pappu",
    title: "Andhra Gongura Pappu (Tangy Sorrel Leaves Dal)",
    slug: "andhra-gongura-pappu",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "15 mins",
    cookTime: "20 mins",
    servings: "4-5 servings",
    difficulty: "Easy",
    description: "The soul food of Andhra Pradesh. Earthy toor dal cooked with fresh sour red-stemmed gongura leaves, green chillies, garlic, and finished with a sizzling mustard-cumin ghee tadka.",
    image: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/5K7q2qQoXqM",
    videoDuration: "8:50",
    videoThumbnail: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "1 cup Toor Dal (split yellow pigeon peas), rinsed",
      "2 large bunches fresh red-stemmed Gongura leaves, washed and chopped",
      "5-6 green chillies, slit lengthwise",
      "1 tsp SPICORA Turmeric Powder",
      "1 tsp SPICORA Red Chilli Powder",
      "1 large onion, roughly chopped",
      "6-8 garlic cloves, crushed",
      "Tadka: 2 tbsp pure ghee, 1 tsp mustard seeds, 1 tsp cumin seeds, 3 dry Guntur red chillies, asafoetida (hing), curry leaves"
    ],
    instructions: [
      "In a pressure cooker, add toor dal, chopped gongura leaves, onions, green chillies, turmeric powder, and 2.5 cups water.",
      "Cook for 4-5 whistles until dal is buttery soft.",
      "Release pressure naturally. Using a traditional wooden masher (pappu gutti), gently mash the dal and sour gongura leaves with salt and red chilli powder into a rustic puree.",
      "Prepare the royal tempering: Heat ghee in a tadka pan. Add mustard seeds, cumin seeds, crushed garlic, whole dried Guntur chillies, and a generous pinch of hing.",
      "Once garlic turns golden and aromatic, pour sizzling tadka immediately into the dal and cover with lid for 3 minutes to trap aroma.",
      "Serve hot with steamed rice, ghee, and roasted papad."
    ],
    spicoraPairing: {
      productId: "spicora-wh-cumin-seeds",
      productName: "Whole Cumin Seeds & Turmeric Powder",
      productSlug: "cumin-seeds",
      tip: "Suggested pairing: Crushing whole cumin seeds lightly before tempering releases rich thymol aromas that complement sour gongura leaves."
    },
    verifiedTesting: true
  },
  {
    id: "rec-paneer-butter-masala",
    title: "Shahi Paneer Butter Masala",
    slug: "shahi-paneer-butter-masala",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "20 mins",
    cookTime: "25 mins",
    servings: "4 servings",
    difficulty: "Medium",
    description: "Velvety, restaurant-style cottage cheese cubes enveloped in a rich, buttery cashew-tomato makhani sauce infused with stone-ground Garam Masala and kasuri methi.",
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/9g_0v9hZ_vA",
    videoDuration: "12:10",
    videoThumbnail: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "300g fresh Malai Paneer, cut into cubes",
      "5 ripe red Roma tomatoes, chopped",
      "15 whole cashew nuts",
      "1.5 tbsp SPICORA Garam Masala (16-spice blend)",
      "1 tbsp SPICORA Red Chilli Powder (Kashmiri & Guntur blend for color & bite)",
      "1/2 tsp SPICORA Turmeric Powder",
      "3 tbsp unsalted white butter",
      "2 tbsp fresh dairy cream",
      "1 tbsp crushed kasuri methi (fenugreek leaves)",
      "1 inch cinnamon quill, 2 green cardamoms, 2 cloves"
    ],
    instructions: [
      "Boil tomatoes, cashews, ginger, garlic, and whole spices with 1 cup water for 12 minutes until tomatoes soften. Cool and blend into a silk-smooth makhani puree.",
      "Strain the puree through a fine sieve into a bowl to achieve that luxurious restaurant texture.",
      "Melt 2 tbsp butter in a heavy pan. Add SPICORA Red Chilli Powder and stir for 5 seconds to bloom the color without burning.",
      "Pour in the strained tomato-cashew puree. Simmer on medium-low flame for 10 minutes until thick and aromatic.",
      "Stir in SPICORA Garam Masala, a pinch of sugar, and salt.",
      "Gently slide in fresh paneer cubes and simmer for 3 minutes.",
      "Finish with fresh heavy cream, crushed kasuri methi, and the remaining knob of fresh butter. Serve with butter naan or jeera rice."
    ],
    spicoraPairing: {
      productId: "spicora-mas-garam",
      productName: "Garam Masala (Stone-Ground 16-Spice)",
      productSlug: "garam-masala",
      tip: "Suggested pairing: Adding SPICORA Garam Masala right at the end of cooking preserves the sweet clove and eucalyptol top notes in rich dairy sauces."
    },
    verifiedTesting: true
  },
  {
    id: "rec-mushroom-pepper-fry",
    title: "Chettinad Mushroom Pepper Chukka",
    slug: "chettinad-mushroom-pepper-chukka",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "15 mins",
    cookTime: "15 mins",
    servings: "3 servings",
    difficulty: "Easy",
    description: "Plump button mushrooms pan-roasted dry in cold-pressed sesame oil with freshly cracked Tellicherry black pepper, fennel seeds, and crisp curry leaves.",
    image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/Z0oY6y0X0xA",
    videoDuration: "7:45",
    videoThumbnail: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "400g button mushrooms, cleaned and quartered",
      "2 tbsp SPICORA Pepper Masala OR coarse Tellicherry Black Pepper",
      "1 tbsp SPICORA Fennel Seeds (Saunf), coarsely crushed",
      "1 large red onion, finely chopped",
      "1.5 tbsp ginger-garlic paste",
      "1/2 tsp SPICORA Turmeric Powder",
      "3 sprigs fresh curry leaves",
      "2 tbsp cold-pressed gingelly / sesame oil"
    ],
    instructions: [
      "Heat sesame oil in a flat iron skillet. Sauté crushed fennel seeds and curry leaves until fragrant.",
      "Add finely chopped onions and sauté until deep golden brown.",
      "Stir in ginger-garlic paste and turmeric. Sauté for 2 minutes.",
      "Add quartered mushrooms over high heat. Toss vigorously so mushrooms sear quickly without releasing too much moisture.",
      "Sprinkle SPICORA Pepper Masala and sea salt. Toss continuously for 5-6 minutes until mushrooms develop a deep brown, peppery spiced glaze.",
      "Garnish with crisp fried curry leaves and serve hot with rasam rice or Malabar parotta."
    ],
    spicoraPairing: {
      productId: "spicora-bl-pepper-masala",
      productName: "Pepper Masala & Tellicherry Peppercorns",
      productSlug: "pepper-masala",
      tip: "Suggested pairing: Tellicherry extra bold black pepper provides bold piperine warmth that deepens when pan-toasted in cold-pressed gingelly oil."
    },
    verifiedTesting: true
  },
  {
    id: "rec-pulihora",
    title: "Temple-Style Chintapandu Pulihora (Tamarind Rice)",
    slug: "temple-style-chintapandu-pulihora",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "20 mins",
    cookTime: "25 mins",
    servings: "5 servings",
    difficulty: "Medium",
    description: "The sacred prasadam of Tirupati and Andhra temples. Steamed rice tossed in a thick, spiced tamarind paste cooked down with SPICORA Pulihora spice mix, roasted peanuts, and hing.",
    image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/W9k0Z6q11o0",
    videoDuration: "10:30",
    videoThumbnail: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "2 cups raw Sona Masoori rice, cooked so each grain is separate",
      "1 large orange-sized aged tamarind soaked and extracted into 1.5 cups thick pulp",
      "2 tbsp SPICORA Pulihora Spice Mix",
      "1/2 tsp SPICORA Turmeric Powder",
      "1/2 cup raw peanuts",
      "1 tbsp chana dal & 1 tbsp urad dal",
      "1 tsp mustard seeds",
      "4 whole Guntur dry red chillies",
      "5 green chillies slit",
      "1/2 tsp asafoetida (hing)",
      "4 tbsp sesame oil, curry leaves, salt"
    ],
    instructions: [
      "Spread hot cooked rice on a wide brass platter (thali). Drizzle 1 tbsp sesame oil, turmeric, and fresh curry leaves over it. Let cool completely.",
      "In a heavy pan, simmer thick tamarind pulp with slit green chillies, salt, and turmeric until it thickens into a glossy paste (pulihora paste) and oil separates.",
      "Stir in SPICORA Pulihora Spice Mix into the hot tamarind paste.",
      "Prepare tempering: Heat remaining sesame oil, fry peanuts until crunchy, add chana dal, urad dal, mustard seeds, dry chillies, hing, and curry leaves.",
      "Combine the spiced tamarind paste with the cooled rice gently. Pour the crunchy peanut tadka over the rice and mix evenly with clean hands.",
      "Let rest for at least 2 hours before serving so the flavors permeate the grains."
    ],
    spicoraPairing: {
      productId: "spicora-bl-pulihora",
      productName: "Pulihora Spice Mix & Sesame",
      productSlug: "pulihora-spice-mix",
      tip: "Suggested pairing: Letting temple pulihora rest for 2-3 hours transforms the flavor as the roasted fenugreek and sesame oils infuse the tamarind grains."
    },
    verifiedTesting: true
  },
  {
    id: "rec-traditional-veg",
    title: "Traditional Rayalaseema Sambar & Hot Rice",
    slug: "traditional-rayalaseema-sambar",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "15 mins",
    cookTime: "25 mins",
    servings: "4-5 servings",
    difficulty: "Easy",
    description: "Comforting toor dal simmered with shallots (sambar pearl onions), drumsticks, pumpkin, and freshly infused SPICORA Sambar Powder.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/K8vO9x2L1zA",
    videoDuration: "9:20",
    videoThumbnail: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "1 cup Toor dal (split pigeon peas), boiled and mashed",
      "2 tbsp SPICORA Sambar Powder",
      "1 cup peeled sambar pearl onions",
      "1 drumstick cut into 2-inch pieces",
      "1/2 cup yellow pumpkin cubes",
      "Lemon-sized tamarind extracted in 1.5 cups warm water",
      "1 tsp SPICORA Whole Cumin & Mustard seeds for tadka",
      "Ghee, curry leaves, and asafoetida (hing)"
    ],
    instructions: [
      "Cook drumstick and shallots in tamarind water with a pinch of turmeric and salt until tender.",
      "Add mashed toor dal and stir in SPICORA Sambar Powder dissolved in 3 tbsp water.",
      "Bring sambar to a gentle simmer for 8 minutes to blend flavors.",
      "Prepare tempering: Heat 1 tbsp ghee in a tadka ladle, splutter mustard seeds, cumin seeds, dry chilli, and hing.",
      "Pour sizzling tadka over the bubbling sambar, cover immediately for 2 minutes to trap aroma, and serve with hot rice and ghee."
    ],
    spicoraPairing: {
      productId: "spicora-mas-sambar",
      productName: "Sambar Powder (Roasted Lentil Blend)",
      productSlug: "sambar-powder",
      tip: "Suggested pairing: Dissolving sambar powder in warm water before pouring into dal prevents lump formation."
    },
    verifiedTesting: true
  },
  {
    id: "rec-veg-biryani",
    title: "Nawabi Vegetable Dum Biryani",
    slug: "nawabi-vegetable-dum-biryani",
    category: "Traditional Veg",
    dietary: "Veg",
    prepTime: "25 mins",
    cookTime: "35 mins",
    servings: "4 servings",
    difficulty: "Medium",
    description: "Garden-fresh carrots, french beans, green peas, and marinated paneer cubes layered with saffron rice and fragrant spice blends.",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/5K7q2qQoXqM",
    videoDuration: "14:15",
    videoThumbnail: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "2 cups mixed vegetables (carrots, peas, cauliflower, beans)",
      "200g malai paneer cubes, lightly sautéed",
      "2 cups basmati rice",
      "1.5 tbsp SPICORA Biryani Masala",
      "1/2 cup curd",
      "2 tbsp ghee",
      "Pinch of saffron and fried brown onions"
    ],
    instructions: [
      "Sauté vegetables in ghee with SPICORA Biryani Masala and yogurt for 6-8 minutes until tender-crisp.",
      "Parboil basmati rice with green cardamom and bay leaf until 70% done.",
      "Assemble layers: vegetables and paneer at the base, fragrant rice on top.",
      "Garnish with saffron milk, fried onions, and mint. Dum cook for 20 minutes on a low flame."
    ],
    spicoraPairing: {
      productId: "spicora-mas-biryani",
      productName: "Biryani Masala",
      productSlug: "biryani-masala",
      tip: "Suggested pairing: Lightly dusting the paneer cubes with biryani masala before searing locks in spices."
    },
    verifiedTesting: true
  },

  // 3. TRADITIONAL NON-VEG RECIPES
  {
    id: "rec-gongura-mamsam",
    title: "Guntur Gongura Mamsam (Andhra Sour Mutton)",
    slug: "guntur-gongura-mamsam",
    category: "Traditional Non-Veg",
    dietary: "Non-Veg",
    prepTime: "30 mins",
    cookTime: "50 mins",
    servings: "4-5 servings",
    difficulty: "Master",
    description: "The most iconic Andhra meat curry. Tender baby mutton slow-braised with sour gongura leaves, stone-ground Guntur Sannam chillies, garlic cloves, and roasted coriander.",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/8eW0K6m81zA",
    videoDuration: "16:40",
    videoThumbnail: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "750g tender bone-in mutton pieces",
      "3 bunches fresh red-stemmed Gongura (sorrel) leaves",
      "2 tbsp SPICORA Mutton Masala",
      "1.5 tbsp SPICORA Red Chilli Powder (Guntur Sannam)",
      "1 tbsp SPICORA Coriander Powder",
      "1/2 tsp SPICORA Turmeric Powder",
      "2 large onions, sliced",
      "2 tbsp ginger-garlic paste",
      "4 tbsp groundnut oil",
      "Whole spices: 2 bay leaves, 4 cloves, 1 cinnamon stick"
    ],
    instructions: [
      "In a small pan, cook washed gongura leaves with 1 tbsp oil until wilted. Cool and coarse-grind into a rustic paste.",
      "Marinate mutton with turmeric, 1 tbsp SPICORA Mutton Masala, ginger-garlic paste, and salt for 30 minutes.",
      "Heat groundnut oil in a heavy pressure cooker or handi. Sauté whole spices and sliced onions until deep caramelized golden.",
      "Add marinated mutton and sear on high heat for 8 minutes to lock in meat juices.",
      "Add SPICORA Red Chilli Powder and Coriander Powder. Pour 1.5 cups water and pressure cook for 5-6 whistles until meat is fork-tender.",
      "Release pressure, stir in the cooked gongura paste and remaining SPICORA Mutton Masala.",
      "Simmer uncovered on medium-low flame for 10 minutes until the dark crimson oil separates and the gravy turns lusciously thick and tangy.",
      "Serve hot with steamed rice or ragi sankati."
    ],
    spicoraPairing: {
      productId: "spicora-mas-mutton",
      productName: "Mutton Masala & Guntur Chilli",
      productSlug: "mutton-masala",
      tip: "Suggested pairing: Stone flower (kalpasi) in the SPICORA Mutton Masala harmonizes the tart oxalic notes of gongura leaves with the rich mutton tallow."
    },
    verifiedTesting: true
  },
  {
    id: "rec-chicken-ghee-roast",
    title: "Kundapura Chicken Ghee Roast",
    slug: "kundapura-chicken-ghee-roast",
    category: "Traditional Non-Veg",
    dietary: "Non-Veg",
    prepTime: "25 mins",
    cookTime: "30 mins",
    servings: "4 servings",
    difficulty: "Master",
    description: "Coastal Karnataka's legendary delicacy. Succulent chicken pieces pan-roasted in copious amounts of pure desi cow ghee, tamarind, and a fiery roasted whole spice paste.",
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/6Y0h0o2yKzM",
    videoDuration: "13:30",
    videoThumbnail: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "700g chicken cut into small pieces",
      "5 tbsp pure Desi Cow Ghee",
      "12 whole dried chillies (8 Byadgi for deep color, 4 Guntur for heat)",
      "1 tbsp SPICORA Whole Coriander Seeds",
      "1 tsp SPICORA Whole Cumin Seeds",
      "1/2 tsp SPICORA Fennel Seeds",
      "1/2 tsp whole black peppercorns",
      "4 cloves & 1 small cinnamon piece",
      "1 marble-sized tamarind ball",
      "6 garlic cloves",
      "1/2 cup thick curd / yogurt for marination"
    ],
    instructions: [
      "Marinate chicken with yogurt, turmeric, 1 tsp chilli powder, and salt for 1 hour.",
      "Dry roast whole spices (coriander, cumin, fennel, pepper, cloves, cinnamon, dried chillies) over low flame until fragrant. Grind with tamarind and garlic into a smooth, thick masala paste.",
      "Heat 2 tbsp ghee in a heavy cast iron kadai. Sear the marinated chicken until 80% cooked and water evaporates. Remove and set aside.",
      "Add 3 tbsp ghee to the same kadai. Pour in the ground spice paste and fry patiently on low heat for 8-10 minutes until raw smell vanishes and glistening ghee floats on top.",
      "Return seared chicken to the kadai. Toss vigorously to coat every piece in the dark crimson ghee glaze.",
      "Roast dry on low heat for another 8 minutes until chicken is tender, dark-red, and succulent.",
      "Serve piping hot with neer dosa, parotta, or steamed rice."
    ],
    spicoraPairing: {
      productId: "spicora-wh-coriander-seeds",
      productName: "Whole Coriander & Tellicherry Pepper",
      productSlug: "coriander-seeds",
      tip: "Suggested pairing: Freshly dry-roasting whole spices in a cast-iron skillet creates the signature charred aromatic crust essential for true Ghee Roast."
    },
    verifiedTesting: true
  },
  {
    id: "rec-chepala-pulusu",
    title: "Nellore Chepala Pulusu (Claypot Fish Curry)",
    slug: "nellore-chepala-pulusu",
    category: "Traditional Non-Veg",
    dietary: "Non-Veg",
    prepTime: "20 mins",
    cookTime: "30 mins",
    servings: "4 servings",
    difficulty: "Medium",
    description: "Traditional coastal Andhra fish stew slow-cooked in an unglazed earthenware claypot with aged tamarind, roasted fenugreek-mustard powder, and Guntur chillies. Tastes even better the next day!",
    image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/5K7q2qQoXqM",
    videoDuration: "14:50",
    videoThumbnail: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "600g fresh river or seawater fish steaks (Korameenu / Rohu / Vanjaram)",
      "1 large lemon-sized aged black tamarind, soaked in 2.5 cups warm water",
      "2 tbsp SPICORA Red Chilli Powder (Guntur Sannam)",
      "1 tbsp SPICORA Coriander Powder",
      "1/2 tsp SPICORA Turmeric Powder",
      "1 tsp roasted methi-mustard powder (fenugreek & mustard seeds toasted and powdered)",
      "2 finely sliced onions",
      "4 green chillies slit",
      "10 garlic cloves crushed",
      "4 tbsp sesame oil, curry leaves, salt"
    ],
    instructions: [
      "In a traditional earthen claypot (matti kunda), heat sesame oil. Splutter mustard seeds, cumin seeds, fenugreek seeds, and curry leaves.",
      "Add sliced onions, crushed garlic, and green chillies. Sauté until translucent.",
      "Add turmeric, coriander powder, and SPICORA Guntur Chilli Powder.",
      "Pour in the thick strained tamarind extract and bring to a vigorous rolling boil for 10 minutes until raw tamarind aroma disappears.",
      "Gently slide in the fresh fish steaks in a single layer.",
      "Do NOT use a ladle to stir fish (it will break). Instead, hold the claypot with towels and swirl gently in circular motions.",
      "Simmer on medium-low flame for 12 minutes. Sprinkle the roasted methi-mustard powder over the curry.",
      "Rest the curry for 4 to 6 hours (or overnight) before eating—this allows the fish to absorb the tangy, spicy tamarind juices completely."
    ],
    spicoraPairing: {
      productId: "spicora-bl-fish-fry",
      productName: "Fish Fry Masala & Fenugreek",
      productSlug: "fish-fry-masala",
      tip: "Suggested pairing: The subtle bitterness of freshly toasted fenugreek balances the rich sourness of coastal tamarind pulusu."
    },
    verifiedTesting: true
  },
  {
    id: "rec-egg-roast",
    title: "Andhra Dhaba Style Spiced Egg Roast",
    slug: "andhra-dhaba-egg-roast",
    category: "Traditional Non-Veg",
    dietary: "Non-Veg",
    prepTime: "15 mins",
    cookTime: "20 mins",
    servings: "3-4 servings",
    difficulty: "Easy",
    description: "Hard-boiled eggs scored lengthwise and pan-seared until blistered, then coated in a rich, dark onion-tomato gravy with Guntur chillies, black pepper, and curry leaves.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/Pj15xZ7k4YQ",
    videoDuration: "9:10",
    videoThumbnail: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "6 farm-fresh eggs, hard-boiled and peeled",
      "1.5 tbsp SPICORA Andhra Special Masala",
      "1 tsp SPICORA Red Chilli Powder",
      "1/2 tsp SPICORA Turmeric Powder",
      "1/2 tsp freshly crushed Tellicherry Black Pepper",
      "2 large red onions, finely sliced",
      "2 ripe tomatoes, chopped",
      "1 tbsp ginger-garlic paste",
      "3 tbsp oil, curry leaves, fresh coriander"
    ],
    instructions: [
      "Make 3-4 shallow vertical slits on each boiled egg.",
      "In a pan, heat 1 tbsp oil with a pinch of turmeric and chilli powder. Fry eggs for 3 minutes until outer skin is blistered and golden. Set aside.",
      "Add remaining oil to the pan. Sauté onions and curry leaves until deep golden brown.",
      "Add ginger-garlic paste and tomatoes. Cook until oil starts separating from the masala.",
      "Stir in SPICORA Andhra Special Masala and black pepper.",
      "Add 1/4 cup water to create a thick coating sauce.",
      "Return blistered eggs to the pan and toss gently for 4 minutes until the dark spicy masala clings to every egg.",
      "Garnish with chopped coriander and serve with hot parottas or bagara rice."
    ],
    spicoraPairing: {
      productId: "spicora-bl-andhra-special",
      productName: "Andhra Special Masala",
      productSlug: "andhra-special-masala",
      tip: "Suggested pairing: Blistering the boiled eggs in hot spiced oil creates microscopic ridges that hold onto thick curry pastes."
    },
    verifiedTesting: true
  },
  {
    id: "rec-chicken-biryani",
    title: "Hyderabadi Dum Chicken Biryani",
    slug: "hyderabadi-dum-chicken-biryani",
    category: "Biryani",
    dietary: "Non-Veg",
    prepTime: "30 mins",
    cookTime: "45 mins",
    servings: "4-5 servings",
    difficulty: "Master",
    description: "Long-grain aged basmati rice layered with fragrant marinated chicken, caramelized onions (birista), fresh mint, saffron, and slow-cooked under dough dum seal.",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/95BCU1n268w",
    videoDuration: "18:20",
    videoThumbnail: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "750g bone-in chicken thighs and drumsticks",
      "500g aged long-grain Basmati rice (soaked 30 mins)",
      "1 cup thick hung curd / Greek yogurt",
      "2 tbsp ginger-garlic paste",
      "2 tbsp SPICORA Biryani Masala Powder",
      "3 drops SPICORA Biryani Flavour Liquid",
      "A pinch of SPICORA Kashmiri Mongra Saffron soaked in 3 tbsp warm milk",
      "1 cup golden fried onions (birista)",
      "1/2 cup fresh mint and coriander leaves",
      "3 tbsp pure cow ghee",
      "Whole spices for rice water: 1 bay leaf, 3 green cardamoms, 1 star anise, 1 inch cinnamon quill"
    ],
    instructions: [
      "Marinate chicken with curd, ginger-garlic paste, SPICORA Biryani Masala, half the fried onions, mint, coriander, 1 tbsp oil, and salt for at least 2 hours.",
      "Boil 3 liters of water with whole spices and generous salt. Add soaked rice and cook till precisely 70% done (about 5-6 minutes). Drain immediately.",
      "In a thick-bottomed handi, layer marinated chicken at the bottom.",
      "Spread the 70% parboiled rice evenly over the chicken.",
      "Drizzle saffron milk, pure ghee, remaining golden onions, and 3 drops of SPICORA Biryani Flavour Liquid on top.",
      "Seal the rim with wheat dough or double aluminum foil. Place heavy lid on top.",
      "Cook on high flame for 10 minutes, then place handi over a heavy iron tawa on low flame for 30 minutes (dum). Let rest for 15 minutes before gently fluffing from bottom to top."
    ],
    spicoraPairing: {
      productId: "spicora-mas-biryani",
      productName: "Biryani Masala & Flavour Drops",
      productSlug: "biryani-masala",
      tip: "Suggested pairing: Drizzle the Biryani Liquid Drops alongside saffron milk right before sealing for the signature royal banquet aroma."
    },
    verifiedTesting: true
  },
  {
    id: "rec-mutton-biryani",
    title: "Royal Awadhi Mutton Biryani",
    slug: "royal-awadhi-mutton-biryani",
    category: "Biryani",
    dietary: "Non-Veg",
    prepTime: "40 mins",
    cookTime: "1 hr 15 mins",
    servings: "5-6 servings",
    difficulty: "Master",
    description: "Melt-in-mouth tender baby goat meat simmered in a spiced yakhni stock, combined with saffron basmati rice, javitri, and slow braised on low heat.",
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/k4J5Hk2b2kM",
    videoDuration: "19:45",
    videoThumbnail: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "800g tender mutton / goat shoulder cuts",
      "500g premium basmati rice",
      "2 tbsp SPICORA Mutton Masala",
      "1 tbsp SPICORA Royal Biryani Spice Mix",
      "1 cup fried onions",
      "1 cup yogurt",
      "4 tbsp ghee",
      "Kashmiri Saffron strands in warm milk",
      "Whole spices: 2 black cardamoms, 4 cloves, 1 blade mace"
    ],
    instructions: [
      "Slow-cook the mutton pieces with SPICORA Mutton Masala, yogurt, fried onions, and water until 85% tender and thick rich gravy forms.",
      "Boil basmati rice with whole spices until 75% cooked. Drain well.",
      "Layer the succulent mutton gravy at the bottom of a heavy vessel, top with parboiled rice, saffron strands, and fresh ghee.",
      "Dum seal for 25 minutes on low flame. Rest before serving with mirchi ka salan."
    ],
    spicoraPairing: {
      productId: "spicora-mas-mutton",
      productName: "Mutton Masala & Royal Mix",
      productSlug: "mutton-masala",
      tip: "Suggested pairing: Use SPICORA Royal Biryani Spice Mix tied in a potli while parboiling the basmati rice."
    },
    verifiedTesting: true
  },
  {
    id: "rec-chicken-fry",
    title: "Guntur Kodi Vepudu (Andhra Chicken Fry)",
    slug: "guntur-kodi-vepudu",
    category: "Poultry",
    dietary: "Non-Veg",
    prepTime: "15 mins",
    cookTime: "25 mins",
    servings: "3-4 servings",
    difficulty: "Medium",
    description: "The pride of Andhra Pradesh dhabas. Tender chicken pieces roasted dry in a wok with fiery Guntur red chillies, curry leaves, and crunchy garlic cloves.",
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/W_5K5M5g1xA",
    videoDuration: "10:15",
    videoThumbnail: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "600g chicken pieces cut into small bites",
      "2 tbsp SPICORA Chicken Fry Masala",
      "1 tsp SPICORA Red Chilli Powder (Guntur Sannam)",
      "1/2 tsp SPICORA Turmeric Powder",
      "10-12 garlic cloves, crushed with skin",
      "3 sprigs fresh curry leaves",
      "3 green chillies slit",
      "3 tbsp peanut or sesame oil"
    ],
    instructions: [
      "Boil chicken with turmeric, a pinch of salt, and 1/4 cup water for 8 minutes until almost cooked through and water evaporates.",
      "In a heavy cast-iron kadai, heat oil. Add crushed garlic cloves, slit green chillies, and curry leaves until sizzling and aromatic.",
      "Add the par-cooked chicken and roast over medium-high heat for 6 minutes until chicken edges start browning.",
      "Sprinkle SPICORA Chicken Fry Masala and Guntur Red Chilli Powder. Toss vigorously so spices coat every morsel.",
      "Roast dry on low heat for another 5 minutes until dark golden, crispy, and thoroughly coated. Garnish with fried curry leaves."
    ],
    spicoraPairing: {
      productId: "spicora-bl-chicken-fry",
      productName: "Chicken Fry Masala & Guntur Chilli",
      productSlug: "chicken-fry-masala",
      tip: "Suggested pairing: Finish with a quick squeeze of fresh lime juice right after taking the pan off the heat."
    },
    verifiedTesting: true
  },
  {
    id: "rec-fish-fry",
    title: "Machilipatnam Crispy Fish Fry",
    slug: "machilipatnam-crispy-fish-fry",
    category: "Seafood",
    dietary: "Non-Veg",
    prepTime: "15 mins",
    cookTime: "12 mins",
    servings: "3 servings",
    difficulty: "Easy",
    description: "Fresh coastal kingfish (vanjaram) or pomfret slices coated in a tangy, spicy marinade and pan-fried to golden, flaky perfection.",
    image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/5K7q2qQoXqM",
    videoDuration: "8:30",
    videoThumbnail: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "500g fish steaks (Vanjaram / Pomfret / Surmai)",
      "2.5 tbsp SPICORA Fish Fry Masala",
      "1 tbsp ginger-garlic paste",
      "1 tbsp lemon juice",
      "1 tbsp water (to make thick paste)",
      "Coconut or groundnut oil for shallow frying"
    ],
    instructions: [
      "Rinse and pat dry fish steaks thoroughly with paper towels.",
      "Mix SPICORA Fish Fry Masala with ginger-garlic paste, lemon juice, and a splash of water into a smooth paste.",
      "Apply the spice paste generously on both sides of each steak. Let marinate for 20 minutes.",
      "Heat 3 tbsp oil in a flat iron skillet over medium heat.",
      "Place fish steaks carefully and shallow fry for 4-5 minutes per side until crust is crispy and fish flakes easily.",
      "Drain on kitchen paper and serve hot with sliced red onions and lemon wedges."
    ],
    spicoraPairing: {
      productId: "spicora-bl-fish-fry",
      productName: "Fish Fry Masala",
      productSlug: "fish-fry-masala",
      tip: "Suggested pairing: Ensure the pan is properly heated before placing fish so the delicate crust crisps instantly."
    },
    verifiedTesting: true
  },
  {
    id: "rec-prawn-fry",
    title: "Andhra Royyala Vepudu (Spiced Prawn Fry)",
    slug: "andhra-royyala-vepudu",
    category: "Seafood",
    dietary: "Non-Veg",
    prepTime: "15 mins",
    cookTime: "15 mins",
    servings: "3-4 servings",
    difficulty: "Medium",
    description: "Juicy prawns tossed with sweet caramelized shallots, fragrant curry leaves, roasted black pepper, and coastal Andhra spices.",
    image: "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/8eW0K6m81zA",
    videoDuration: "9:50",
    videoThumbnail: "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "400g cleaned and deveined tiger prawns",
      "2 tbsp SPICORA Prawn Fry Masala",
      "1/2 tsp SPICORA Turmeric Powder",
      "1 large onion finely chopped",
      "2 sprigs fresh curry leaves",
      "2 tbsp oil",
      "Fresh coriander leaves"
    ],
    instructions: [
      "Marinate cleaned prawns with turmeric and 1 tbsp SPICORA Prawn Fry Masala for 10 minutes.",
      "In a pan, sear prawns without oil for 3 minutes until excess moisture releases. Remove prawns and set aside.",
      "Heat oil in the same pan. Sauté onions and curry leaves until golden brown.",
      "Return prawns to the pan and add the remaining SPICORA Prawn Fry Masala.",
      "Stir-fry on high heat for 3-4 minutes until the sauce clings tightly to each prawn. Do not overcook. Garnish with coriander."
    ],
    spicoraPairing: {
      productId: "spicora-bl-prawn-fry",
      productName: "Prawn Fry Masala",
      productSlug: "prawn-fry-masala",
      tip: "Suggested pairing: Pairs sublimely with hot steamed sona masoori rice and tangy tomato rasam."
    },
    verifiedTesting: true
  },
  {
    id: "rec-andhra-curry",
    title: "Guntur Kodi Kura (Spicy Andhra Chicken Curry)",
    slug: "guntur-kodi-kura",
    category: "Andhra Curry",
    dietary: "Non-Veg",
    prepTime: "20 mins",
    cookTime: "30 mins",
    servings: "4 servings",
    difficulty: "Medium",
    description: "The traditional home-style Andhra chicken curry featuring a rich, onion-poppy gravy infused with Guntur chillies and roasted coriander.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1000&q=80",
    videoUrl: "https://www.youtube.com/embed/W_5K5M5g1xA",
    videoDuration: "12:40",
    videoThumbnail: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    ingredients: [
      "700g chicken cut into curry pieces",
      "2 tbsp SPICORA Andhra Special Masala",
      "1 tbsp SPICORA Coriander Powder",
      "1/2 tsp SPICORA Turmeric Powder",
      "2 finely sliced onions",
      "2 chopped ripe tomatoes",
      "2 tbsp ginger-garlic paste",
      "3 tbsp groundnut oil"
    ],
    instructions: [
      "Heat oil in a heavy pot. Sauté onions until golden translucent.",
      "Add ginger-garlic paste and sauté until raw smell dissipates.",
      "Add chopped tomatoes, turmeric, and SPICORA Andhra Special Masala. Cook until oil separates.",
      "Add chicken pieces and sear in the gravy for 5 minutes.",
      "Pour in 1 cup warm water, cover with lid, and simmer on medium flame for 20 minutes until chicken is tender and gravy is thick and reddish-brown.",
      "Garnish with chopped coriander and serve with steamed rice or ragi sankati."
    ],
    spicoraPairing: {
      productId: "spicora-bl-andhra-special",
      productName: "Andhra Special Masala",
      productSlug: "andhra-special-masala",
      tip: "Suggested pairing: Savor with dollops of fresh melted desi ghee over hot rice."
    },
    verifiedTesting: true
  }
];

export function getRecipeBySlug(slug: string): Recipe | undefined {
  return RECIPES.find((r) => r.slug === slug);
}
