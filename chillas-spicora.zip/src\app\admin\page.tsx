"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  BarChart3,
  Package,
  ShoppingBag,
  Users,
  MessageSquare,
  Tag,
  Building2,
  TrendingUp,
  AlertTriangle,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Eye,
  RefreshCw,
  Search,
  SlidersHorizontal,
  Shield,
  Lock,
  ArrowRight
} from "lucide-react";
import { useSpicora } from "@/context/SpicoraContext";
import { formatINR } from "@/lib/utils";
import { Product, ProductStatus } from "@/types";
import { DEFAULT_COUPONS } from "@/data/coupons";

export default function AdminPage() {
  const {
    products,
    updateProduct,
    createProduct,
    deleteProduct,
    resetProductsToDefault,
    orders,
    updateOrderStatus,
    b2bEnquiries,
    updateB2BStatus,
    reviews,
    updateReviewStatus,
    user,
  } = useSpicora();

  // Navigation tab in Admin
  const [activeTab, setActiveTab] = useState<"overview" | "products" | "orders" | "b2b" | "reviews" | "coupons">("overview");

  // Product edit modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [productSearch, setProductSearch] = useState("");
  const [productCategoryFilter, setProductCategoryFilter] = useState("all");
  const [adminAuthBypass, setAdminAuthBypass] = useState(true); // default true for demo evaluation

  // Analytics Metrics
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = orders.length;
  const activeProductsCount = products.filter((p) => p.status === "Active").length;
  const developmentProductsCount = products.filter((p) => p.status === "Development").length;
  const comingSoonProductsCount = products.filter((p) => p.status === "Coming Soon").length;
  const b2bCount = b2bEnquiries.length;

  // Filtered Products in Admin Table
  const filteredProducts = products.filter((p) => {
    if (productCategoryFilter !== "all" && p.categoryId !== productCategoryFilter) return false;
    if (productSearch.trim()) {
      const q = productSearch.toLowerCase();
      return p.name.toLowerCase().includes(q) || p.slug.toLowerCase().includes(q);
    }
    return true;
  });

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    if (isCreatingNew) {
      createProduct(editingProduct);
      setIsCreatingNew(false);
    } else {
      updateProduct(editingProduct);
    }
    setEditingProduct(null);
  };

  const handleStartCreateProduct = () => {
    const newProd: Product = {
      id: "spicora-custom-" + Date.now(),
      name: "New Artisanal Spice Blend",
      slug: "new-artisanal-spice-blend-" + Date.now(),
      tagline: "Custom Guntur Batch",
      categoryId: "masala-powders",
      categoryName: "Traditional Masala Powders",
      packagingType: "powder",
      shortDescription: "Chef crafted small-batch spice formulation.",
      description: "Slow-roasted and milled to order using verified Guntur spice ingredients.",
      images: [
        "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80"
      ],
      variants: [
        { id: "var-1", size: "100 g", price: 120, compareAtPrice: 150, inStock: true, sku: "SPIC-CUST-100" },
        { id: "var-2", size: "200 g", price: 220, compareAtPrice: 280, inStock: true, sku: "SPIC-CUST-200" }
      ],
      status: "Development",
      origin: "Guntur, Andhra Pradesh",
      flavourNotes: ["Warm Aromatic", "Earthy"],
      ingredients: ["Coriander", "Cumin", "Chilli", "Black Pepper"],
      storageInstructions: "Store sealed in dry cupboard.",
      complianceNotice: "Proposed pilot batch under evaluation.",
      rating: 5.0,
      reviewCount: 0,
      isFeatured: false
    };
    setEditingProduct(newProd);
    setIsCreatingNew(true);
  };

  return (
    <div className="bg-[#FCFBF7] min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Admin Header */}
        <div className="bg-[#174D35] rounded-3xl p-6 sm:p-8 text-white border border-[#D4A84F]/40 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="bg-[#D4A84F] text-[#174D35] text-[10px] font-black px-2.5 py-0.5 rounded uppercase tracking-wider">
                ADMIN CONSOLE
              </span>
              <span className="text-xs text-[#D4A84F] font-mono">Guntur Mill Ops v1.0</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl font-extrabold text-white">
              CHILLA&apos;S SPICORA Enterprise Manager
            </h1>
            <p className="text-xs text-stone-300 font-light">
              Live control over catalogue, product statuses (Active, Development, Coming Soon, Out of Stock, Discontinued), customer orders, and wholesale leads.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (confirm("Reset catalog and orders to default demo settings?")) {
                  resetProductsToDefault();
                  alert("Product catalog has been refreshed to initial defaults.");
                }
              }}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl border border-white/20 flex items-center gap-1.5 transition-colors"
              title="Reset Catalog to Defaults"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#D4A84F]" />
              Reset Demo Data
            </button>
            <Link
              href="/shop"
              className="px-4 py-2 bg-[#D4A84F] text-[#174D35] text-xs font-bold rounded-xl hover:bg-[#F3DC9B] flex items-center gap-1.5 transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              View Live Store
            </Link>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-stone-200 overflow-x-auto no-scrollbar">
          {[
            { id: "overview", label: "Executive Analytics", icon: BarChart3 },
            { id: "products", label: `Products (${products.length})`, icon: Package },
            { id: "orders", label: `Orders (${orders.length})`, icon: ShoppingBag },
            { id: "b2b", label: `B2B Wholesale (${b2bEnquiries.length})`, icon: Building2 },
            { id: "reviews", label: `Reviews (${reviews.length})`, icon: MessageSquare },
            { id: "coupons", label: "Coupons & Campaigns", icon: Tag },
          ].map((tab) => {
            const Icon = tab.icon;
            const isCurrent = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                  isCurrent
                    ? "bg-[#174D35] text-white shadow-sm"
                    : "text-stone-600 hover:text-[#174D35] hover:bg-stone-100"
                }`}
              >
                <Icon className={`w-4 h-4 ${isCurrent ? "text-[#D4A84F]" : "text-stone-400"}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 1. OVERVIEW / ANALYTICS */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                  Simulated Gross Sales
                </span>
                <div className="font-serif font-black text-3xl text-[#174D35]">
                  {formatINR(totalRevenue)}
                </div>
                <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  +18.4% from last batch
                </span>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                  Orders Processed
                </span>
                <div className="font-serif font-black text-3xl text-[#174D35]">
                  {totalOrdersCount}
                </div>
                <span className="text-[11px] text-stone-400">
                  Across 6 Indian States
                </span>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                  Live Catalogue
                </span>
                <div className="font-serif font-black text-3xl text-[#174D35]">
                  {products.length} Formulations
                </div>
                <div className="text-[11px] text-stone-500 space-x-2">
                  <span className="text-emerald-700 font-bold">{activeProductsCount} Active</span>
                  <span>•</span>
                  <span className="text-amber-700 font-bold">{developmentProductsCount} In Dev</span>
                  <span>•</span>
                  <span className="text-blue-700 font-bold">{comingSoonProductsCount} Soon</span>
                </div>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                  B2B Institutional Leads
                </span>
                <div className="font-serif font-black text-3xl text-[#174D35]">
                  {b2bCount} Inquiries
                </div>
                <span className="text-[11px] text-[#87571F] font-semibold">
                  Hotels, Caterers & Chai Chains
                </span>
              </div>
            </div>

            {/* Recent Orders Preview */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <h3 className="font-serif font-bold text-lg text-[#174D35]">
                  Recent Customer Spice Orders
                </h3>
                <button
                  onClick={() => setActiveTab("orders")}
                  className="text-xs font-bold text-[#174D35] hover:text-[#D4A84F] flex items-center gap-1"
                >
                  Manage All Orders <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-stone-100">
                {orders.slice(0, 4).map((order) => (
                  <div key={order.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-stone-900">{order.orderNumber} • {order.customer.fullName}</div>
                      <div className="text-stone-500">{order.customer.city}, {order.customer.state} ({order.items.length} items)</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-serif font-bold text-sm text-[#174D35]">{formatINR(order.total)}</span>
                      <span className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded font-bold text-[10px]">
                        {order.orderStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 2. PRODUCT MANAGEMENT (CRUD & STATUS TOGGLES) */}
        {activeTab === "products" && (
          <div className="space-y-6">
            <div className="bg-white p-4 sm:p-6 rounded-3xl border border-[#D4A84F]/30 shadow-md space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-xl focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <select
                    value={productCategoryFilter}
                    onChange={(e) => setProductCategoryFilter(e.target.value)}
                    className="p-2 text-xs border border-stone-200 rounded-xl focus:outline-none"
                  >
                    <option value="all">All Categories (48)</option>
                    <option value="liquid-flavours">Liquid Flavours (6)</option>
                    <option value="masala-powders">Masala Powders (12)</option>
                    <option value="special-blends">Special Blends (10)</option>
                    <option value="whole-spices">Whole Spices (14)</option>
                    <option value="combo-packs">Combo Packs (6)</option>
                  </select>

                  <button
                    onClick={handleStartCreateProduct}
                    className="px-4 py-2 bg-[#174D35] text-white text-xs font-bold rounded-xl hover:bg-[#13422E] flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Product
                  </button>
                </div>
              </div>

              {/* Products Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-stone-700">
                  <thead className="bg-stone-50 text-stone-500 font-semibold border-y border-stone-200">
                    <tr>
                      <th className="py-3 px-3">Product</th>
                      <th className="py-3 px-3">Category</th>
                      <th className="py-3 px-3">Pack Sizes</th>
                      <th className="py-3 px-3">Base Price</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-stone-50/60 transition-colors">
                        <td className="py-3 px-3 flex items-center gap-3">
                          <div className="relative w-10 h-10 rounded-lg overflow-hidden bg-stone-100 flex-shrink-0">
                            <Image src={p.images[0]} alt={p.name} fill className="object-cover" />
                          </div>
                          <div>
                            <span className="font-bold text-stone-900 block">{p.name}</span>
                            <span className="text-[10px] text-stone-400 font-mono">{p.slug}</span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-stone-600 font-medium">
                          {p.categoryName}
                        </td>
                        <td className="py-3 px-3 text-stone-500">
                          {p.variants.map((v) => v.size.split("(")[0]).join(", ")}
                        </td>
                        <td className="py-3 px-3 font-serif font-bold text-[#174D35]">
                          {formatINR(p.variants[0]?.price || 0)}
                        </td>
                        <td className="py-3 px-3">
                          <select
                            value={p.status}
                            onChange={(e) => {
                              const updated = { ...p, status: e.target.value as ProductStatus };
                              updateProduct(updated);
                            }}
                            className={`px-2 py-1 rounded-md text-[10px] font-bold border ${
                              p.status === "Active"
                                ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                                : p.status === "Development"
                                ? "bg-amber-50 text-amber-800 border-amber-300"
                                : p.status === "Coming Soon"
                                ? "bg-blue-50 text-blue-800 border-blue-300"
                                : "bg-stone-100 text-stone-700 border-stone-300"
                            }`}
                          >
                            <option value="Active">Active (Orderable)</option>
                            <option value="Development">Development</option>
                            <option value="Coming Soon">Coming Soon</option>
                            <option value="Out of Stock">Out of Stock</option>
                            <option value="Discontinued">Discontinued</option>
                          </select>
                        </td>
                        <td className="py-3 px-3 text-right space-x-2">
                          <button
                            onClick={() => {
                              setEditingProduct(p);
                              setIsCreatingNew(false);
                            }}
                            className="p-1.5 text-stone-500 hover:text-[#174D35] rounded hover:bg-stone-100"
                            title="Edit Product"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Delete product "${p.name}"?`)) {
                                deleteProduct(p.id);
                              }
                            }}
                            className="p-1.5 text-stone-400 hover:text-red-600 rounded hover:bg-stone-100"
                            title="Delete Product"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Product Edit Modal */}
            {editingProduct && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-5 max-h-[90vh] overflow-y-auto border border-[#D4A84F]/40 shadow-2xl">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                    <h3 className="font-serif font-bold text-lg text-[#174D35]">
                      {isCreatingNew ? "Add New Spice Formulation" : `Edit "${editingProduct.name}"`}
                    </h3>
                    <button
                      onClick={() => setEditingProduct(null)}
                      className="text-stone-400 hover:text-stone-600"
                    >
                      <XCircle className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-semibold text-stone-700 mb-1">Product Name</label>
                        <input
                          type="text"
                          required
                          value={editingProduct.name}
                          onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-stone-700 mb-1">Category</label>
                        <select
                          value={editingProduct.categoryId}
                          onChange={(e) => {
                            const catMap: Record<string, string> = {
                              "liquid-flavours": "Signature Liquid Flavours",
                              "masala-powders": "Traditional Masala Powders",
                              "special-blends": "Special Spice Blends",
                              "whole-spices": "Whole Spices",
                              "combo-packs": "Combo Packs",
                            };
                            setEditingProduct({
                              ...editingProduct,
                              categoryId: e.target.value,
                              categoryName: catMap[e.target.value] || "Custom",
                            });
                          }}
                          className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none"
                        >
                          <option value="liquid-flavours">Signature Liquid Flavours</option>
                          <option value="masala-powders">Traditional Masala Powders</option>
                          <option value="special-blends">Special Spice Blends</option>
                          <option value="whole-spices">Whole Spices</option>
                          <option value="combo-packs">Combo Packs</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-semibold text-stone-700 mb-1">Base Demo Price (₹)</label>
                        <input
                          type="number"
                          required
                          value={editingProduct.variants[0]?.price || 100}
                          onChange={(e) => {
                            const newPrice = Number(e.target.value);
                            const updatedVariants = [...editingProduct.variants];
                            if (updatedVariants[0]) updatedVariants[0].price = newPrice;
                            setEditingProduct({ ...editingProduct, variants: updatedVariants });
                          }}
                          className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-stone-700 mb-1">Status</label>
                        <select
                          value={editingProduct.status}
                          onChange={(e) =>
                            setEditingProduct({
                              ...editingProduct,
                              status: e.target.value as ProductStatus,
                            })
                          }
                          className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none"
                        >
                          <option value="Active">Active (Orderable Demo)</option>
                          <option value="Development">Development</option>
                          <option value="Coming Soon">Coming Soon</option>
                          <option value="Out of Stock">Out of Stock</option>
                          <option value="Discontinued">Discontinued</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">Short Description</label>
                      <input
                        type="text"
                        value={editingProduct.shortDescription}
                        onChange={(e) =>
                          setEditingProduct({ ...editingProduct, shortDescription: e.target.value })
                        }
                        className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">Full Detailed Story</label>
                      <textarea
                        rows={3}
                        value={editingProduct.description}
                        onChange={(e) =>
                          setEditingProduct({ ...editingProduct, description: e.target.value })
                        }
                        className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none"
                      />
                    </div>

                    <div className="flex justify-end gap-3 pt-3 border-t border-stone-100">
                      <button
                        type="button"
                        onClick={() => setEditingProduct(null)}
                        className="px-4 py-2 border border-stone-300 rounded-xl text-stone-700 hover:bg-stone-100"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2 bg-[#174D35] text-white font-bold rounded-xl hover:bg-[#13422E]"
                      >
                        Save Changes
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 3. ORDERS MANAGEMENT */}
        {activeTab === "orders" && (
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#D4A84F]/30 shadow-md space-y-6">
            <h3 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
              Customer Order Fulfillment & Shipping
            </h3>

            <div className="space-y-4">
              {orders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-5 rounded-2xl border border-stone-200 bg-stone-50/50 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <span className="font-mono font-bold text-sm text-[#174D35]">
                        {ord.orderNumber}
                      </span>
                      <span className="text-stone-500 ml-2">
                        • {ord.customer.fullName} ({ord.customer.phone})
                      </span>
                      <p className="text-stone-400 text-[11px] mt-0.5">
                        Address: {ord.customer.addressLine1}, {ord.customer.city}, {ord.customer.state} - {ord.customer.pincode}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-serif font-bold text-sm text-[#174D35]">
                        {formatINR(ord.total)}
                      </span>
                      <select
                        value={ord.orderStatus}
                        onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold border border-stone-300 bg-white"
                      >
                        <option value="Placed">Placed</option>
                        <option value="Processing">Processing</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Out for Delivery">Out for Delivery</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  {/* Items summary */}
                  <div className="text-[11px] text-stone-600 flex flex-wrap gap-2 pt-1 border-t border-stone-200/60">
                    {ord.items.map((it, i) => (
                      <span key={i} className="bg-white px-2 py-0.5 rounded border border-stone-200">
                        {it.product.name} ({it.variant.size}) × {it.quantity}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. B2B WHOLESALE LEADS */}
        {activeTab === "b2b" && (
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#D4A84F]/30 shadow-md space-y-6">
            <h3 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
              Institutional B2B Wholesale Pipeline
            </h3>

            <div className="space-y-4">
              {b2bEnquiries.map((enq) => (
                <div
                  key={enq.id}
                  className="p-5 rounded-2xl border border-stone-200 bg-stone-50 space-y-3 text-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#174D35]">
                        {enq.companyName}
                      </h4>
                      <p className="text-stone-600">
                        Contact: <strong>{enq.contactPerson}</strong> • {enq.email} • {enq.phone}
                      </p>
                      <p className="text-stone-400 text-[11px]">
                        Segment: {enq.businessType} • Location: {enq.city}, {enq.state} {enq.gstin && `• GSTIN: ${enq.gstin}`}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="bg-[#D4A84F]/20 text-[#87571F] font-semibold px-2.5 py-1 rounded-md text-[11px]">
                        {enq.estimatedVolume}
                      </span>
                      <select
                        value={enq.status}
                        onChange={(e) => updateB2BStatus(enq.id, e.target.value as any)}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold border border-stone-300 bg-white"
                      >
                        <option value="New">New Lead</option>
                        <option value="Under Review">Under Review</option>
                        <option value="Quotation Sent">Quotation Sent</option>
                        <option value="Active Customer">Active Customer</option>
                      </select>
                    </div>
                  </div>

                  {enq.notes && (
                    <p className="text-[11px] text-stone-500 bg-white p-2.5 rounded-lg border border-stone-200 italic">
                      &ldquo;{enq.notes}&rdquo;
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. REVIEWS MODERATION */}
        {activeTab === "reviews" && (
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#D4A84F]/30 shadow-md space-y-6">
            <h3 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
              Customer Taste Panel Reviews
            </h3>

            <div className="space-y-4">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="p-4 rounded-2xl border border-stone-200 bg-stone-50 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <strong className="text-stone-900 font-bold">{rev.author}</strong>
                      <span className="text-stone-400 ml-2">({rev.date})</span>
                    </div>
                    <select
                      value={rev.status || "Approved"}
                      onChange={(e) => updateReviewStatus(rev.id, e.target.value as any)}
                      className="px-2 py-1 rounded text-[11px] border border-stone-300 bg-white"
                    >
                      <option value="Approved">Approved</option>
                      <option value="Pending">Pending</option>
                      <option value="Flagged">Flagged</option>
                    </select>
                  </div>
                  <h4 className="font-bold text-[#174D35]">{rev.title}</h4>
                  <p className="text-stone-600 leading-relaxed">{rev.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. COUPONS & CAMPAIGNS */}
        {activeTab === "coupons" && (
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#D4A84F]/30 shadow-md space-y-6">
            <h3 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
              Active Promo Campaigns
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {DEFAULT_COUPONS.map((cpn) => (
                <div
                  key={cpn.code}
                  className="p-5 rounded-2xl border border-[#D4A84F]/30 bg-[#FFF8E9]/50 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-sm text-[#174D35] bg-[#174D35]/10 px-2.5 py-1 rounded">
                      {cpn.code}
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                      Active
                    </span>
                  </div>
                  <h4 className="font-serif font-bold text-base text-[#174D35]">{cpn.discountPercent}% OFF</h4>
                  <p className="text-xs text-stone-600">{cpn.description}</p>
                  <div className="text-[11px] text-stone-400 pt-1">
                    Min Order: ₹{cpn.minOrderValue} | Max Discount: ₹{cpn.maxDiscount}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
