"use client";

import React from "react";
import { X, Play, Clock, Sparkles, ShoppingBag, ExternalLink } from "lucide-react";
import Link from "next/link";
import { Recipe } from "@/types";

interface RecipeVideoModalProps {
  recipe: Recipe | null;
  isOpen: boolean;
  onClose: () => void;
}

export function RecipeVideoModal({ recipe, isOpen, onClose }: RecipeVideoModalProps) {
  if (!isOpen || !recipe) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#101713] rounded-3xl border border-[#D4A84F]/40 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-[#0C120F] border-b border-[#D4A84F]/25 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#D4A84F] text-[#0C120F] flex items-center justify-center font-bold">
              <Play className="w-4 h-4 fill-current ml-0.5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-[#D4A84F] uppercase tracking-wider block">
                SPICORA CULINARY MASTERCLASS • {recipe.videoDuration || "10 mins"}
              </span>
              <h3 className="font-serif font-bold text-base sm:text-lg text-white line-clamp-1">
                {recipe.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Embed Frame */}
        <div className="relative aspect-video w-full bg-black">
          {recipe.videoUrl ? (
            <iframe
              src={`${recipe.videoUrl}?autoplay=1&rel=0&modestbranding=1`}
              title={recipe.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-center p-6 text-stone-400 space-y-3">
              <Play className="w-12 h-12 text-[#D4A84F] opacity-75" />
              <p className="text-sm">Video masterclass stream loading for {recipe.title}...</p>
            </div>
          )}
        </div>

        {/* Bottom Paired Spice Action Bar */}
        <div className="p-4 sm:p-5 bg-[#0C120F] border-t border-[#D4A84F]/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-[11px] font-bold text-[#D4A84F] uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              Featured Master Spice in this Video
            </div>
            <p className="text-xs text-stone-300">
              {recipe.spicoraPairing.productName} — {recipe.spicoraPairing.tip}
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Link
              href={`/shop/${recipe.spicoraPairing.productSlug}`}
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 flex items-center justify-center gap-1.5 shadow-md"
            >
              <ShoppingBag className="w-4 h-4" />
              Shop This Spice
            </Link>

            <Link
              href={`/recipes/${recipe.slug}`}
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-white/20 hover:border-[#D4A84F] text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              Full Recipe Method
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
