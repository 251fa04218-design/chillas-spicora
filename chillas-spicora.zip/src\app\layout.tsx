import type { Metadata } from "next";
import "./globals.css";
import { SpicoraProvider } from "@/context/SpicoraContext";
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { WhatsAppButton } from "@/components/ui/WhatsAppButton";

export const metadata: Metadata = {
  title: "CHILLA'S SPICORA | The Essence of Indian Spices (Guntur, AP)",
  description:
    "Premium Indian spice and flavour company from Guntur, Andhra Pradesh. Authentic cold-extracted liquid spice drops, stone-ground masala powders, and Grade-A whole botanicals.",
  keywords: [
    "Chillas Spicora",
    "Guntur chilli",
    "Indian spices",
    "liquid chai masala drops",
    "biryani flavour liquid",
    "Andhra masala",
    "Tellicherry black pepper",
    "Idukki cardamom",
    "pure turmeric powder"
  ],
  authors: [{ name: "CHILLA'S SPICORA" }],
  openGraph: {
    title: "CHILLA'S SPICORA | The Essence of Indian Spices",
    description: "Premium Indian spice and flavour company rooted in Guntur, Andhra Pradesh.",
    url: "https://spicora.com",
    siteName: "CHILLA'S SPICORA",
    images: [
      {
        url: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=80",
        width: 1200,
        height: 630,
        alt: "CHILLA'S SPICORA Premium Indian Spices",
      },
    ],
    locale: "en_IN",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen flex flex-col antialiased selection:bg-[#D4A84F] selection:text-[#174D35]">
        <SpicoraProvider>
          <CartProvider>
            <WishlistProvider>
              <Navbar />
              <main className="flex-1">{children}</main>
              <CartDrawer />
              <WhatsAppButton />
              <Footer />
            </WishlistProvider>
          </CartProvider>
        </SpicoraProvider>
      </body>
    </html>
  );
}
