import { Review } from "@/types";

export const INITIAL_REVIEWS: Review[] = [
  {
    id: "rev-1",
    productId: "spicora-liq-chai",
    author: "Raghava Rao V.",
    rating: 5,
    title: "Unbelievable Chai Aroma with Just 2 Drops!",
    comment: "I was skeptical about liquid chai masala at first. But 2 drops into my morning milk tea changed my mind forever. The aroma of freshly crushed green cardamom and ginger without any grit at the bottom of the cup is extraordinary.",
    date: "14 Nov 2026",
    verifiedPurchase: true,
    isDemo: true,
    status: "Approved"
  },
  {
    id: "rev-2",
    productId: "spicora-mas-red-chilli",
    author: "Sowmya Reddy",
    rating: 5,
    title: "Authentic Guntur Sannam Heat and Color",
    comment: "Being from Guntur myself, finding genuine unadulterated chilli powder outside Andhra was always disappointing. CHILLA'S SPICORA Red Chilli powder has the true crimson hue and clean heat without any artificial color. 10/10.",
    date: "09 Nov 2026",
    verifiedPurchase: true,
    isDemo: true,
    status: "Approved"
  },
  {
    id: "rev-3",
    productId: "spicora-bl-biryani",
    author: "Chef Tariq M.",
    rating: 5,
    title: "Commercial-Grade Shahi Dum Flavor",
    comment: "The balance of javitri, shahi jeera, and cold-extracted cardamom in the Biryani Liquid and Masala is exceptional. We used it for our catering feast and guests couldn't stop asking about the aroma.",
    date: "02 Nov 2026",
    verifiedPurchase: true,
    isDemo: true,
    status: "Approved"
  },
  {
    id: "rev-4",
    productId: "spicora-wh-green-cardamom",
    author: "Meenakshi Sundaram",
    rating: 5,
    title: "Plump 8mm Pods with Intact Volatile Oils",
    comment: "Every single green cardamom pod was plump, vibrant green, and filled with dark aromatic seeds. Cracking open just two pods perfumed our entire kitchen.",
    date: "28 Oct 2026",
    verifiedPurchase: true,
    isDemo: true,
    status: "Approved"
  },
  {
    id: "rev-5",
    productId: "spicora-cb-biryani-special",
    author: "Anand K. Sharma",
    rating: 5,
    title: "The Ultimate Gift for Biryani Lovers",
    comment: "The packaging in forest green and gold is fit for royalty. Comes with authentic saffron and liquid drops. Prepared our Sunday dum biryani and the taste was restaurant-quality.",
    date: "22 Oct 2026",
    verifiedPurchase: true,
    isDemo: true,
    status: "Approved"
  }
];
