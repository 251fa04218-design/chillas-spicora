"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  MapPin,
  Phone,
  Mail,
  MessageCircle,
  Clock,
  Send,
  CheckCircle2,
  ChevronDown,
  Sparkles,
  ShieldCheck
} from "lucide-react";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "General Inquiry",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const faqs = [
    {
      q: "How do I use SPICORA Liquid Flavour Drops in cooking and tea?",
      a: "Our liquid drops are high-intensity botanical extracts. For Chai, add 2 to 3 drops per cup right before straining. For Biryani or Curries, add 4 to 6 drops during the final simmer or dum stage so the delicate top-note aromas remain intact.",
    },
    {
      q: "Where are CHILLA'S SPICORA spices sourced and packaged?",
      a: "Our spices are sourced from single-origin terroirs across India, with core chillies, coriander, and turmeric coming directly from Guntur and surrounding Andhra districts. Packaging and extraction occur in our facility in Guntur, Andhra Pradesh.",
    },
    {
      q: "Are these pack sizes confirmed for commercial sale?",
      a: "The pack configurations (30ml/50ml liquid vials, 50g–500g pouches) represent our planned commercial offerings. Final commercial pricing and pack confirmation will be affirmed following laboratory validation and FSSAI statutory labelling.",
    },
    {
      q: "Do you supply bulk volumes to restaurants and tea cafe franchises?",
      a: "Yes! We have a dedicated B2B institutional division providing food-service drums, wholesale sacks, and custom liquid batches for caterers, hotels, and cafes. Visit our Wholesale section for custom quotation requests.",
    },
  ];

  return (
    <div className="bg-[#FCFBF7] min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#174D35] to-[#0f3424] rounded-3xl p-8 sm:p-12 text-white border border-[#D4A84F]/40 shadow-xl space-y-3 relative overflow-hidden text-center md:text-left">
          <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#D4A84F] block">
            GUNTUR HEADQUARTERS & CONCIERGE
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-extrabold text-white">
            Get in Touch with Our Spice Masters
          </h1>
          <p className="text-sm text-stone-200 max-w-2xl font-light">
            Have questions regarding recipe pairings, bulk catering orders, or distribution partnerships? We welcome you to connect with our team in Guntur.
          </p>
        </div>

        {/* Info Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-xs space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#174D35] text-[#D4A84F] flex items-center justify-center">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="font-serif font-bold text-base text-[#174D35]">Our Heritage Facility</h3>
            <p className="text-xs text-stone-600 leading-relaxed font-light">
              Plot 42, Spicora Heritage Corridor, Near Spice Board Market Yard, Guntur, Andhra Pradesh - 522002, India.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-xs space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#174D35] text-[#D4A84F] flex items-center justify-center">
              <Phone className="w-6 h-6" />
            </div>
            <h3 className="font-serif font-bold text-base text-[#174D35]">Customer Care & WhatsApp</h3>
            <p className="text-xs text-stone-600 leading-relaxed font-light">
              Toll-Free & Direct: +91 98480 12345<br />
              WhatsApp Concierge: +91 98480 54321<br />
              Mon - Sat: 9:00 AM - 7:00 PM IST
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-[#D4A84F]/30 shadow-xs space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#174D35] text-[#D4A84F] flex items-center justify-center">
              <Mail className="w-6 h-6" />
            </div>
            <h3 className="font-serif font-bold text-base text-[#174D35]">Electronic Inquiries</h3>
            <p className="text-xs text-stone-600 leading-relaxed font-light">
              Consumer Support: care@spicora.in<br />
              Wholesale & Institutional: b2b@spicora.in<br />
              Founder&apos;s Desk: ramesh@spicora.in
            </p>
          </div>
        </div>

        {/* Contact Form & WhatsApp Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-10 border border-[#D4A84F]/30 shadow-md">
            {submitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#174D35] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#174D35]">
                  Message Successfully Dispatched
                </h3>
                <p className="text-xs text-stone-600 max-w-sm mx-auto">
                  Thank you for reaching out to CHILLA&apos;S SPICORA. A customer relations specialist will reply within 12 business hours.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 rounded-full bg-[#174D35] text-white text-xs font-bold uppercase tracking-wider"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <h2 className="font-serif font-bold text-xl text-[#174D35]">
                    Send Us an Inquiry
                  </h2>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Fill out the form below and we will respond promptly.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Your Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sowmya Rao"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      placeholder="sowmya@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Phone Number</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98480 12345"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Inquiry Topic</label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    >
                      <option value="General Inquiry">General Product Inquiry</option>
                      <option value="Recipe Assistance">Culinary / Recipe Pairing</option>
                      <option value="Wholesale">Wholesale & Catering Request</option>
                      <option value="Press">Media / Press & Export</option>
                    </select>
                  </div>
                </div>

                <div className="text-xs">
                  <label className="block font-semibold text-stone-700 mb-1">Your Message</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Tell us how we can assist you..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-[#174D35] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#13422E] shadow-md flex items-center justify-center gap-2 transition-colors"
                >
                  <Send className="w-4 h-4 text-[#D4A84F]" />
                  Transmit Inquiry
                </button>
              </form>
            )}
          </div>

          {/* WhatsApp Direct & Quick FAQ */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-emerald-800 text-white p-6 sm:p-8 rounded-3xl border border-[#D4A84F]/40 shadow-xl space-y-4">
              <div className="w-12 h-12 rounded-full bg-emerald-700 text-white flex items-center justify-center shadow-inner">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h3 className="font-serif font-bold text-xl text-white">
                Instant WhatsApp Concierge
              </h3>
              <p className="text-xs text-stone-200 leading-relaxed font-light">
                Need immediate assistance choosing the right chai drop ratio, biryani marinade spice, or delivery updates? Chat live with our Guntur culinary desk.
              </p>
              <a
                href="https://wa.me/919848012345?text=Namaskaram%20Spicora%20Team!%20I%20have%20an%20inquiry."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-emerald-900 font-bold text-xs uppercase tracking-wider hover:bg-stone-100 shadow transition-all"
              >
                Chat on WhatsApp Now
              </a>
            </div>

            {/* Interactive FAQs Accordion */}
            <div className="bg-white rounded-3xl p-6 border border-[#D4A84F]/30 shadow-md space-y-3">
              <h3 className="font-serif font-bold text-base text-[#174D35] border-b border-stone-100 pb-3">
                Frequently Asked Questions
              </h3>
              <div className="space-y-2">
                {faqs.map((faq, idx) => {
                  const isOpen = openFaq === idx;
                  return (
                    <div key={idx} className="border border-stone-200 rounded-xl overflow-hidden">
                      <button
                        onClick={() => setOpenFaq(isOpen ? null : idx)}
                        className="w-full p-3 text-left font-serif font-bold text-xs text-[#174D35] flex items-center justify-between gap-2 hover:bg-stone-50 transition-colors"
                      >
                        <span>{faq.q}</span>
                        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                      </button>
                      {isOpen && (
                        <div className="p-3 bg-stone-50 border-t border-stone-200 text-xs text-stone-600 font-light leading-relaxed">
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
