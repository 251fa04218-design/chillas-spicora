"use client";

import React, { useState } from "react";
import { MessageCircle, X } from "lucide-react";

export function WhatsAppButton() {
  const [showTooltip, setShowTooltip] = useState(false);

  const whatsappUrl = `https://wa.me/919848012345?text=${encodeURIComponent(
    "Namaskaram CHILLA'S SPICORA! I am interested in your premium Indian spices and liquid flavour drops. Please assist me."
  )}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
      {/* Tooltip bubble */}
      {showTooltip && (
        <div className="bg-[#174D35] text-white border border-[#D4A84F]/50 px-3.5 py-2 rounded-xl shadow-xl text-xs max-w-xs animate-in fade-in slide-in-from-right duration-200">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="font-serif font-bold text-[#D4A84F]">CHILLA&apos;S SPICORA Concierge</span>
            <button
              onClick={() => setShowTooltip(false)}
              className="text-stone-300 hover:text-white"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <p className="text-[11px] text-stone-200">
            Have questions about pack sizes, recipe pairings, or bulk catering orders? Chat with our Guntur spice masters!
          </p>
        </div>
      )}

      {/* Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-110 border-2 border-[#D4A84F]"
        aria-label="Chat with us on WhatsApp"
      >
        <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-30 group-hover:opacity-0" />
        <MessageCircle className="w-7 h-7 stroke-[2.2]" />
      </a>
    </div>
  );
}
