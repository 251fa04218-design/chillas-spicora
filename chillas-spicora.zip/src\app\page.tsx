"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Sparkles,
  Award,
  ShieldCheck,
  Droplets,
  Flame,
  ChefHat,
  ChevronRight,
  Star,
  CheckCircle2,
  Clock,
  Play,
  Heart,
  ChevronLeft,
  ShoppingBag,
  Gift,
  Copy,
  Check,
  CheckCircle,
  Percent,
  SlidersHorizontal
} from "lucide-react";
import { CATEGORIES } from "@/data/categories";
import { RECIPES } from "@/data/recipes";
import { useSpicora } from "@/context/SpicoraContext";
import { useCart } from "@/context/CartContext";
import { ProductCard } from "@/components/products/ProductCard";
import { RecipeVideoModal } from "@/components/recipes/RecipeVideoModal";
import { Recipe } from "@/types";

export default function HomePage() {
  const { products } = useSpicora();
  const { applyCoupon } = useCart();
  const [selectedRecipeVideo, setSelectedRecipeVideo] = useState<Recipe | null>(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [recipeFilter, setRecipeFilter] = useState<"All" | "Traditional Veg" | "Traditional Non-Veg" | "Chai">("All");
  const [copiedCoupon, setCopiedCoupon] = useState(false);
  const [activeLiquidDosage, setActiveLiquidDosage] = useState<number>(0);

  // Flagship Liquid Products
  const liquidProducts = products.filter((p) => p.categoryId === "liquid-flavours");

  // Curated Combo Products
  const comboProducts = products.filter((p) => p.categoryId === "combo-packs");

  const filteredRecipes =
    recipeFilter === "All"
      ? RECIPES
      : recipeFilter === "Traditional Veg"
      ? RECIPES.filter((r) => r.dietary === "Veg" && r.category !== "Chai")
      : recipeFilter === "Traditional Non-Veg"
      ? RECIPES.filter((r) => r.dietary === "Non-Veg")
      : RECIPES.filter((r) => r.category === "Chai");

  const openVideoModal = (recipe: Recipe) => {
    setSelectedRecipeVideo(recipe);
    setIsVideoModalOpen(true);
  };

  const handleCopyCoupon = (code: string) => {
    navigator.clipboard.writeText(code);
    applyCoupon(code);
    setCopiedCoupon(true);
    setTimeout(() => setCopiedCoupon(false), 2500);
  };

  const liquidDosages = [
    {
      title: "Kadak Masala Chai",
      drops: "2 to 3 Drops",
      liquidName: "Traditional Chai Masala Liquid",
      icon: "☕",
      desc: "Add 2 drops directly into boiling milk and tea decoction. Instant royal dhaba aroma with zero gritty residue."
    },
    {
      title: "Royal Dum Biryani",
      drops: "5 to 6 Drops",
      liquidName: "Biryani Flavour Liquid",
      icon: "🍲",
      desc: "Drop over steamed basmati rice before dough sealing (dum). Fills the dining room with authentic degchi saffron aroma."
    },
    {
      title: "Everyday Curry & Dal",
      drops: "3 to 4 Drops",
      liquidName: "Ginger-Garlic Flavour Liquid",
      icon: "🥘",
      desc: "Infuse directly into hot oil or tomato gravy. Concentrated allicin punch with zero water splattering or burning."
    },
    {
      title: "Tandoori Paneer & Chicken",
      drops: "4 Drops",
      liquidName: "Tandoori Flavour Liquid",
      icon: "🍢",
      desc: "Whisk into hung yoghurt marinade. Authentic coal-charred tandoor smokiness achieved on home stovetop or air fryer."
    },
    {
      title: "Festive Kheer & Mithai",
      drops: "2 Drops",
      liquidName: "Cardamom Flavour Liquid",
      icon: "🍨",
      desc: "Pure cold-extracted Idukki green cardamom. Replaces 6 whole crushed pods with smooth dessert blending."
    },
    {
      title: "Hot Rasam & Soups",
      drops: "3 Drops",
      liquidName: "Pepper Flavour Liquid",
      icon: "🥣",
      desc: "Sharp Tellicherry black pepper kick that blooms immediately in hot broth without peppery dust settling at the bottom."
    }
  ];

  return (
    <div className="bg-[#080C0A] text-[#F3F4F1] min-h-screen flex flex-col selection:bg-[#D4A84F] selection:text-black">
      {/* 1. HERO SECTION (MATCHING THE DARK LUXURY REFERENCE DESIGN) */}
      <section className="relative overflow-hidden pt-8 pb-16 lg:py-20 border-b border-[#D4A84F]/20">
        {/* Ambient Gold Sparks & Spice Dust */}
        <div className="absolute inset-0 bg-spice-pattern opacity-15 pointer-events-none" />
        <div className="absolute top-10 right-1/4 w-80 h-80 bg-[#D4A84F]/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-5 left-10 w-96 h-96 bg-[#C83E24]/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Column: Headline and Hero CTA */}
            <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
              {/* Flagship Announcement Pill */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-[#D4A84F]/40 text-xs text-[#D4A84F] tracking-widest uppercase font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-[#D4A84F] animate-ping" />
                ★ OUR HERO INNOVATION: SIGNATURE LIQUID SPICE DROPS
              </div>

              <div className="space-y-3">
                <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-black uppercase tracking-wider text-[#F4E6BE] leading-tight">
                  ELEVATE YOUR <br className="hidden sm:inline" />
                  <span className="text-white">FLAVORS</span>
                </h1>
                <p className="font-serif italic text-base sm:text-xl font-bold tracking-widest text-[#E56345] uppercase">
                  EXPLORE SIGNATURE LIQUIDS & HANDCRAFTED MASALAS
                </p>
              </div>

              <p className="text-sm text-stone-300 font-light leading-relaxed max-w-xl mx-auto lg:mx-0">
                Crafted in the spice heartland of Guntur. Experience ultrasonic cold-extracted liquid spice drops — where <strong>1 drop replaces 1 spoon of spice</strong> with zero burning and zero residue — alongside stone-ground masalas and curated combo hampers.
              </p>

              {/* Action Buttons matching the reference design */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <Link
                  href="/shop?category=signature-liquid-flavours"
                  className="px-8 py-3.5 rounded-full bg-gradient-to-r from-[#D4A84F] via-[#F4E6BE] to-[#B3862D] text-stone-950 font-black text-xs uppercase tracking-[0.2em] shadow-xl hover:shadow-[#D4A84F]/30 hover:scale-105 transition-all flex items-center gap-2"
                >
                  <Droplets className="w-4 h-4 fill-current" />
                  SHOP SIGNATURE LIQUIDS
                  <ArrowRight className="w-4 h-4 stroke-[3]" />
                </Link>

                <Link
                  href="#combo-offers"
                  className="px-7 py-3.5 rounded-full bg-[#C83E24] hover:bg-[#A82B14] text-white font-extrabold text-xs uppercase tracking-wider border border-[#C83E24]/60 transition-all flex items-center gap-2 shadow-lg"
                >
                  <Gift className="w-4 h-4" />
                  COMBO OFFERS (SAVE 30%)
                </Link>
              </div>

              {/* Key Brand Metrics */}
              <div className="pt-6 border-t border-white/10 flex items-center justify-center lg:justify-start gap-6 sm:gap-8 text-xs text-stone-400">
                <div>
                  <span className="font-serif font-black text-lg text-white block">1 DROP = 1 SPOON</span>
                  <span className="text-[11px] text-stone-300">Ultrasonic Extraction</span>
                </div>
                <div className="w-px h-6 bg-white/10" />
                <div>
                  <span className="font-serif font-black text-lg text-white block">600+ DROPS</span>
                  <span className="text-[11px] text-stone-300">Per 30ml Bottle</span>
                </div>
                <div className="w-px h-6 bg-white/10" />
                <div>
                  <span className="font-serif font-black text-lg text-white block">UP TO 30% OFF</span>
                  <span className="text-[11px] text-amber-300">Curated Combo Boxes</span>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Visual with spices on rustic dark wood */}
            <div className="lg:col-span-6 relative">
              <div className="relative mx-auto w-full max-w-lg aspect-[16/11] rounded-3xl overflow-hidden border border-[#D4A84F]/40 shadow-2xl shadow-black/80 bg-stone-950 group">
                <Image
                  src="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=80"
                  alt="Elevate your flavors with Indian Spices & Liquid Drops"
                  fill
                  priority
                  className="object-cover group-hover:scale-105 transition-transform duration-700 brightness-95"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent opacity-80" />

                {/* Floating Flagship Liquid Badge on Hero Image */}
                <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-md border border-[#D4A84F]/50 px-3.5 py-1.5 rounded-full flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#D4A84F] animate-pulse" />
                  <span className="text-[11px] font-bold text-[#F4E6BE] tracking-wider uppercase">
                    Main Product: Liquid Spice Drops
                  </span>
                </div>

                {/* Ambient glowing dots indicating carousel */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#C83E24]" />
                  <span className="w-2 h-2 rounded-full bg-[#D4A84F]" />
                  <span className="w-2 h-2 rounded-full bg-[#E59E1B]" />
                  <span className="w-2 h-2 rounded-full bg-white/40" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. OUR SIGNATURE BLENDS SECTION (DIRECT ADAPTATION OF UPLOADED INTERFACE MOCKUP) */}
      <section className="py-16 bg-[#080C0A] relative border-b border-[#D4A84F]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          {/* Section Header with Left/Right Arrows */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold uppercase tracking-[0.2em] text-[#D4A84F]">
                OUR SIGNATURE BLENDS
              </h2>
              <p className="text-xs text-stone-400 mt-1">
                Handcrafted formulations in artisanal glass jars & dropper bottles.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Link
                href="/shop"
                className="w-9 h-9 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-stone-300 hover:text-white hover:border-[#D4A84F] transition-colors"
                title="Previous"
              >
                <ChevronLeft className="w-4 h-4" />
              </Link>
              <Link
                href="/shop"
                className="w-9 h-9 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-stone-300 hover:text-white hover:border-[#D4A84F] transition-colors"
                title="Next"
              >
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Cards Grid: 3 Glass Jar Cards + 1 Featured Ingredient Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Card 1: Guntur Red Chilli Powder */}
            {products.find((p) => p.id === "spicora-mas-red-chilli") && (
              <ProductCard product={products.find((p) => p.id === "spicora-mas-red-chilli")!} />
            )}

            {/* Card 2: Traditional Chai Masala Liquid (HERO LIQUID SPOTLIGHT) */}
            {products.find((p) => p.id === "spicora-liq-chai") && (
              <ProductCard product={products.find((p) => p.id === "spicora-liq-chai")!} />
            )}

            {/* Card 3: Turmeric Powder */}
            {products.find((p) => p.id === "spicora-mas-turmeric") && (
              <ProductCard product={products.find((p) => p.id === "spicora-mas-turmeric")!} />
            )}

            {/* Card 4: FEATURED INGREDIENT SIDE CARD (AS SHOWN IN MOCKUP) */}
            <div className="rounded-2xl p-6 glow-card-crimson flex flex-col justify-between text-center space-y-4 border border-[#C83E24]/60">
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#E56345] block">
                  FEATURED INGREDIENT
                </span>
                <h3 className="font-serif font-black text-lg text-white uppercase tracking-wider">
                  RED CHILI
                </h3>
              </div>

              {/* Glowing Chilli Illustration */}
              <div className="relative aspect-square w-32 mx-auto rounded-2xl overflow-hidden bg-black/50 border border-[#C83E24]/40 p-2 shadow-inner">
                <Image
                  src="https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=400&q=80"
                  alt="Red Chili"
                  fill
                  className="object-cover rounded-xl"
                />
              </div>

              <div className="space-y-2">
                <p className="text-xs text-stone-300 font-light leading-relaxed">
                  Red Chili&apos;s handcrafted spices & masalas, with premium ingredient.
                </p>
                <div className="flex justify-center text-[#D4A84F] gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>
              </div>

              <Link
                href="/shop/red-chilli-powder"
                className="w-full py-2.5 rounded-full bg-gradient-to-r from-[#C83E24] to-[#9E2A14] text-white font-extrabold text-xs uppercase tracking-wider hover:brightness-110 shadow-md transition-all block"
              >
                EXPLORE INGREDIENT
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 3. HERO PRODUCT SPOTLIGHT: SIGNATURE LIQUID FLAVOURS SHOWCASE */}
      <section className="py-20 bg-[#0C120F] relative border-b border-[#D4A84F]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4A84F]/15 border border-[#D4A84F]/40 text-xs text-[#D4A84F] font-bold uppercase tracking-wider">
                <Droplets className="w-3.5 h-3.5 fill-current" />
                OUR MAIN FLAGSHIP PRODUCT
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white">
                The Signature Liquid Spice Collection
              </h2>
              <p className="text-xs sm:text-sm text-stone-300 font-light max-w-2xl leading-relaxed">
                Replaces bulky perishable pastes, gritty spice powders, and bitter burnt remnants. Extracted at low temperatures in Guntur to lock in 100% active volatile essential oils. <strong>Just 2 concentrated drops</strong> transform boiling chai, royal biryanis, and simmering curries.
              </p>
            </div>

            <Link
              href="/shop?category=signature-liquid-flavours"
              className="px-6 py-3 rounded-full bg-[#174D35] hover:bg-[#13422E] text-white border border-[#D4A84F]/50 font-bold text-xs uppercase tracking-wider whitespace-nowrap flex items-center gap-2 shadow-lg"
            >
              Explore All 6 Liquid Drops
              <ArrowRight className="w-4 h-4 text-[#D4A84F]" />
            </Link>
          </div>

          {/* Interactive Dropper Dosage Guide */}
          <div className="bg-[#101713] rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-[#D4A84F] block">
                  CULINARY DOSAGE CALCULATOR
                </span>
                <h3 className="font-serif font-bold text-lg sm:text-xl text-white">
                  How Many Drops Do You Need?
                </h3>
              </div>
              <span className="text-xs text-stone-400">
                Click any dish to see the precision drop ratio:
              </span>
            </div>

            {/* Dish selector pills */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              {liquidDosages.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveLiquidDosage(idx)}
                  className={`p-3 rounded-2xl text-left border transition-all flex flex-col justify-between ${
                    activeLiquidDosage === idx
                      ? "bg-[#D4A84F] text-stone-950 border-[#D4A84F] shadow-lg font-bold"
                      : "bg-black/40 text-stone-300 border-white/10 hover:border-[#D4A84F]/50"
                  }`}
                >
                  <div className="text-2xl mb-1">{item.icon}</div>
                  <div className="text-xs font-bold line-clamp-1">{item.title}</div>
                  <div className={`text-[11px] mt-1 font-extrabold ${activeLiquidDosage === idx ? "text-stone-950 font-black" : "text-[#D4A84F]"}`}>
                    {item.drops}
                  </div>
                </button>
              ))}
            </div>

            {/* Active Dosage Highlight Card */}
            <div className="bg-black/60 rounded-2xl p-5 border border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{liquidDosages[activeLiquidDosage].icon}</span>
                  <h4 className="font-serif font-black text-white text-base">
                    {liquidDosages[activeLiquidDosage].title}: Recommended Dosage
                  </h4>
                  <span className="bg-[#D4A84F] text-stone-950 text-xs font-black px-2.5 py-0.5 rounded-full">
                    {liquidDosages[activeLiquidDosage].drops}
                  </span>
                </div>
                <p className="text-xs text-stone-300 font-light leading-relaxed">
                  {liquidDosages[activeLiquidDosage].desc}
                </p>
              </div>

              <Link
                href="/shop?category=signature-liquid-flavours"
                className="px-5 py-2.5 rounded-full bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider whitespace-nowrap hover:brightness-105 shadow-md flex items-center gap-1.5"
              >
                <Droplets className="w-3.5 h-3.5" />
                Shop This Drop
              </Link>
            </div>
          </div>

          {/* Grid of All 6 Signature Liquid Products */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {liquidProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* 4. CURATED COMBO OFFERS & VALUE BUNDLES SECTION (#combo-offers) */}
      <section id="combo-offers" className="py-20 bg-[#080C0A] relative border-b border-[#D4A84F]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          {/* Promotional Deal of the Day Banner */}
          <div className="bg-gradient-to-r from-[#C83E24] via-[#9E2A14] to-[#701A09] rounded-3xl p-6 sm:p-8 text-white border border-[#D4A84F]/50 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
            <div className="space-y-2 text-center md:text-left z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/40 border border-white/20 text-xs font-bold text-[#F4E6BE] uppercase">
                <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                SPECIAL COMBO OFFER • SAVE UP TO 30%
              </div>
              <h3 className="font-serif font-black text-2xl sm:text-3xl text-white">
                Liquid & Spice Discovery Bundles
              </h3>
              <p className="text-xs sm:text-sm text-stone-200 max-w-xl font-light">
                Get our flagship liquid drops paired with traditional masalas and whole botanicals. Plus a <strong>Complimentary Gold-Plated Precision Dropper</strong> with every combo!
              </p>
            </div>

            {/* Click to Apply Coupon Box */}
            <div className="bg-black/70 backdrop-blur-md p-4 rounded-2xl border border-[#D4A84F]/60 text-center space-y-2 z-10 w-full md:w-auto">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4A84F] block">
                EXTRA 25% OFF COUPON
              </span>
              <div className="font-mono font-black text-xl text-white tracking-widest bg-white/10 px-4 py-1.5 rounded-lg border border-dashed border-[#D4A84F]">
                LIQUIDCOMBO25
              </div>
              <button
                onClick={() => handleCopyCoupon("LIQUIDCOMBO25")}
                className="w-full py-2 px-4 rounded-xl bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-extrabold text-xs uppercase tracking-wider hover:brightness-110 flex items-center justify-center gap-1.5 transition-all"
              >
                {copiedCoupon ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Applied & Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Apply Coupon
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#D4A84F] block">
                SAVE BIG ON EXPERTLY CURATED SETS
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-extrabold text-white mt-1">
                Explore All 8 Combo Offers & Gift Boxes
              </h2>
            </div>
            <Link
              href="/shop?category=combo-packs"
              className="text-xs font-bold uppercase tracking-wider text-[#D4A84F] hover:text-white flex items-center gap-1"
            >
              View All Combo Bundles
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Grid of All 8 Combo Products */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {comboProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* 5. RECIPE VIDEOS & CULINARY MASTERCLASSES SECTION */}
      <section className="py-20 bg-[#0C120F] border-b border-[#D4A84F]/20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#D4A84F] flex items-center gap-1.5">
                <Play className="w-3.5 h-3.5 fill-current" />
                CULINARY VIDEO MASTERCLASSES
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-extrabold text-white">
                Authentic Recipe Videos & Preparation Guides
              </h2>
              <p className="text-xs sm:text-sm text-stone-400 font-light max-w-2xl">
                Watch our kitchen masterclasses demonstrating traditional vegetarian curries, slow-braised mutton and chicken preparations, and royal chai with SPICORA spice pairings.
              </p>
            </div>

            {/* Recipe Filter Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {(["All", "Traditional Veg", "Traditional Non-Veg", "Chai"] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setRecipeFilter(cat)}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                    recipeFilter === cat
                      ? "bg-[#D4A84F] text-stone-950 font-extrabold shadow-md"
                      : "bg-white/5 text-stone-300 border border-white/10 hover:border-[#D4A84F]"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Recipe Video Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.slice(0, 6).map((recipe) => (
              <div
                key={recipe.id}
                className="group rounded-2xl overflow-hidden bg-[#101713] border border-white/10 hover:border-[#D4A84F]/60 transition-all duration-300 flex flex-col justify-between shadow-xl"
              >
                {/* Video Thumbnail with Play Button Overlay */}
                <div
                  onClick={() => openVideoModal(recipe)}
                  className="relative aspect-[16/10] w-full overflow-hidden cursor-pointer bg-black"
                >
                  <Image
                    src={recipe.image}
                    alt={recipe.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500 brightness-90"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-[#D4A84F] text-stone-950 flex items-center justify-center shadow-2xl group-hover:scale-115 transition-transform">
                      <Play className="w-6 h-6 fill-stone-950 ml-1" />
                    </div>
                  </div>

                  {/* Duration Tag */}
                  {recipe.videoDuration && (
                    <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-sm text-white text-[11px] font-mono px-2 py-0.5 rounded-md border border-white/20 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#D4A84F]" />
                      {recipe.videoDuration}
                    </div>
                  )}

                  {/* Dietary Tag */}
                  <div className="absolute top-3 left-3">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                        recipe.dietary === "Veg"
                          ? "bg-emerald-950/80 text-emerald-400 border-emerald-500/40"
                          : "bg-red-950/80 text-red-400 border-red-500/40"
                      }`}
                    >
                      {recipe.dietary}
                    </span>
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-stone-400">
                      <span className="text-[#D4A84F] font-semibold">{recipe.category}</span>
                      <span>Prep: {recipe.prepTime}</span>
                    </div>

                    <h3 className="font-serif font-bold text-lg text-white group-hover:text-[#D4A84F] transition-colors line-clamp-1">
                      {recipe.title}
                    </h3>

                    <p className="text-xs text-stone-300 line-clamp-2 leading-relaxed font-light">
                      {recipe.description}
                    </p>
                  </div>

                  {/* Paired Spice Mini Card */}
                  <div className="pt-3 border-t border-white/10 space-y-2">
                    <div className="bg-[#174D35]/40 border border-[#D4A84F]/30 p-2.5 rounded-xl text-xs flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-[#D4A84F] uppercase font-bold block">
                          Paired Spice:
                        </span>
                        <span className="font-bold text-white line-clamp-1">
                          {recipe.spicoraPairing.productName}
                        </span>
                      </div>
                      <Link
                        href={`/shop/${recipe.spicoraPairing.productSlug}`}
                        className="p-1.5 rounded-lg bg-[#D4A84F] text-stone-950 hover:bg-[#F3DC9B] transition-colors"
                        title="Shop Paired Spice"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                      </Link>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => openVideoModal(recipe)}
                        className="flex-1 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Play className="w-3.5 h-3.5 fill-[#D4A84F] text-[#D4A84F]" />
                        Watch Video
                      </button>
                      <Link
                        href={`/recipes/${recipe.slug}`}
                        className="px-3 py-2 rounded-xl border border-white/20 hover:border-[#D4A84F] text-stone-300 hover:text-white text-xs font-semibold flex items-center justify-center"
                      >
                        Recipe
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center pt-4">
            <Link
              href="/recipes"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#174D35] hover:bg-[#13422E] text-white font-bold text-xs uppercase tracking-wider border border-[#D4A84F]/40 transition-colors shadow-lg"
            >
              Explore All 19 Traditional Indian Recipes & Videos
              <ArrowRight className="w-4 h-4 text-[#D4A84F]" />
            </Link>
          </div>
        </div>
      </section>

      {/* 6. GUNTUR HERITAGE & FOOD SAFETY COMMITMENT */}
      <section className="py-14 bg-[#0A130E] border-t border-[#D4A84F]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-6 rounded-3xl bg-[#101713] border border-[#D4A84F]/30 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-1.5 text-center md:text-left">
              <span className="text-[11px] font-bold text-[#D4A84F] uppercase tracking-wider flex items-center justify-center md:justify-start gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Food Safety & Regulatory Compliance Framework
              </span>
              <h3 className="font-serif font-bold text-lg text-white">
                Proposed Product Catalog & Formulation Pilot
              </h3>
              <p className="text-xs text-stone-300 max-w-2xl font-light">
                Products presented on this portal reflect proposed formulations undergoing laboratory validation in Guntur, AP. Full statutory FSSAI food business licensing and nutritional tables are published prior to mass retail sale.
              </p>
            </div>
            <Link
              href="/about"
              className="px-6 py-2.5 rounded-full bg-[#D4A84F] text-stone-950 font-bold text-xs uppercase tracking-wider hover:bg-[#F3DC9B] whitespace-nowrap"
            >
              Read Quality Protocol
            </Link>
          </div>
        </div>
      </section>

      {/* Video Masterclass Modal */}
      <RecipeVideoModal
        recipe={selectedRecipeVideo}
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
      />
    </div>
  );
}
