import { Product } from "@/types";
import { LIQUID_PRODUCTS } from "./liquid";
import { MASALA_PRODUCTS } from "./masala";
import { BLEND_PRODUCTS } from "./blends";
import { WHOLE_PRODUCTS } from "./whole";
import { COMBO_PRODUCTS } from "./combos";

export const ALL_PRODUCTS: Product[] = [
  ...LIQUID_PRODUCTS,
  ...MASALA_PRODUCTS,
  ...BLEND_PRODUCTS,
  ...WHOLE_PRODUCTS,
  ...COMBO_PRODUCTS,
];

export function getProductBySlug(slug: string): Product | undefined {
  return ALL_PRODUCTS.find((p) => p.slug === slug);
}

export function getProductsByCategory(categoryId: string): Product[] {
  return ALL_PRODUCTS.filter((p) => p.categoryId === categoryId);
}

export function getFeaturedProducts(): Product[] {
  return ALL_PRODUCTS.filter((p) => p.isFeatured);
}

export function getBestSellers(): Product[] {
  return ALL_PRODUCTS.filter((p) => p.isBestSeller);
}

export function getNewArrivals(): Product[] {
  return ALL_PRODUCTS.filter((p) => p.isNewArrival);
}
