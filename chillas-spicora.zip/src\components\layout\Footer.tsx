"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  MapPin,
  Phone,
  Mail,
  ArrowRight,
  ShieldAlert,
  CheckCircle2,
  Award,
  Sparkles,
  Heart
} from "lucide-react";
import { Logo } from "@/components/ui/Logo";

export function Footer() {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      setNewsletterEmail("");
    }
  };

  return (
    <footer className="bg-[#0b251a] text-stone-300 border-t border-[#D4A84F]/30">
      {/* Brand Trust Badges Row */}
      <div className="border-b border-[#D4A84F]/20 bg-[#0f3424]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-[#174D35] flex items-center justify-center text-[#D4A84F] mb-3 shadow-inner">
              <MapPin className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-white text-sm">Guntur Heritage Origin</h4>
            <p className="text-xs text-stone-400 mt-1">Direct from India&apos;s spice heartland</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-[#174D35] flex items-center justify-center text-[#D4A84F] mb-3 shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-white text-sm">Cold-Extracted Drops</h4>
            <p className="text-xs text-stone-400 mt-1">Groundbreaking liquid spice technology</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-[#174D35] flex items-center justify-center text-[#D4A84F] mb-3 shadow-inner">
              <Award className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-white text-sm">Zero Adulteration</h4>
            <p className="text-xs text-stone-400 mt-1">100% pure unadulterated botanicals</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-[#174D35] flex items-center justify-center text-[#D4A84F] mb-3 shadow-inner">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-white text-sm">Rigorous Safety Testing</h4>
            <p className="text-xs text-stone-400 mt-1">Lab validated aroma and purity</p>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
        {/* Brand Column */}
        <div className="lg:col-span-2 space-y-4">
          <Logo variant="light" size="lg" />
          <p className="text-sm text-stone-400 leading-relaxed max-w-sm pt-2">
            CHILLA&apos;S SPICORA is a premier Indian spice and culinary flavour company rooted in Guntur, Andhra Pradesh. We craft high-terpene liquid spice drops, slow-roasted masala powders, and hand-selected whole botanicals for true culinary masters.
          </p>

          <div className="space-y-2 text-xs text-stone-300 pt-2">
            <p className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#D4A84F] flex-shrink-0" />
              <span>Guntur Industrial Spice Corridor, Andhra Pradesh - 522002, India</span>
            </p>
            <p className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#D4A84F] flex-shrink-0" />
              <span>Direct: +91 98480 12345 / WhatsApp: +91 98480 54321</span>
            </p>
            <p className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#D4A84F] flex-shrink-0" />
              <span>care@spicora.in / b2b@spicora.in</span>
            </p>
          </div>
        </div>

        {/* Spice Catalog */}
        <div className="space-y-3">
          <h3 className="font-serif font-bold text-white text-base tracking-wider border-b border-[#D4A84F]/30 pb-2">
            Spice Collections
          </h3>
          <ul className="space-y-2 text-sm text-stone-400">
            <li>
              <Link href="/shop?category=signature-liquid-flavours" className="hover:text-[#D4A84F] transition-colors">
                Signature Liquid Flavours
              </Link>
            </li>
            <li>
              <Link href="/shop?category=traditional-masala-powders" className="hover:text-[#D4A84F] transition-colors">
                Traditional Masala Powders
              </Link>
            </li>
            <li>
              <Link href="/shop?category=special-spice-blends" className="hover:text-[#D4A84F] transition-colors">
                Special Spice Blends
              </Link>
            </li>
            <li>
              <Link href="/shop?category=whole-spices" className="hover:text-[#D4A84F] transition-colors">
                Whole Spices & Botanicals
              </Link>
            </li>
            <li>
              <Link href="/shop?category=combo-packs" className="hover:text-[#D4A84F] transition-colors">
                Curated Gift Boxes & Combos
              </Link>
            </li>
            <li>
              <Link href="/shop?status=Active" className="hover:text-[#D4A84F] transition-colors font-medium text-emerald-400">
                Ready for Dispatch (Pilot)
              </Link>
            </li>
          </ul>
        </div>

        {/* Quick Links */}
        <div className="space-y-3">
          <h3 className="font-serif font-bold text-white text-base tracking-wider border-b border-[#D4A84F]/30 pb-2">
            Culinary & Brand
          </h3>
          <ul className="space-y-2 text-sm text-stone-400">
            <li>
              <Link href="/recipes" className="hover:text-[#D4A84F] transition-colors">
                Recipe Inspiration Hub
              </Link>
            </li>
            <li>
              <Link href="/about" className="hover:text-[#D4A84F] transition-colors">
                Guntur Story & Heritage
              </Link>
            </li>
            <li>
              <Link href="/wholesale" className="hover:text-[#D4A84F] transition-colors">
                B2B Bulk & Caterers Supply
              </Link>
            </li>
            <li>
              <Link href="/account" className="hover:text-[#D4A84F] transition-colors">
                Customer Account & Orders
              </Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-[#D4A84F] transition-colors">
                Contact & Factory Visits
              </Link>
            </li>
            <li>
              <Link href="/admin" className="hover:text-[#D4A84F] transition-colors text-[#D4A84F] font-semibold">
                Admin Management Portal
              </Link>
            </li>
          </ul>
        </div>

        {/* Newsletter Signup */}
        <div className="space-y-3">
          <h3 className="font-serif font-bold text-white text-base tracking-wider border-b border-[#D4A84F]/30 pb-2">
            Spice Connoisseurs Club
          </h3>
          <p className="text-xs text-stone-400 leading-relaxed">
            Join 12,000+ Indian food enthusiasts. Receive private tasting invitations, secret Telugu recipes, and early access to harvest batches.
          </p>

          {subscribed ? (
            <div className="bg-[#174D35] p-3 rounded-lg border border-[#D4A84F]/40 text-xs text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#D4A84F]" />
              <span>Namaskaram! You are subscribed to SPICORA Royal Club.</span>
            </div>
          ) : (
            <form onSubmit={handleNewsletterSubmit} className="space-y-2">
              <input
                type="email"
                placeholder="Enter your email address"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                required
                className="w-full bg-[#13422E] border border-[#D4A84F]/30 rounded-lg px-3.5 py-2 text-xs text-white placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
              />
              <button
                type="submit"
                className="w-full py-2 bg-[#D4A84F] text-[#174D35] font-bold text-xs rounded-lg hover:bg-[#F3DC9B] flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                Subscribe Now
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          <div className="pt-2 text-[11px] text-stone-400">
            <span>Special Welcome Offer: Use coupon </span>
            <code className="text-[#D4A84F] font-mono font-bold bg-[#13422E] px-1.5 py-0.5 rounded">SPICORA10</code>
          </div>
        </div>
      </div>

      {/* Mandatory Food Safety & Legal Compliance Notice Banner */}
      <div className="bg-[#061710] border-t border-[#D4A84F]/20 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-start gap-3 text-stone-400 text-[11px] leading-relaxed">
          <ShieldAlert className="w-4 h-4 text-[#D4A84F] flex-shrink-0 mt-0.5" />
          <div>
            <strong className="text-white font-semibold">FOOD SAFETY & REGULATORY COMPLIANCE STATEMENT:</strong> This platform showcases the proposed product catalog, formulation portfolio, and pack variants of CHILLA&apos;S SPICORA. Commercial dispatch and retail sale are governed by applicable Indian food safety laws. Full laboratory validation, nutrition facts, allergen declarations, and applicable FSSAI licensing will be verified and published prior to mass commercial sale. Products marked as &ldquo;Development&rdquo; or &ldquo;Coming Soon&rdquo; represent concepts in active testing and formulation.
          </div>
        </div>
      </div>

      {/* Bottom Copyright */}
      <div className="border-t border-white/5 py-6 px-4 text-center text-xs text-stone-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} CHILLA&apos;S SPICORA. All Rights Reserved. Guntur, Andhra Pradesh, India.</p>
          <div className="flex gap-4">
            <Link href="/about" className="hover:text-white">Privacy Policy</Link>
            <Link href="/about" className="hover:text-white">Terms of Service</Link>
            <Link href="/contact" className="hover:text-white">Food Safety Roadmap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
