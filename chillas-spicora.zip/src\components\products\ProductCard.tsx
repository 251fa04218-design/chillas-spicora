"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart, ShoppingBag, Star, Sparkles, Check, Bell, Droplets, Gift, CheckCircle } from "lucide-react";
import { Product, ProductVariant } from "@/types";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { formatINR } from "@/lib/utils";

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  // Active variant state
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant>(
    product.variants[0]
  );
  const [addedAnimation, setAddedAnimation] = useState(false);
  const [notified, setNotified] = useState(false);

  const isFavorited = isInWishlist(product.id);
  const isAvailableForSale = product.status === "Active" && selectedVariant.inStock;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAvailableForSale) return;

    addItem(product, selectedVariant, 1);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1500);
  };

  const handleNotifyMe = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setNotified(true);
    setTimeout(() => setNotified(false), 2500);
  };

  // Determine ambient glow color matching the reference UI mockup
  const getGlowClass = () => {
    if (product.isLiquidFlagship) {
      return "glow-card-gold border-[#D4A84F]/60 hover:border-[#D4A84F]";
    }
    if (product.packagingType === "combo") {
      return "glow-card-turmeric border-[#E59E1B]/50 hover:border-[#E59E1B]";
    }
    const nameLower = product.name.toLowerCase();
    if (nameLower.includes("chilli") || nameLower.includes("chili") || nameLower.includes("pepper") || nameLower.includes("tandoori")) {
      return "glow-card-crimson hover:border-[#C83E24]";
    }
    if (nameLower.includes("turmeric") || nameLower.includes("saffron") || nameLower.includes("ginger") || nameLower.includes("curry")) {
      return "glow-card-turmeric hover:border-[#E59E1B]";
    }
    if (nameLower.includes("chai") || nameLower.includes("cardamom") || nameLower.includes("coriander")) {
      return "glow-card-emerald hover:border-[#4fa77c]";
    }
    return "glow-card-gold hover:border-[#D4A84F]";
  };

  const getButtonClass = () => {
    if (product.isLiquidFlagship) {
      return "bg-gradient-to-r from-[#D4A84F] via-[#F4E6BE] to-[#B3862D] text-stone-950 shadow-yellow-950/60 font-black";
    }
    if (product.packagingType === "combo") {
      return "bg-gradient-to-r from-[#E59E1B] via-[#DE7A22] to-[#B8720C] text-stone-950 shadow-amber-950/60 font-black";
    }
    const nameLower = product.name.toLowerCase();
    if (nameLower.includes("chilli") || nameLower.includes("chili") || nameLower.includes("tandoori")) {
      return "bg-gradient-to-r from-[#C83E24] via-[#D63031] to-[#9E2A14] text-white shadow-red-950/50";
    }
    if (nameLower.includes("turmeric") || nameLower.includes("curry")) {
      return "bg-gradient-to-r from-[#E59E1B] via-[#DE7A22] to-[#B8720C] text-stone-950 shadow-amber-950/50";
    }
    return "bg-gradient-to-r from-[#D4A84F] via-[#F4E6BE] to-[#B3862D] text-stone-950 shadow-yellow-950/50";
  };

  return (
    <div
      className={`group relative rounded-2xl overflow-hidden transition-all duration-300 flex flex-col justify-between p-4 ${getGlowClass()}`}
    >
      {/* Top Wishlist and Badges Bar */}
      <div className="flex items-center justify-between mb-2 z-10 gap-1.5 flex-wrap">
        <div className="flex items-center gap-1.5 flex-wrap">
          {product.isLiquidFlagship && (
            <span className="bg-[#D4A84F] text-stone-950 text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-0.5 shadow-sm">
              <Droplets className="w-2.5 h-2.5 fill-current" />
              FLAGSHIP LIQUID
            </span>
          )}

          {product.discountBadge && (
            <span className="bg-[#C83E24] text-white text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-0.5 shadow-sm uppercase">
              <Sparkles className="w-2.5 h-2.5 fill-current" />
              {product.discountBadge}
            </span>
          )}

          {!product.isLiquidFlagship && !product.discountBadge && product.status === "Active" && (
            <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Pilot Orderable
            </span>
          )}

          {product.status !== "Active" && (
            <span className="bg-stone-900/90 text-[#D4A84F] border border-[#D4A84F]/40 text-[9px] font-bold px-2 py-0.5 rounded-full">
              {product.status}
            </span>
          )}
        </div>

        {/* Wishlist Heart */}
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleWishlist(product);
          }}
          className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
            isFavorited
              ? "bg-red-600 text-white shadow-lg"
              : "bg-black/40 text-stone-300 hover:text-red-400 hover:bg-black/60 border border-white/10"
          }`}
          title={isFavorited ? "In Wishlist" : "Add to Wishlist"}
        >
          <Heart className={`w-3.5 h-3.5 ${isFavorited ? "fill-current" : ""}`} />
        </button>
      </div>

      {/* Center Product Image Container with Jar/Bottle Presentation */}
      <Link href={`/shop/${product.slug}`} className="block relative aspect-square w-full my-1 rounded-xl overflow-hidden bg-black/40 border border-white/5 group-hover:scale-102 transition-transform duration-300">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-108 transition-transform duration-700 brightness-95"
        />
        {/* Soft radial shadow below jar */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80" />

        {/* Liquid Flagship Overlay Banner */}
        {product.isLiquidFlagship && product.packagingType === "liquid" && (
          <div className="absolute bottom-2 left-2 right-2 bg-black/85 backdrop-blur-sm border border-[#D4A84F]/40 px-2.5 py-1 rounded-lg flex items-center justify-between text-[10px]">
            <span className="text-[#D4A84F] font-bold flex items-center gap-1">
              <Droplets className="w-3 h-3 fill-current" />
              1 Drop = 1 Spoon
            </span>
            <span className="text-stone-300 text-[9px]">Cold Extracted</span>
          </div>
        )}

        {/* Combo Pack Item Count Overlay Banner */}
        {product.bundleItems && (
          <div className="absolute bottom-2 left-2 right-2 bg-black/85 backdrop-blur-sm border border-[#E59E1B]/50 px-2.5 py-1 rounded-lg flex items-center justify-between text-[10px]">
            <span className="text-[#E59E1B] font-bold flex items-center gap-1">
              <Gift className="w-3 h-3" />
              Includes {product.bundleItems.length} Items
            </span>
            {product.savingsAmount && (
              <span className="text-emerald-400 font-black text-[9px]">
                Save ₹{product.savingsAmount}
              </span>
            )}
          </div>
        )}
      </Link>

      {/* Content */}
      <div className="mt-3 space-y-2.5 flex-1 flex flex-col justify-between">
        <div>
          {/* Product Title */}
          <Link href={`/shop/${product.slug}`} className="block">
            <h3 className="font-serif font-bold text-sm sm:text-base text-white group-hover:text-[#D4A84F] transition-colors line-clamp-1 uppercase tracking-wide">
              {product.name}
            </h3>
          </Link>

          {/* Size & Rating line */}
          <div className="flex items-center justify-between text-xs text-stone-400 mt-1">
            <span className="text-[11px] font-medium text-stone-300">
              ★ {selectedVariant.size.split("(")[0]}
            </span>
            <div className="flex items-center gap-1 text-[#D4A84F]">
              <div className="flex text-[#D4A84F]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-2.5 h-2.5 fill-current" />
                ))}
              </div>
              <span className="text-[10px] text-stone-400 font-mono">({product.reviewCount})</span>
            </div>
          </div>

          {/* Short tagline or bundle preview */}
          {product.tagline && (
            <p className="text-[11px] text-stone-300 italic line-clamp-1 mt-0.5">
              &quot;{product.tagline}&quot;
            </p>
          )}

          {/* If Combo Pack, show bundle items quick glance */}
          {product.bundleItems && product.bundleItems.length > 0 && (
            <div className="mt-1.5 p-1.5 rounded-lg bg-black/40 border border-white/5 space-y-0.5">
              {product.bundleItems.slice(0, 2).map((item, idx) => (
                <div key={idx} className="flex items-center gap-1 text-[10px] text-stone-300 line-clamp-1">
                  <CheckCircle className="w-2.5 h-2.5 text-emerald-400 flex-shrink-0" />
                  <span className="truncate">{item}</span>
                </div>
              ))}
              {product.bundleItems.length > 2 && (
                <span className="text-[9px] text-[#D4A84F] font-semibold block pl-3.5">
                  +{product.bundleItems.length - 2} more items included
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pack Size Selector Options */}
        <div className="flex flex-wrap gap-1">
          {product.variants.map((v) => {
            const isSelected = selectedVariant.id === v.id;
            return (
              <button
                key={v.id}
                type="button"
                onClick={() => setSelectedVariant(v)}
                className={`px-2 py-0.5 text-[10px] font-medium rounded-md border transition-all ${
                  isSelected
                    ? "bg-[#D4A84F] text-stone-950 border-[#D4A84F] font-bold shadow-xs"
                    : "bg-black/40 text-stone-300 border-white/10 hover:border-[#D4A84F]/50"
                }`}
              >
                {v.size.split("(")[0]}
              </button>
            );
          })}
        </div>

        {/* Price & Pill Add To Cart Button */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
          <div>
            <div className="font-serif font-black text-lg text-white">
              {formatINR(selectedVariant.price)}
            </div>
            {selectedVariant.compareAtPrice && (
              <span className="text-[10px] text-stone-400 line-through block -mt-1">
                {formatINR(selectedVariant.compareAtPrice)}
              </span>
            )}
          </div>

          {isAvailableForSale ? (
            <button
              onClick={handleAddToCart}
              className={`px-4 py-2 rounded-full text-[11px] font-extrabold uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-md hover:scale-105 ${getButtonClass()}`}
            >
              {addedAnimation ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  Added
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3 h-3 fill-current" />
                  {product.packagingType === "combo" ? "GRAB OFFER" : "ADD TO CART"}
                </>
              )}
            </button>
          ) : (
            <button
              onClick={handleNotifyMe}
              className="px-3.5 py-1.5 rounded-full text-[10px] font-bold bg-white/10 hover:bg-white/20 text-white border border-white/20 flex items-center gap-1"
            >
              <Bell className="w-3 h-3 text-[#D4A84F]" />
              {notified ? "Notified" : "NOTIFY ME"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
