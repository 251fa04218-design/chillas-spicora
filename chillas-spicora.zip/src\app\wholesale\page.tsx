"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Building2,
  UtensilsCrossed,
  Coffee,
  Store,
  Truck,
  CheckCircle2,
  ShieldCheck,
  Send,
  Phone,
  Sparkles
} from "lucide-react";
import { useSpicora } from "@/context/SpicoraContext";

export default function WholesalePage() {
  const { addB2BEnquiry } = useSpicora();

  const [formData, setFormData] = useState({
    companyName: "",
    contactPerson: "",
    email: "",
    phone: "",
    businessType: "Restaurant" as const,
    gstin: "",
    city: "",
    state: "Andhra Pradesh",
    estimatedVolume: "100 - 500 kg/month" as const,
    productInterests: ["Biryani Flavour Liquid", "Guntur Red Chilli Powder"],
    notes: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const businessTypes = [
    { name: "Restaurants", icon: UtensilsCrossed, desc: "Consistent kitchen gravies & fry masalas" },
    { name: "Hotels & Banquets", icon: Building2, desc: "Bulk catering dum biryani & curry pastes" },
    { name: "Tea Shops & Cafes", icon: Coffee, desc: "Standardized 2-drop chai liquid extracts" },
    { name: "Caterers", icon: UtensilsCrossed, desc: "Scalable wedding feast seasonings" },
    { name: "Retail Stores", icon: Store, desc: "Premium shelf-ready bottled spices" },
    { name: "Distributors", icon: Truck, desc: "Regional territory distribution rights" },
  ];

  const handleInterestToggle = (product: string) => {
    setFormData((prev) => {
      const exists = prev.productInterests.includes(product);
      return {
        ...prev,
        productInterests: exists
          ? prev.productInterests.filter((p) => p !== product)
          : [...prev.productInterests, product],
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addB2BEnquiry(formData);
    setSubmitted(true);
  };

  return (
    <div className="bg-[#FCFBF7] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-[#174D35] to-[#0f3424] rounded-3xl p-8 sm:p-12 text-white border border-[#D4A84F]/40 shadow-xl space-y-4 relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[radial-gradient(#D4A84F_1px,transparent_1px)] [background-size:16px_16px] opacity-15 pointer-events-none" />
          <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#D4A84F] block">
            INSTITUTIONAL & B2B SPICE SUPPLY
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-extrabold text-white">
            Wholesale, Bulk & Culinary Partner Network
          </h1>
          <p className="text-sm sm:text-base text-stone-200 max-w-3xl font-light leading-relaxed">
            Partner directly with CHILLA&apos;S SPICORA in Guntur, Andhra Pradesh. We provide commercial food-service pack sizes, custom liquid flavour infusions, and wholesale botanical sacks for luxury hotels, high-volume restaurants, caterers, and national distributors.
          </p>
        </div>

        {/* Industry Segments Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {businessTypes.map((b) => {
            const Icon = b.icon;
            return (
              <div
                key={b.name}
                className="bg-white p-5 rounded-2xl border border-[#D4A84F]/25 shadow-xs text-center space-y-2 hover:border-[#D4A84F] transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-[#174D35]/10 text-[#174D35] flex items-center justify-center mx-auto">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-serif font-bold text-xs sm:text-sm text-[#174D35]">{b.name}</h3>
                <p className="text-[11px] text-stone-500 leading-tight">{b.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Enquiry Form & Value Pillars */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-10 border border-[#D4A84F]/30 shadow-md">
            {submitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#174D35]">
                  Enquiry Transmitted to Guntur Hub
                </h3>
                <p className="text-xs sm:text-sm text-[#5E6C65] max-w-md mx-auto leading-relaxed">
                  Namaskaram. Our Institutional Sales Executive will review your monthly requirements and contact you within 24 hours with custom batch pricing and sample kits.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 rounded-full bg-[#174D35] text-white text-xs font-bold uppercase tracking-wider"
                >
                  Submit Another Enquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <h2 className="font-serif font-bold text-xl text-[#174D35]">
                    Institutional Partnership Application
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    Please provide your business registration and estimated monthly spice volume.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Company / Enterprise Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Hyderabad Royal Biryanis Pvt Ltd"
                      value={formData.companyName}
                      onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Contact Person & Designation</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Chef Ramesh / General Manager"
                      value={formData.contactPerson}
                      onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Official Business Email</label>
                    <input
                      type="email"
                      required
                      placeholder="procurement@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Phone Number (Direct)</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98480 12345"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Business Type</label>
                    <select
                      value={formData.businessType}
                      onChange={(e) => setFormData({ ...formData, businessType: e.target.value as any })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    >
                      <option value="Restaurant">Restaurant Chain / Cloud Kitchen</option>
                      <option value="Hotel">Hotel / Resort / Banquet</option>
                      <option value="Tea Shop / Cafe">Tea Shop / Specialty Cafe Chain</option>
                      <option value="Caterer">Industrial / Wedding Caterer</option>
                      <option value="Retail Store">Retail Supermarket / Organic Store</option>
                      <option value="Distributor">FMCG Wholesaler / Regional Distributor</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">GSTIN Number (Optional)</label>
                    <input
                      type="text"
                      placeholder="37AAAAA0000A1Z5"
                      value={formData.gstin}
                      onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35] uppercase font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">City & State</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vijayawada, Andhra Pradesh"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Estimated Monthly Requirement</label>
                    <select
                      value={formData.estimatedVolume}
                      onChange={(e) => setFormData({ ...formData, estimatedVolume: e.target.value as any })}
                      className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    >
                      <option value="Under 25 kg/month">Under 25 kg/month (Trial)</option>
                      <option value="25 - 100 kg/month">25 - 100 kg/month</option>
                      <option value="100 - 500 kg/month">100 - 500 kg/month</option>
                      <option value="500+ kg/month">500+ kg/month (Enterprise)</option>
                      <option value="Custom Liquid Batch">Custom Liquid Dropper Batch (Liters)</option>
                    </select>
                  </div>
                </div>

                {/* Product Interests Selection */}
                <div className="space-y-2 pt-2 text-xs">
                  <label className="block font-semibold text-stone-700">
                    Product Lines of Interest:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      "Signature Liquid Flavours",
                      "Traditional Chai Drops",
                      "Biryani Flavour Liquid",
                      "Guntur Red Chilli Powder",
                      "Stone-Ground Masala Powders",
                      "Special Spice Blends",
                      "Grade-A Whole Spices",
                      "Corporate Festival Gift Boxes",
                    ].map((item) => {
                      const checked = formData.productInterests.includes(item);
                      return (
                        <button
                          key={item}
                          type="button"
                          onClick={() => handleInterestToggle(item)}
                          className={`p-2 rounded-lg text-left text-[11px] font-medium border transition-colors ${
                            checked
                              ? "bg-[#174D35] text-white border-[#174D35]"
                              : "bg-stone-50 text-stone-700 border-stone-200"
                          }`}
                        >
                          {checked ? "✓ " : "+ "}
                          {item}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Notes */}
                <div className="text-xs">
                  <label className="block font-semibold text-stone-700 mb-1">
                    Custom Formulation or Packaging Specifications
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Specify target batch sizes, private labelling interest, or sample requests..."
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 shadow-md flex items-center justify-center gap-2 transition-all"
                >
                  <Send className="w-4 h-4" />
                  Submit Wholesale Request
                </button>
              </form>
            )}
          </div>

          {/* Right Column: B2B Perks */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#174D35] text-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/40 shadow-xl space-y-5">
              <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#D4A84F]">
                THE SPICORA INSTITUTIONAL ADVANTAGE
              </span>
              <h3 className="font-serif font-bold text-2xl">
                Direct From the Guntur Milling Hub
              </h3>
              <p className="text-xs text-stone-200 font-light leading-relaxed">
                Cut out 3 layers of middlemen and brokers. Receive fresh batch millings with verified certificates of analysis (CoA) and volatile oil declarations.
              </p>

              <div className="space-y-3 pt-2 text-xs">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4A84F] flex-shrink-0 mt-0.5" />
                  <span>Custom bulk liquid drums (5L, 20L, 50L) and whole botanical bags (25kg, 50kg)</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4A84F] flex-shrink-0 mt-0.5" />
                  <span>Batch-to-batch consistency with laser-calibrated Scoville heat units for chillies</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4A84F] flex-shrink-0 mt-0.5" />
                  <span>Priority express pallet logistics across India with tracking</span>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#D4A84F] text-[#174D35] flex items-center justify-center">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] text-stone-300 block">Direct Wholesale Hotline:</span>
                  <a href="tel:+919848012345" className="text-sm font-bold text-white hover:text-[#D4A84F]">
                    +91 98480 12345 / b2b@spicora.in
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
