"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { Product, Order, B2BEnquiry, Review, ProductStatus, OrderCustomer } from "@/types";
import { ALL_PRODUCTS } from "@/data/products";
import { INITIAL_REVIEWS } from "@/data/reviews";
import { generateOrderNumber } from "@/lib/utils";

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  addresses: OrderCustomer[];
  isAdmin: boolean;
}

interface SpicoraContextType {
  products: Product[];
  updateProduct: (updated: Product) => void;
  createProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  resetProductsToDefault: () => void;
  
  orders: Order[];
  addOrder: (orderData: Omit<Order, "id" | "orderNumber" | "createdAt">) => Order;
  updateOrderStatus: (orderId: string, status: Order["orderStatus"], trackingNumber?: string) => void;

  b2bEnquiries: B2BEnquiry[];
  addB2BEnquiry: (enquiry: Omit<B2BEnquiry, "id" | "createdAt" | "status">) => void;
  updateB2BStatus: (id: string, status: B2BEnquiry["status"]) => void;

  reviews: Review[];
  addReview: (review: Omit<Review, "id" | "date" | "isDemo" | "status">) => void;
  updateReviewStatus: (id: string, status: Review["status"]) => void;

  user: UserProfile | null;
  loginUser: (email: string, name?: string) => void;
  logoutUser: () => void;
  saveAddress: (address: OrderCustomer) => void;
}

const DEFAULT_USER: UserProfile = {
  id: "usr-demo-01",
  name: "Chilla Ramesh",
  email: "ramesh.chilla@spicora.demo",
  phone: "+91 98480 12345",
  isAdmin: true,
  addresses: [
    {
      fullName: "Chilla Ramesh",
      email: "ramesh.chilla@spicora.demo",
      phone: "+91 98480 12345",
      addressLine1: "Plot 42, Spicora Heritage Enclave, Brodipet",
      addressLine2: "Near Spice Board Market Yard",
      city: "Guntur",
      state: "Andhra Pradesh",
      pincode: "522002"
    }
  ]
};

const INITIAL_ORDERS: Order[] = [
  {
    id: "ord-101",
    orderNumber: "SPI-2611-8492",
    customer: {
      fullName: "Venkata Raman",
      email: "venkat.raman@example.com",
      phone: "+91 98491 55210",
      addressLine1: "12-4-88 Lakshmipuram Main Road",
      city: "Guntur",
      state: "Andhra Pradesh",
      pincode: "522007"
    },
    items: [
      {
        id: "spicora-liq-chai-liq-chai-30ml",
        product: ALL_PRODUCTS.find(p => p.id === "spicora-liq-chai") || ALL_PRODUCTS[0],
        variant: { id: "liq-chai-30ml", size: "30 ml", price: 199, inStock: true, sku: "SPIC-LQ-CHAI-30" },
        quantity: 2
      },
      {
        id: "spicora-mas-red-chilli-mas-rc-500g",
        product: ALL_PRODUCTS.find(p => p.id === "spicora-mas-red-chilli") || ALL_PRODUCTS[1],
        variant: { id: "mas-rc-500g", size: "500 g", price: 349, inStock: true, sku: "SPIC-MAS-RC-500" },
        quantity: 1
      }
    ],
    subtotal: 747,
    discount: 75,
    couponCode: "SPICORA10",
    shipping: 0,
    total: 672,
    paymentMethod: "razorpay",
    paymentStatus: "Test Mode Completed",
    orderStatus: "Processing",
    trackingNumber: "DEL-AP-9923812",
    createdAt: "2026-11-20T14:30:00Z"
  },
  {
    id: "ord-102",
    orderNumber: "SPI-2611-6140",
    customer: {
      fullName: "Ananya Iyer",
      email: "ananya.iyer@example.com",
      phone: "+91 98840 88219",
      addressLine1: "Flat 402, Royal Gardens, T. Nagar",
      city: "Chennai",
      state: "Tamil Nadu",
      pincode: "600017"
    },
    items: [
      {
        id: "spicora-cb-gift-box-cb-gb-box",
        product: ALL_PRODUCTS.find(p => p.id === "spicora-cb-gift-box") || ALL_PRODUCTS[4],
        variant: { id: "cb-gb-box", size: "Luxury Keepsake Hamper", price: 1799, inStock: true, sku: "SPIC-CB-GIFT-01" },
        quantity: 1
      }
    ],
    subtotal: 1799,
    discount: 360,
    couponCode: "ROYAL20",
    shipping: 0,
    total: 1439,
    paymentMethod: "upi",
    paymentStatus: "Paid",
    orderStatus: "Shipped",
    trackingNumber: "BLR-EXP-440219",
    createdAt: "2026-11-18T10:15:00Z"
  }
];

const INITIAL_B2B: B2BEnquiry[] = [
  {
    id: "b2b-01",
    companyName: "Amaravathi Grand Luxury Hotel",
    contactPerson: "K. Subba Rao (Executive Chef)",
    email: "procurement@amaravathigrand.in",
    phone: "+91 94401 22334",
    businessType: "Hotel",
    gstin: "37AAACA1234A1Z5",
    city: "Vijayawada",
    state: "Andhra Pradesh",
    estimatedVolume: "100 - 500 kg/month",
    productInterests: ["Biryani Flavour Liquid", "Guntur Red Chilli Powder", "Royal Biryani Spice Mix"],
    notes: "Requires bulk 500ml food-grade containers of Biryani Liquid and 50kg sacks of stemless Guntur Sannam chillies.",
    createdAt: "2026-11-19T09:00:00Z",
    status: "Quotation Sent"
  },
  {
    id: "b2b-02",
    companyName: "Chai Kadak Tea Cafe Chain",
    contactPerson: "Vikram Malhotra",
    email: "operations@chaikadak.co.in",
    phone: "+91 98200 44556",
    businessType: "Tea Shop / Cafe",
    gstin: "27AABCT9988C1Z2",
    city: "Hyderabad",
    state: "Telangana",
    estimatedVolume: "Custom Liquid Batch",
    productInterests: ["Traditional Chai Masala Liquid", "Cardamom Flavour Liquid"],
    notes: "Looking for monthly supply of 500 units of 50ml Chai Liquid drops for 18 cafe locations in Hyderabad and Bangalore.",
    createdAt: "2026-11-21T11:45:00Z",
    status: "New"
  }
];

const SpicoraContext = createContext<SpicoraContextType | undefined>(undefined);

export function SpicoraProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>(ALL_PRODUCTS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [b2bEnquiries, setB2bEnquiries] = useState<B2BEnquiry[]>(INITIAL_B2B);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [user, setUser] = useState<UserProfile | null>(DEFAULT_USER);
  const [isInitialized, setIsInitialized] = useState(false);

  // Load state from localStorage on client mount
  useEffect(() => {
    try {
      const storedProds = localStorage.getItem("spicora_products");
      if (storedProds) {
        setProducts(JSON.parse(storedProds));
      }

      const storedOrders = localStorage.getItem("spicora_orders");
      if (storedOrders) {
        setOrders(JSON.parse(storedOrders));
      }

      const storedB2B = localStorage.getItem("spicora_b2b");
      if (storedB2B) {
        setB2bEnquiries(JSON.parse(storedB2B));
      }

      const storedReviews = localStorage.getItem("spicora_reviews");
      if (storedReviews) {
        setReviews(JSON.parse(storedReviews));
      }

      const storedUser = localStorage.getItem("spicora_user");
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (e) {
      console.warn("Could not load from localStorage:", e);
    }
    setIsInitialized(true);
  }, []);

  // Sync to localStorage
  useEffect(() => {
    if (!isInitialized) return;
    try {
      localStorage.setItem("spicora_products", JSON.stringify(products));
      localStorage.setItem("spicora_orders", JSON.stringify(orders));
      localStorage.setItem("spicora_b2b", JSON.stringify(b2bEnquiries));
      localStorage.setItem("spicora_reviews", JSON.stringify(reviews));
      if (user) {
        localStorage.setItem("spicora_user", JSON.stringify(user));
      }
    } catch (e) {
      console.warn("Could not sync to localStorage:", e);
    }
  }, [products, orders, b2bEnquiries, reviews, user, isInitialized]);

  // Product actions
  const updateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const createProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const resetProductsToDefault = () => {
    setProducts(ALL_PRODUCTS);
    localStorage.removeItem("spicora_products");
  };

  // Order actions
  const addOrder = (orderData: Omit<Order, "id" | "orderNumber" | "createdAt">): Order => {
    const newOrder: Order = {
      ...orderData,
      id: "ord-" + Date.now(),
      orderNumber: generateOrderNumber(),
      createdAt: new Date().toISOString()
    };
    setOrders((prev) => [newOrder, ...prev]);
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: Order["orderStatus"], trackingNumber?: string) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            orderStatus: status,
            ...(trackingNumber ? { trackingNumber } : {})
          };
        }
        return o;
      })
    );
  };

  // B2B actions
  const addB2BEnquiry = (enquiryData: Omit<B2BEnquiry, "id" | "createdAt" | "status">) => {
    const newEnquiry: B2BEnquiry = {
      ...enquiryData,
      id: "b2b-" + Date.now(),
      createdAt: new Date().toISOString(),
      status: "New"
    };
    setB2bEnquiries((prev) => [newEnquiry, ...prev]);
  };

  const updateB2BStatus = (id: string, status: B2BEnquiry["status"]) => {
    setB2bEnquiries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, status } : e))
    );
  };

  // Review actions
  const addReview = (reviewData: Omit<Review, "id" | "date" | "isDemo" | "status">) => {
    const dateStr = new Date().toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
    const newRev: Review = {
      ...reviewData,
      id: "rev-" + Date.now(),
      date: dateStr,
      isDemo: false,
      status: "Approved"
    };
    setReviews((prev) => [newRev, ...prev]);

    // Update product rating & review count
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === reviewData.productId) {
          const newCount = p.reviewCount + 1;
          const newRating = Number(((p.rating * p.reviewCount + reviewData.rating) / newCount).toFixed(1));
          return { ...p, reviewCount: newCount, rating: newRating };
        }
        return p;
      })
    );
  };

  const updateReviewStatus = (id: string, status: Review["status"]) => {
    setReviews((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
  };

  // User actions
  const loginUser = (email: string, name?: string) => {
    setUser({
      id: "usr-" + Date.now(),
      name: name || email.split("@")[0],
      email: email,
      phone: "+91 98480 99999",
      isAdmin: email.includes("admin") || email.includes("chilla"),
      addresses: DEFAULT_USER.addresses
    });
  };

  const logoutUser = () => {
    setUser(null);
    localStorage.removeItem("spicora_user");
  };

  const saveAddress = (newAddr: OrderCustomer) => {
    if (!user) return;
    setUser((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        addresses: [newAddr, ...prev.addresses.filter((a) => a.addressLine1 !== newAddr.addressLine1)]
      };
    });
  };

  return (
    <SpicoraContext.Provider
      value={{
        products,
        updateProduct,
        createProduct,
        deleteProduct,
        resetProductsToDefault,
        orders,
        addOrder,
        updateOrderStatus,
        b2bEnquiries,
        addB2BEnquiry,
        updateB2BStatus,
        reviews,
        addReview,
        updateReviewStatus,
        user,
        loginUser,
        logoutUser,
        saveAddress
      }}
    >
      {children}
    </SpicoraContext.Provider>
  );
}

export function useSpicora() {
  const context = useContext(SpicoraContext);
  if (!context) {
    throw new Error("useSpicora must be used within a SpicoraProvider");
  }
  return context;
}
