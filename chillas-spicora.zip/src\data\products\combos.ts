import { Product } from "@/types";

export const COMBO_PRODUCTS: Product[] = [
  {
    id: "spicora-cb-liquid-trio",
    name: "Signature Liquid Spice Trio",
    slug: "signature-liquid-spice-trio",
    tagline: "Our Top 3 Flagship Liquids in a Deluxe Gold Foil Box",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "BUY 2 GET 1 FREE OFFER",
    savingsAmount: 188,
    offerDetails: "Save 26% instantly + Free Spicora Precision Dropper included!",
    shortDescription: "The essential liquid spice discovery box featuring Traditional Chai Masala Liquid (30ml), Biryani Flavour Liquid (30ml), and Cardamom Flavour Liquid (30ml).",
    description: "Experience the pure magic of ultrasonic cold-extracted liquid spices. This trio brings together our three best-selling flagship liquid formulations in an elegant gold-foiled presentation box. Replaces over 1.5kg of whole spices and messy pastes. Simply drop 2-3 drops into tea, biryani, or festive sweets for instant room-filling aromatic bliss.",
    images: [
      "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Traditional Chai Masala Liquid (30 ml / 600 drops)",
      "Biryani Flavour Liquid (30 ml / 600 drops)",
      "Cardamom Flavour Liquid (30 ml / 600 drops)",
      "Complimentary Gold-Plated Precision Dropper & Dosage Guide"
    ],
    variants: [
      { id: "cb-lt-30ml", size: "3-Bottle Discovery Box (3 x 30 ml)", price: 549, compareAtPrice: 737, inStock: true, sku: "SPIC-CB-TRIO-30" },
      { id: "cb-lt-50ml", size: "Grand Family Box (3 x 50 ml)", price: 849, compareAtPrice: 1148, inStock: true, sku: "SPIC-CB-TRIO-50" }
    ],
    status: "Active",
    origin: "Guntur Culinary Extraction Facility",
    flavourNotes: ["Spicy Chai Terpenes", "Royal Biryani Saffron & Mace", "Floral Western Ghats Elaichi"],
    ingredients: ["Proprietary cold-pressed spice extracts of Cardamom, Ginger, Mace, Clove, Star Anise, Cinnamon, and Saffron distillates"],
    storageInstructions: "Store at ambient room temperature away from direct flame or heat.",
    complianceNotice: "Curated bundle of pilot-tested individual liquid products.",
    rating: 5.0,
    reviewCount: 64,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["Daily Morning Chai", "Sunday Dum Biryanis", "Festive Mithai & Kheer"]
  },
  {
    id: "spicora-cb-liquid-master",
    name: "The Complete Liquid Kitchen Lab (All 6 Drops)",
    slug: "complete-liquid-kitchen-lab",
    tagline: "The Full Culinary Revolution: 6 Master Liquid Drops + Wooden Velvet Caddy",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "SAVE 30% • BEST VALUE",
    savingsAmount: 495,
    offerDetails: "Complete 6-Bottle Collection + Handcrafted Sheesham Wood Caddy + Free Shipping",
    shortDescription: "All 6 SPICORA signature liquid flavours: Chai, Biryani, Ginger-Garlic, Cardamom, Tandoori, and Pepper in a solid Sheesham wood collector's stand.",
    description: "The ultimate showpiece for the modern gourmet kitchen. Never chop garlic, peel fibrous ginger, crush whole cardamom, or struggle with burnt masala pastes again. All 6 SPICORA liquid essences neatly organized in an engraved Sheesham wood rack with calibrated glass pipettes.",
    images: [
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Traditional Chai Masala Liquid (30 ml)",
      "Biryani Flavour Liquid (30 ml)",
      "Ginger-Garlic Flavour Liquid (30 ml)",
      "Cardamom Flavour Liquid (30 ml)",
      "Tandoori Flavour Liquid (30 ml)",
      "Pepper Flavour Liquid (30 ml)",
      "Handcrafted Sheesham Wood Presentation Rack + 2 Calibrated Droppers"
    ],
    variants: [
      { id: "cb-lm-30ml", size: "Collector's 6-Piece Lab (30 ml each)", price: 1199, compareAtPrice: 1694, inStock: true, sku: "SPIC-CB-LAB-30" },
      { id: "cb-lm-50ml", size: "Executive Chef 6-Piece Lab (50 ml each)", price: 1799, compareAtPrice: 2490, inStock: true, sku: "SPIC-CB-LAB-50" }
    ],
    status: "Active",
    origin: "Guntur Culinary Research Lab",
    flavourNotes: ["All 6 Master Spice Profiles from Chai warmth to Tandoori smoke"],
    ingredients: ["100% pure cold-extracted spice oleoresins and botanical distillates"],
    storageInstructions: "Display on kitchen counter or store in pantry. Keep droppers sealed.",
    complianceNotice: "Collection of proposed formulations. Batch verified in pilot kitchen.",
    rating: 5.0,
    reviewCount: 78,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["All Indian Cooking", "Cocktail Mixology", "Gourmet Gifting"]
  },
  {
    id: "spicora-cb-biryani-special",
    name: "Royal Dum Biryani Master Kit",
    slug: "biryani-special-kit",
    tagline: "Liquid Aroma + Potli Whole Spices + Masala + Saffron",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "CHEF'S CHOICE • SAVE 25%",
    savingsAmount: 300,
    offerDetails: "Save ₹300! Everything needed for restaurant-grade Hyderabadi Dum Biryani.",
    shortDescription: "Includes Biryani Flavour Liquid (30ml), Royal Biryani Potli Mix (100g), Biryani Masala Powder (200g), and Grade-A Kashmiri Saffron (1g).",
    description: "Crafted for biryani obsessives. From boiling fragrant basmati with the muslin spice potli to marinating tender meat with the slow-roasted masala and infusing the final dum steam with our signature Biryani Liquid Drops and pure Kashmiri saffron threads.",
    images: [
      "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Biryani Flavour Liquid (30 ml / 600 drops)",
      "Biryani Masala Powder (200 g)",
      "Royal Biryani Whole Spice Potli Mix (100 g)",
      "Pure Kashmiri Mongra Saffron (1 g glass vial)"
    ],
    variants: [
      { id: "cb-bs-kit", size: "Complete 4-Piece Biryani Box", price: 899, compareAtPrice: 1199, inStock: true, sku: "SPIC-CB-BIRY-01" }
    ],
    status: "Active",
    origin: "Guntur & Hyderabad Culinary Labs",
    flavourNotes: ["Regal Saffron", "Shahi Jeera", "Sweet Mace", "Cold-Extracted Dum Aroma"],
    ingredients: ["Biryani Masala", "Biryani Flavour Drops", "Whole Potli Botanicals", "Pampore Saffron"],
    storageInstructions: "Keep in a cool dry space.",
    complianceNotice: "Curated bundle of proposed and pilot tested products.",
    rating: 5.0,
    reviewCount: 45,
    isFeatured: true,
    suggestedPairings: ["Sunday Chicken Dum Biryani", "Mutton Biryani", "Kolkata Biryani"]
  },
  {
    id: "spicora-cb-chai-lovers",
    name: "Chai Lover's Liquid & Powder Elixir Kit",
    slug: "chai-lovers-kit",
    tagline: "Instant Liquid Drops + Stone Ground Masala + Whole Pods",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "SAVE 23% • BEST SELLER",
    savingsAmount: 191,
    offerDetails: "Special Tea Lover Offer: Includes 2 Liquid Drops + Stone Ground Powder + Whole Pods",
    shortDescription: "Chai Masala Powder (100g), Traditional Chai Liquid Drops (30ml), Cardamom Liquid Drops (30ml), and Idukki Green Cardamom (50g).",
    description: "Every tea lover understands that a perfect cup of chai is sacred. This kit lets you alternate between simmering stone-ground spices for slow evening tea and rapid 2-drop instant morning brews with concentrated liquid extracts.",
    images: [
      "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Traditional Chai Masala Liquid Drops (30 ml)",
      "Cardamom Flavour Liquid Drops (30 ml)",
      "Chai Masala Powder (100 g tin)",
      "Western Ghats Whole Green Cardamom 8mm (50 g)"
    ],
    variants: [
      { id: "cb-cl-box", size: "Chai Lovers Gift Set", price: 649, compareAtPrice: 840, inStock: true, sku: "SPIC-CB-CHAI-01" }
    ],
    status: "Active",
    origin: "Guntur Blend House",
    flavourNotes: ["Spicy Sonth", "Green Cardamom", "Clove Tingle", "Sweet Cinnamon"],
    ingredients: ["Chai Masala Powder", "Chai Flavour Liquid", "Cardamom Liquid", "Idukki Green Cardamom Pods"],
    storageInstructions: "Store sealed.",
    complianceNotice: "Bundle of proposed formulation tea spices.",
    rating: 4.9,
    reviewCount: 36,
    isFeatured: true,
    suggestedPairings: ["Morning Tea", "Evening High-Tea with Pakoras", "Tea Stall Lovers"]
  },
  {
    id: "spicora-cb-liquid-fry-sizzle",
    name: "Liquid Sizzle & Tandoori BBQ Combo",
    slug: "liquid-sizzle-tandoori-bbq-combo",
    tagline: "Tandoori Liquid + Pepper Liquid + Non-Veg Fry Masalas",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "WEEKEND SPECIAL • 27% OFF",
    savingsAmount: 281,
    offerDetails: "Save ₹281 on this sizzler set! Perfect for grills, tikkas, and crispy pan-fries.",
    shortDescription: "Tandoori Flavour Liquid (30ml), Pepper Flavour Liquid (30ml), Ginger-Garlic Liquid (30ml), Chicken Fry Masala (200g), and Fish Fry Masala (200g).",
    description: "Designed for sizzling home barbecues and weekend fry feasts. Blend the smoky Tandoori and Pepper drops directly into yoghurt marinades for paneer or chicken, while the Ginger-Garlic liquid coats seafood effortlessly without burning in hot oil.",
    images: [
      "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Tandoori Flavour Liquid (30 ml / Smoky Char Extract)",
      "Pepper Flavour Liquid (30 ml / Malabar Black Pepper)",
      "Ginger-Garlic Flavour Liquid (30 ml / Zero-Splatter)",
      "Chicken Fry Masala (200 g pouch)",
      "Fish Fry Masala (200 g pouch)"
    ],
    variants: [
      { id: "cb-ls-box", size: "5-Piece Sizzler Box", price: 749, compareAtPrice: 1030, inStock: true, sku: "SPIC-CB-SIZZLE-01" }
    ],
    status: "Active",
    origin: "Guntur Meat & BBQ Traditions",
    flavourNotes: ["Smoky Hickory & Coal", "Sharp Tellicherry Pepper", "Crispy Garlic Crust"],
    ingredients: ["Tandoori Liquid", "Pepper Liquid", "Ginger-Garlic Liquid", "Chicken Fry Mix", "Fish Fry Mix"],
    storageInstructions: "Keep in a cool dry space.",
    complianceNotice: "Curated bundle of pilot tested meat seasonings.",
    rating: 4.9,
    reviewCount: 31,
    isFeatured: true,
    suggestedPairings: ["Weekend Tikkas", "Pan Fry Prawns & Fish", "Crispy Chicken Fry"]
  },
  {
    id: "spicora-cb-andhra-collection",
    name: "Andhra Fire & Terroir Collection",
    slug: "andhra-spice-collection",
    tagline: "Direct from Guntur: Signature Red Chilli + Masalas + Liquid Ginger-Garlic",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    discountBadge: "REGIONAL ICON • SAVE 24%",
    savingsAmount: 241,
    offerDetails: "Authentic Guntur terroir flavours: Includes high-grade chilli, liquids, and Telugu fry blends.",
    shortDescription: "Guntur Sannam Red Chilli Powder (500g), Ginger-Garlic Liquid (30ml), Andhra Special Masala (200g), and Pulihora Spice Mix (200g).",
    description: "Direct from the spice capital of India. Experience the unmistakable fiery punch, deep red hue, and rustic spice blends that define Telugu culinary excellence, paired with our zero-water Ginger-Garlic liquid extract.",
    images: [
      "https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Guntur Sannam Red Chilli Powder (500 g pouch)",
      "Ginger-Garlic Flavour Liquid (30 ml)",
      "Andhra Special Masala (200 g jar)",
      "Temple Style Pulihora Spice Mix (200 g jar)"
    ],
    variants: [
      { id: "cb-ac-box", size: "Heritage Andhra Box (1.1 kg + Liquid)", price: 799, compareAtPrice: 1040, inStock: true, sku: "SPIC-CB-AND-01" }
    ],
    status: "Active",
    origin: "Guntur District, Andhra Pradesh",
    flavourNotes: ["Signature Guntur Heat", "Fresh Ginger-Garlic Pungency", "Temple Pulihora Sesame"],
    ingredients: ["Pure Guntur Sannam Red Chilli", "Ginger-Garlic Oleoresin", "Andhra Special Masala", "Pulihora Spice Mix"],
    storageInstructions: "Airtight storage away from direct sunlight.",
    complianceNotice: "Curated regional collection. Quality tested in pilot batches.",
    rating: 5.0,
    reviewCount: 53,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["Traditional Telugu Meals", "Pickle Making", "Sunday Non-Veg Lunch"]
  },
  {
    id: "spicora-cb-kitchen-starter",
    name: "Kitchen Starter Kit + Liquid Duo",
    slug: "kitchen-starter-kit",
    tagline: "The Essential 6-Spice Daily Pantry + Chai & Biryani Liquid Drops",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "PANTRY UPGRADE • 25% OFF",
    savingsAmount: 300,
    offerDetails: "Complete 8-Piece Daily Setup: 6 Core Masalas + 2 Flagship Liquid Drops",
    shortDescription: "Guntur Red Chilli (200g), Turmeric (200g), Coriander (200g), Cumin (200g), Garam Masala (100g), Whole Cumin (100g), Chai Liquid (30ml), and Biryani Liquid (30ml).",
    description: "The complete upgrade for your everyday kitchen. Combines the sacred essential daily powdered spices with our modern liquid spice technology. Cook rich dal and sabzi with stone-ground masalas, and make instant restaurant chai and biryani with pure liquid drops.",
    images: [
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Guntur Red Chilli Powder (200 g)",
      "Turmeric Powder (200 g)",
      "Coriander Powder (200 g)",
      "Cumin Powder (200 g)",
      "Garam Masala (100 g)",
      "Whole Cumin Seeds (100 g)",
      "Traditional Chai Masala Liquid (30 ml)",
      "Biryani Flavour Liquid (30 ml)"
    ],
    variants: [
      { id: "cb-ks-standard", size: "Complete 8-Piece Pantry Set", price: 899, compareAtPrice: 1199, inStock: true, sku: "SPIC-CB-KS-STD" },
      { id: "cb-ks-deluxe", size: "Deluxe Pantry Box (500g Powders + 50ml Liquids)", price: 1499, compareAtPrice: 1990, inStock: true, sku: "SPIC-CB-KS-DLX" }
    ],
    status: "Active",
    origin: "Guntur Heritage Facility",
    flavourNotes: ["Balanced Everyday Harmony", "Single-Origin Purity", "Sun-Dried Freshness"],
    ingredients: ["Guntur Sannam Chilli Powder", "High-Curcumin Turmeric", "Roasted Coriander Powder", "Cumin Powder", "Garam Masala", "Whole Cumin Seeds", "Chai Extract", "Biryani Extract"],
    storageInstructions: "Store jars in ambient dry conditions.",
    complianceNotice: "Curated bundle of pilot-tested individual products.",
    rating: 4.9,
    reviewCount: 39,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["All Indian Home Cooking", "Housewarming Gifts", "Beginner Chefs"]
  },
  {
    id: "spicora-cb-gift-box",
    name: "Premium Indian Spice & Liquid Gift Box",
    slug: "premium-indian-spice-gift-box",
    tagline: "Gold-Embossed Luxury Keepsake Hamper with Handcrafted Drops & Whole Botanicals",
    categoryId: "combo-packs",
    categoryName: "Combo Packs",
    packagingType: "combo",
    isLiquidFlagship: true,
    discountBadge: "LUXURY FESTIVE GIFT • 27% OFF",
    savingsAmount: 651,
    offerDetails: "Save ₹651 on this opulent gold-foiled wooden presentation box with magnetic closure.",
    shortDescription: "Ultra-luxury gift box with Kashmiri Saffron (2g), Idukki Green Cardamom (100g), Tellicherry Extra Bold Pepper (100g), Ceylon Cinnamon (100g), Chai Liquid Drops (30ml), and Cardamom Liquid Drops (30ml).",
    description: "Presented in a royal forest-green and gold-embossed keepsake rigid box with magnetic closure and satin ribbon. The quintessential gift of royal Indian hospitality for weddings, corporate executives, and festival celebrations.",
    images: [
      "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80"
    ],
    bundleItems: [
      "Kashmiri Mongra Saffron (2 g glass vial with cork)",
      "Idukki Green Cardamom 8mm (100 g gold tin)",
      "Tellicherry Extra Bold Black Pepper (100 g gold tin)",
      "Ceylon Cinnamon Quills (100 g gold tin)",
      "Traditional Chai Masala Liquid Drops (30 ml)",
      "Cardamom Flavour Liquid Drops (30 ml)",
      "Gold-Plated Tea Spoon & Calibrated Liquid Dropper"
    ],
    variants: [
      { id: "cb-gb-box", size: "Luxury Keepsake Hamper", price: 1799, compareAtPrice: 2450, inStock: true, sku: "SPIC-CB-GIFT-01" }
    ],
    status: "Active",
    origin: "All-India Terroirs, Packed in Guntur",
    flavourNotes: ["Luxury Saffron", "Regal Cardamom", "Tellicherry Pepper", "Ceylon Cinnamon"],
    ingredients: ["Kashmiri Mongra Saffron", "Idukki Green Cardamom 8mm", "Tellicherry Black Pepper", "Ceylon Cinnamon", "Traditional Chai Liquid", "Cardamom Liquid"],
    storageInstructions: "Keep in cool ambient environment.",
    complianceNotice: "Proposed luxury gift bundle. High-grade botanical certifications.",
    rating: 5.0,
    reviewCount: 41,
    isFeatured: true,
    isBestSeller: true,
    suggestedPairings: ["Diwali & Festive Gifting", "Corporate Partner Gifts", "Wedding Return Favours"]
  }
];
