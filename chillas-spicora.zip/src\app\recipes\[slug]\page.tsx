"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  Clock,
  ChefHat,
  Users,
  Sparkles,
  ArrowRight,
  ShoppingBag,
  CheckCircle2,
  ShieldAlert,
  ArrowLeft,
  Play
} from "lucide-react";
import { RECIPES } from "@/data/recipes";

export default function RecipeDetailPage() {
  const { slug } = useParams();
  const recipe = RECIPES.find((r) => r.slug === slug);
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);

  if (!recipe) {
    return (
      <div className="bg-[#080C0A] min-h-screen py-20 px-4 text-center space-y-4 text-white">
        <h1 className="font-serif text-3xl font-bold text-[#D4A84F]">Recipe Not Found</h1>
        <p className="text-stone-400">The culinary guide you requested does not exist.</p>
        <Link
          href="/recipes"
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#174D35] text-white text-xs font-bold uppercase tracking-wider"
        >
          Back to Recipes
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-[#080C0A] text-[#F3F4F1] min-h-screen py-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Navigation Breadcrumb */}
        <Link
          href="/recipes"
          className="inline-flex items-center gap-1.5 text-xs font-bold text-[#D4A84F] hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to All Heritage Recipes & Videos
        </Link>

        {/* Recipe Header */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="bg-[#174D35] text-[#D4A84F] text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider border border-[#D4A84F]/30">
              {recipe.category}
            </span>
            <span className={`text-xs font-bold px-3 py-1 rounded-full border ${
              recipe.dietary === "Veg"
                ? "bg-emerald-950 text-emerald-300 border-emerald-500/40"
                : "bg-red-950 text-red-300 border-red-500/40"
            }`}>
              {recipe.dietary === "Veg" ? "🥬 Vegetarian" : "🍗 Non-Vegetarian"}
            </span>
          </div>

          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white">
            {recipe.title}
          </h1>

          <p className="text-sm sm:text-base text-stone-300 font-light max-w-3xl leading-relaxed">
            {recipe.description}
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-[#101713] border border-[#D4A84F]/30 shadow-md">
            <div className="text-center border-r border-white/10 last:border-none">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Prep Time</span>
              <span className="text-xs sm:text-sm font-bold text-white">{recipe.prepTime}</span>
            </div>
            <div className="text-center border-r border-white/10 last:border-none">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Cook Time</span>
              <span className="text-xs sm:text-sm font-bold text-white">{recipe.cookTime}</span>
            </div>
            <div className="text-center border-r border-white/10 last:border-none">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Servings</span>
              <span className="text-xs sm:text-sm font-bold text-white">{recipe.servings}</span>
            </div>
            <div className="text-center">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Mastery</span>
              <span className="text-xs sm:text-sm font-bold text-[#D4A84F]">{recipe.difficulty}</span>
            </div>
          </div>
        </div>

        {/* Video Player or Hero Visual */}
        <div className="relative aspect-[16/9] w-full rounded-3xl overflow-hidden shadow-2xl border border-[#D4A84F]/40 bg-black">
          {isPlayingVideo && recipe.videoUrl ? (
            <iframe
              src={`${recipe.videoUrl}?autoplay=1&rel=0&modestbranding=1`}
              title={recipe.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          ) : (
            <>
              <Image
                src={recipe.videoThumbnail || recipe.image}
                alt={recipe.title}
                fill
                priority
                className="object-cover brightness-85"
              />
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center space-y-3">
                <button
                  onClick={() => setIsPlayingVideo(true)}
                  className="w-20 h-20 rounded-full bg-[#D4A84F] hover:bg-[#F3DC9B] text-stone-950 flex items-center justify-center shadow-2xl hover:scale-110 transition-transform"
                  title="Play Masterclass Video"
                >
                  <Play className="w-8 h-8 fill-current ml-1" />
                </button>
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-white bg-black/70 px-4 py-1.5 rounded-full border border-white/20">
                  Watch Recipe Video ({recipe.videoDuration || "10 mins"})
                </span>
              </div>
            </>
          )}
        </div>

        {/* Paired Spice Feature Box */}
        <div className="bg-[#101713] text-white p-6 rounded-3xl border border-[#D4A84F]/40 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6 glow-card-gold">
          <div className="space-y-1.5 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-bold text-[#D4A84F] uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              Suggested Spice Pairing: {recipe.spicoraPairing.productName}
            </div>
            <p className="text-xs text-stone-200 font-light max-w-xl leading-relaxed">
              {recipe.spicoraPairing.tip}
            </p>
            <span className="text-[10px] text-emerald-400 italic block">
              {recipe.verifiedTesting
                ? "✓ Tested and kitchen-validated in SPICORA culinary trials"
                : "Proposed culinary pairing concept"}
            </span>
          </div>

          <Link
            href={`/shop/${recipe.spicoraPairing.productSlug}`}
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 whitespace-nowrap shadow-md transition-colors flex items-center gap-1.5"
          >
            <ShoppingBag className="w-4 h-4" />
            Shop Paired Spice
          </Link>
        </div>

        {/* Ingredients & Instructions Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Ingredients Column */}
          <div className="lg:col-span-5 bg-[#101713] p-6 sm:p-8 rounded-3xl border border-white/10 shadow-md space-y-4">
            <h2 className="font-serif font-bold text-xl text-[#D4A84F] border-b border-white/10 pb-3">
              Recipe Ingredients
            </h2>
            <ul className="space-y-3 text-xs sm:text-sm text-stone-300">
              {recipe.ingredients.map((ing, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4A84F] mt-2 flex-shrink-0" />
                  <span className="leading-relaxed font-light">{ing}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Instructions Column */}
          <div className="lg:col-span-7 bg-[#101713] p-6 sm:p-8 rounded-3xl border border-white/10 shadow-md space-y-6">
            <h2 className="font-serif font-bold text-xl text-[#D4A84F] border-b border-white/10 pb-3">
              Step-by-Step Cooking Method
            </h2>
            <div className="space-y-6">
              {recipe.instructions.map((step, idx) => (
                <div key={idx} className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-[#174D35] text-[#D4A84F] font-serif font-bold text-sm flex items-center justify-center flex-shrink-0 border border-[#D4A84F]/40 shadow-sm">
                    {idx + 1}
                  </div>
                  <div className="flex-1 text-xs sm:text-sm text-stone-300 leading-relaxed pt-1 font-light">
                    {step}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-stone-400 flex items-start gap-3">
          <ShieldAlert className="w-4 h-4 text-[#D4A84F] flex-shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Culinary Testing Notice:</strong> Suggested pairings are curated by SPICORA food development chefs. Ingredients and cooking times may vary based on domestic heat sources and regional ingredients.
          </p>
        </div>
      </div>
    </div>
  );
}
