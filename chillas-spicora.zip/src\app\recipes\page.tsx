"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Clock, ChefHat, Sparkles, ArrowRight, Play, ShoppingBag, Filter } from "lucide-react";
import { RECIPES } from "@/data/recipes";
import { RecipeVideoModal } from "@/components/recipes/RecipeVideoModal";
import { Recipe } from "@/types";

export default function RecipesPage() {
  const [filter, setFilter] = useState<string>("All");
  const [dietaryFilter, setDietaryFilter] = useState<"All" | "Veg" | "Non-Veg">("All");
  const [selectedRecipeVideo, setSelectedRecipeVideo] = useState<Recipe | null>(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  const categories = [
    "All",
    "Traditional Veg",
    "Traditional Non-Veg",
    "Biryani",
    "Seafood",
    "Poultry",
    "Andhra Curry",
    "Chai"
  ];

  const filteredRecipes = RECIPES.filter((r) => {
    if (filter !== "All" && r.category !== filter) return false;
    if (dietaryFilter !== "All" && r.dietary !== dietaryFilter) return false;
    return true;
  });

  const openVideoModal = (recipe: Recipe) => {
    setSelectedRecipeVideo(recipe);
    setIsVideoModalOpen(true);
  };

  return (
    <div className="bg-[#080C0A] text-[#F3F4F1] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#174D35] to-[#0f3424] rounded-3xl p-8 sm:p-12 text-white border border-[#D4A84F]/40 shadow-xl space-y-3 relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-spice-pattern opacity-20 pointer-events-none" />
          <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#D4A84F] block">
            CULINARY STUDIO & VIDEO MASTERCLASSES
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-extrabold text-white">
            Heritage Recipe Inspirations & Videos
          </h1>
          <p className="text-sm text-stone-200 max-w-2xl font-light leading-relaxed">
            Master traditional vegetarian delicacies like Andhra Gutti Vankaya and Gongura Pappu, iconic non-veg feasts like Gongura Mamsam and Kundapura Chicken Ghee Roast, and Kadak Masala Chai. Watch preparation videos and shop paired spices.
          </p>
        </div>

        {/* Filters Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#101713] p-4 rounded-2xl border border-white/10">
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                  filter === cat
                    ? "bg-[#D4A84F] text-stone-950 shadow-md"
                    : "bg-white/5 text-stone-300 border border-white/10 hover:border-[#D4A84F]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Veg / Non-Veg Toggle */}
          <div className="flex items-center gap-1.5 self-end sm:self-auto">
            {(["All", "Veg", "Non-Veg"] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDietaryFilter(d)}
                className={`px-3 py-1 text-xs font-bold rounded-lg border transition-all ${
                  dietaryFilter === d
                    ? d === "Veg"
                      ? "bg-emerald-950 text-emerald-300 border-emerald-500"
                      : d === "Non-Veg"
                      ? "bg-red-950 text-red-300 border-red-500"
                      : "bg-[#174D35] text-white border-[#D4A84F]"
                    : "bg-transparent text-stone-400 border-white/10 hover:text-white"
                }`}
              >
                {d === "Veg" ? "🥬 Veg Only" : d === "Non-Veg" ? "🍗 Non-Veg Only" : "All Diets"}
              </button>
            ))}
          </div>
        </div>

        {/* Recipe Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredRecipes.map((recipe) => (
            <div
              key={recipe.id}
              className="bg-[#101713] rounded-3xl border border-[#D4A84F]/25 overflow-hidden shadow-xl flex flex-col justify-between group hover:border-[#D4A84F] transition-all duration-300"
            >
              {/* Video Thumbnail with Play Button */}
              <div className="relative aspect-[16/10] overflow-hidden bg-black">
                <Image
                  src={recipe.videoThumbnail || recipe.image}
                  alt={recipe.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500 brightness-90"
                />
                <div className="absolute inset-0 bg-black/35 group-hover:bg-black/20 transition-colors" />

                {/* Play Button Trigger */}
                <button
                  onClick={() => openVideoModal(recipe)}
                  className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-[#D4A84F] hover:bg-[#F3DC9B] text-stone-950 flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform"
                  title="Watch Video"
                >
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                </button>

                <span className={`absolute top-4 left-4 text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                  recipe.dietary === "Veg"
                    ? "bg-emerald-950 text-emerald-300 border border-emerald-500/50"
                    : "bg-red-950 text-red-300 border border-red-500/50"
                }`}>
                  {recipe.dietary === "Veg" ? "🥬 Veg" : "🍗 Non-Veg"}
                </span>

                <span className="absolute bottom-4 right-4 bg-black/80 backdrop-blur-sm text-[#D4A84F] text-xs font-mono font-bold px-2.5 py-1 rounded-md flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  {recipe.videoDuration || "10 mins"}
                </span>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-stone-400">
                    <span>{recipe.category}</span>
                    <span>Difficulty: <strong className="text-white">{recipe.difficulty}</strong></span>
                  </div>

                  <h3 className="font-serif font-bold text-xl text-white group-hover:text-[#D4A84F] transition-colors leading-snug">
                    {recipe.title}
                  </h3>

                  <p className="text-xs text-stone-300 leading-relaxed line-clamp-2 font-light">
                    {recipe.description}
                  </p>
                </div>

                {/* Suggested Pairing Pill */}
                <div className="pt-3 border-t border-white/10 space-y-3">
                  <div className="bg-[#174D35]/30 border border-[#D4A84F]/30 p-3 rounded-2xl text-xs space-y-1">
                    <div className="flex items-center gap-1 text-[11px] font-bold text-[#D4A84F] uppercase">
                      <Sparkles className="w-3 h-3" />
                      Suggested Pairing
                    </div>
                    <div className="font-serif font-bold text-white">
                      {recipe.spicoraPairing.productName}
                    </div>
                    <p className="text-[11px] text-stone-300 line-clamp-1 italic font-light">
                      {recipe.spicoraPairing.tip}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openVideoModal(recipe)}
                      className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 flex items-center justify-center gap-1.5 shadow-md transition-all"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Watch Video
                    </button>

                    <Link
                      href={`/recipes/${recipe.slug}`}
                      className="px-4 py-2.5 rounded-xl border border-white/20 hover:border-[#D4A84F] text-white font-bold text-xs flex items-center justify-center transition-colors"
                    >
                      Method
                    </Link>

                    <Link
                      href={`/shop/${recipe.spicoraPairing.productSlug}`}
                      className="p-2.5 rounded-xl border border-[#D4A84F]/50 text-[#D4A84F] hover:bg-[#D4A84F] hover:text-stone-950 transition-colors"
                      title="Shop Paired Spice"
                    >
                      <ShoppingBag className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Video Modal */}
      <RecipeVideoModal
        recipe={selectedRecipeVideo}
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
      />
    </div>
  );
}
