"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { X, Plus, Minus, Trash2, ArrowRight, ShoppingBag, ShieldCheck, Tag } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatINR } from "@/lib/utils";

export function CartDrawer() {
  const {
    isOpen,
    closeCart,
    items,
    removeItem,
    updateQuantity,
    subtotal,
    discount,
    shipping,
    total,
    appliedCoupon,
    couponError,
    applyCoupon,
    removeCoupon,
  } = useCart();

  const [couponInput, setCouponInput] = useState("");

  if (!isOpen) return null;

  const freeShippingThreshold = 499;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const freeShippingProgress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput) return;
    const success = applyCoupon(couponInput);
    if (success) {
      setCouponInput("");
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={closeCart}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FFF8E9] shadow-2xl flex flex-col border-l border-[#D4A84F]/30">
          {/* Header */}
          <div className="p-5 bg-[#174D35] text-white flex items-center justify-between border-b border-[#D4A84F]/30">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#D4A84F]" />
              <h2 className="font-serif text-lg font-bold tracking-wide">
                Your Spice Cart ({items.reduce((acc, i) => acc + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={closeCart}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/80 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Meter */}
          <div className="bg-[#13422E] px-5 py-3 text-white text-xs border-b border-[#D4A84F]/20">
            {remainingForFreeShipping > 0 ? (
              <p className="mb-1.5">
                Add <span className="font-bold text-[#D4A84F]">{formatINR(remainingForFreeShipping)}</span> more to unlock <span className="font-semibold text-emerald-300">FREE India Shipping</span>!
              </p>
            ) : (
              <p className="font-semibold text-emerald-300 flex items-center gap-1.5 mb-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4A84F]" />
                You unlocked FREE shipping across India!
              </p>
            )}
            <div className="w-full bg-black/30 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#D4A84F] to-emerald-400 h-full transition-all duration-300"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Item List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {items.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-20 h-20 rounded-full bg-[#174D35]/10 flex items-center justify-center mx-auto text-[#174D35]">
                  <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
                </div>
                <h3 className="font-serif text-xl font-bold text-[#174D35]">
                  Your cart is empty
                </h3>
                <p className="text-sm text-[#5E6C65] max-w-xs mx-auto">
                  Explore our cold-extracted liquid spices, stone-ground masalas, and Grade-A whole botanicals.
                </p>
                <Link
                  href="/shop"
                  onClick={closeCart}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#174D35] text-white font-medium text-sm hover:bg-[#13422E] shadow-md transition-colors"
                >
                  Explore Spice Shop
                  <ArrowRight className="w-4 h-4 text-[#D4A84F]" />
                </Link>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-3.5 bg-white rounded-xl border border-[#D4A84F]/20 shadow-sm"
                >
                  <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-stone-100 flex-shrink-0">
                    <Image
                      src={item.product.images[0]}
                      alt={item.product.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <Link
                          href={`/shop/${item.product.slug}`}
                          onClick={closeCart}
                          className="font-serif text-sm font-bold text-[#174D35] hover:text-[#D4A84F] line-clamp-1 transition-colors"
                        >
                          {item.product.name}
                        </Link>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-stone-400 hover:text-red-600 transition-colors ml-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-[#5E6C65] font-medium mt-0.5">
                        Pack: <span className="text-[#174D35] font-semibold">{item.variant.size}</span>
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-stone-100">
                      <div className="flex items-center border border-stone-200 rounded-lg overflow-hidden bg-stone-50">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-stone-200 text-stone-700 transition-colors"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 py-0.5 text-xs font-semibold text-stone-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-stone-200 text-stone-700 transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-bold text-[#174D35]">
                          {formatINR(item.variant.price * item.quantity)}
                        </span>
                        {item.variant.compareAtPrice && (
                          <span className="block text-[10px] text-stone-400 line-through">
                            {formatINR(item.variant.compareAtPrice * item.quantity)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout */}
          {items.length > 0 && (
            <div className="p-5 bg-white border-t border-[#D4A84F]/30 space-y-4">
              {/* Promo Code Box */}
              <div>
                {appliedCoupon ? (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-lg text-xs text-emerald-800">
                    <div className="flex items-center gap-1.5 font-medium">
                      <Tag className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Code <strong>{appliedCoupon.code}</strong> applied ({appliedCoupon.discountPercent}% OFF)</span>
                    </div>
                    <button
                      onClick={removeCoupon}
                      className="text-emerald-700 hover:text-red-600 font-semibold underline text-[11px]"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Coupon code (e.g. SPICORA10)"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-[#174D35] text-white text-xs font-semibold rounded-lg hover:bg-[#13422E] transition-colors"
                    >
                      Apply
                    </button>
                  </form>
                )}
                {!appliedCoupon && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <button
                      type="button"
                      onClick={() => { setCouponInput("LIQUIDCOMBO25"); }}
                      className="text-[10px] bg-amber-50 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-full hover:bg-amber-100 flex items-center gap-1 font-bold"
                    >
                      🔥 LIQUIDCOMBO25 (25% OFF)
                    </button>
                    <button
                      type="button"
                      onClick={() => { setCouponInput("SPICORA10"); }}
                      className="text-[10px] bg-stone-100 text-stone-700 border border-stone-300 px-2 py-0.5 rounded-full hover:bg-stone-200"
                    >
                      SPICORA10 (10% OFF)
                    </button>
                  </div>
                )}
                {couponError && (
                  <p className="text-red-600 text-[11px] mt-1">{couponError}</p>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-stone-900">{formatINR(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount ({appliedCoupon?.code})</span>
                    <span className="font-semibold">-{formatINR(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Standard Shipping</span>
                  <span>{shipping === 0 ? <strong className="text-emerald-700">FREE</strong> : formatINR(shipping)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-stone-200 text-sm font-bold text-[#174D35]">
                  <span>Estimated Total</span>
                  <span>{formatINR(total)}</span>
                </div>
                <p className="text-[10px] text-stone-400 text-center">
                  *All prices in INR. GST included. Food safety demo ordering mode.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <Link
                  href="/cart"
                  onClick={closeCart}
                  className="w-full text-center py-2.5 rounded-lg border border-[#174D35] text-[#174D35] font-semibold text-xs hover:bg-[#174D35]/5 transition-colors"
                >
                  View Full Cart
                </Link>
                <Link
                  href="/checkout"
                  onClick={closeCart}
                  className="w-full text-center py-2.5 rounded-lg bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs hover:brightness-105 shadow-md flex items-center justify-center gap-1.5 transition-all"
                >
                  Checkout Now
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
