"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ShoppingBag,
  Heart,
  Search,
  Menu,
  X,
  Phone,
  Shield,
  User,
  Sparkles,
  Droplets,
  Flame,
  Gift
} from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useSpicora } from "@/context/SpicoraContext";

export function Navbar() {
  const pathname = usePathname();
  const { openCart, itemCount, total } = useCart();
  const { wishlistCount } = useWishlist();
  const { user } = useSpicora();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const navLinks = [
    { name: "Home", href: "/" },
    { 
      name: "Liquid Drops", 
      href: "/shop?category=signature-liquid-flavours", 
      badge: "HERO PRODUCT", 
      badgeClass: "bg-[#D4A84F] text-stone-950 font-black",
      icon: Droplets 
    },
    { 
      name: "Combo Offers", 
      href: "/shop?category=combo-packs", 
      badge: "SAVE 30%", 
      badgeClass: "bg-[#C83E24] text-white font-extrabold animate-pulse",
      icon: Gift 
    },
    { name: "All Spices", href: "/shop" },
    { name: "Recipes & Videos", href: "/recipes" },
    { name: "Wholesale B2B", href: "/wholesale" },
    { name: "About Us", href: "/about" },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/shop?q=${encodeURIComponent(searchQuery.trim())}`;
      setSearchOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full shadow-2xl bg-[#080C0A]/95 backdrop-blur-md border-b border-[#D4A84F]/25">
      {/* Top Heritage & Flagship Liquid Notice Ribbon */}
      <div className="bg-[#050806] text-[#D4A84F] text-[11px] font-semibold tracking-wider px-4 py-1.5 flex items-center justify-between border-b border-white/5">
        <div className="hidden sm:flex items-center gap-2">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#D4A84F] animate-pulse" />
          <span className="text-white font-bold">HERO INNOVATION:</span>
          <span>1 DROP = 1 SPOON OF SPICE • ZERO SPLATTER OR BURNING</span>
        </div>
        <div className="mx-auto sm:mx-0 flex items-center gap-4 text-center">
          <span className="text-[#F4E6BE] font-bold flex items-center gap-1">
            <Gift className="w-3 h-3 text-[#E59E1B]" />
            Combo Offers: Up to 30% OFF Bundles
          </span>
          <span className="hidden md:inline text-white/30">|</span>
          <span className="hidden md:inline text-emerald-400 font-bold">Free India Delivery on ₹499+</span>
        </div>
        <div className="hidden lg:flex items-center gap-4 text-stone-300">
          <Link href="/admin" className="hover:text-[#D4A84F] flex items-center gap-1 transition-colors">
            <Shield className="w-3 h-3 text-[#D4A84F]" />
            <span>Admin Ops</span>
          </Link>
          <a href="tel:+919848012345" className="hover:text-[#D4A84F] flex items-center gap-1 transition-colors">
            <Phone className="w-3 h-3 text-[#D4A84F]" />
            <span>+91 98480 12345</span>
          </a>
        </div>
      </div>

      {/* Main Navbar matching the reference UI mockup */}
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between h-20">
          {/* Brand Logo */}
          <div className="flex-shrink-0">
            <Logo variant="light" size="md" />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => {
              const isActive = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`text-[11px] xl:text-xs uppercase font-bold tracking-[0.12em] transition-colors py-1 relative flex items-center gap-1.5 group ${
                    isActive
                      ? "text-[#D4A84F]"
                      : "text-stone-300 hover:text-[#D4A84F]"
                  }`}
                >
                  {link.icon && <link.icon className="w-3.5 h-3.5 text-[#D4A84F]" />}
                  {link.name}
                  {link.badge && (
                    <span className={`text-[8px] font-black px-1.5 py-0.2 rounded-full uppercase leading-tight ${link.badgeClass}`}>
                      {link.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#D4A84F] rounded-full" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Icons matching reference image */}
          <div className="flex items-center gap-3 sm:gap-4 text-stone-200">
            {/* Search Trigger */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 hover:text-[#D4A84F] hover:bg-white/5 rounded-full transition-colors"
              title="Search Spices"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist */}
            <Link
              href="/account?tab=wishlist"
              className="relative p-2 hover:text-[#D4A84F] hover:bg-white/5 rounded-full transition-colors"
              title="My Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 bg-[#C83E24] text-white text-[9px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Account / Admin Portal */}
            <Link
              href={user?.isAdmin ? "/admin" : "/account"}
              className="p-2 hover:text-[#D4A84F] hover:bg-white/5 rounded-full transition-colors flex items-center gap-1.5"
              title={user ? user.name : "Account"}
            >
              <User className="w-5 h-5" />
            </Link>

            {/* Cart with Red Notification Badge matching the reference image */}
            <button
              onClick={openCart}
              className="relative p-2 hover:text-[#D4A84F] hover:bg-white/5 rounded-full transition-colors group"
              title="View Cart"
            >
              <ShoppingBag className="w-5 h-5 group-hover:scale-105 transition-transform" />
              {itemCount > 0 && (
                <span className="absolute top-0.5 right-0.5 bg-[#C83E24] text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-lg border border-black animate-scale-in">
                  {itemCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-300 hover:text-white"
              title="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Real-time Search Dropdown */}
        {searchOpen && (
          <div className="py-3 px-2 border-t border-white/10">
            <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search Chai liquid drops, Biryani liquid, Combos, Guntur chilli, Pepper drops..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                  className="w-full bg-[#101713] text-white placeholder-stone-400 pl-10 pr-4 py-2.5 text-xs rounded-full border border-[#D4A84F]/40 focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-full hover:brightness-105"
              >
                Search
              </button>
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="px-3 py-2 text-stone-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0C120F] text-white border-b border-[#D4A84F]/30 px-6 py-6 space-y-4 shadow-2xl">
          <div className="space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between text-sm uppercase tracking-wider font-semibold py-2 border-b border-white/5 hover:text-[#D4A84F]"
              >
                <span className="flex items-center gap-2">
                  {link.icon && <link.icon className="w-4 h-4 text-[#D4A84F]" />}
                  {link.name}
                </span>
                {link.badge && (
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${link.badgeClass}`}>
                    {link.badge}
                  </span>
                )}
              </Link>
            ))}
            <Link
              href="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-sm uppercase tracking-wider font-bold py-2 text-[#D4A84F] border-b border-white/5"
            >
              Admin Operations Portal
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
