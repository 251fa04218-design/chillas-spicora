"use client";

import React, { useState, Suspense } from "react";
import Image from "next/image";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  User,
  Package,
  Heart,
  MapPin,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Trash2,
  ShoppingBag,
  ExternalLink,
  LogOut,
  LogIn
} from "lucide-react";
import { useSpicora } from "@/context/SpicoraContext";
import { useWishlist } from "@/context/WishlistContext";
import { useCart } from "@/context/CartContext";
import { formatINR } from "@/lib/utils";

function AccountContent() {
  const searchParams = useSearchParams();
  const initialTab = (searchParams.get("tab") as any) || "orders";

  const { user, loginUser, logoutUser, orders } = useSpicora();
  const { wishlistIds, toggleWishlist } = useWishlist();
  const { products } = useSpicora();
  const { addItem } = useCart();

  const [activeTab, setActiveTab] = useState<"orders" | "wishlist" | "profile" | "addresses">(initialTab);
  const [emailInput, setEmailInput] = useState("");
  const [nameInput, setNameInput] = useState("");

  const wishlistProducts = products.filter((p) => wishlistIds.includes(p.id));

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput) {
      loginUser(emailInput, nameInput || "Spice Connoisseur");
      setEmailInput("");
      setNameInput("");
    }
  };

  return (
    <div className="bg-[#FCFBF7] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Account Header */}
        <div className="bg-gradient-to-r from-[#174D35] to-[#0f3424] rounded-3xl p-8 sm:p-10 text-white border border-[#D4A84F]/40 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-16 h-16 rounded-full bg-[#D4A84F] text-[#174D35] flex items-center justify-center font-serif font-black text-2xl shadow-lg border-2 border-white">
              {user?.name?.charAt(0) || "S"}
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#D4A84F]">
                CUSTOMER CONNOISSEUR PORTAL
              </span>
              <h1 className="font-serif text-2xl sm:text-3xl font-extrabold text-white">
                {user ? user.name : "Welcome, Guest Connoisseur"}
              </h1>
              <p className="text-xs text-stone-300">
                {user ? user.email : "Sign in to track spice orders, view dispatch timelines, and manage wishlist"}
              </p>
            </div>
          </div>

          {user ? (
            <button
              onClick={logoutUser}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl border border-white/20 flex items-center gap-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5 text-[#D4A84F]" />
              Sign Out
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <input
                type="email"
                placeholder="Enter email to sign in"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                className="bg-[#0f3424] text-white text-xs px-3 py-2 rounded-xl border border-[#D4A84F]/40 focus:outline-none"
              />
              <button
                onClick={handleLogin}
                className="px-4 py-2 bg-[#D4A84F] text-[#174D35] text-xs font-bold rounded-xl hover:bg-[#F3DC9B] transition-colors"
              >
                Sign In
              </button>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-stone-200 overflow-x-auto no-scrollbar">
          {[
            { id: "orders", label: `My Orders (${orders.length})`, icon: Package },
            { id: "wishlist", label: `Wishlist (${wishlistProducts.length})`, icon: Heart },
            { id: "addresses", label: "Saved Addresses", icon: MapPin },
            { id: "profile", label: "Profile Settings", icon: User },
          ].map((tab) => {
            const Icon = tab.icon;
            const isCurrent = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                  isCurrent
                    ? "bg-[#174D35] text-white shadow-sm"
                    : "text-stone-600 hover:text-[#174D35] hover:bg-stone-100"
                }`}
              >
                <Icon className={`w-4 h-4 ${isCurrent ? "text-[#D4A84F]" : "text-stone-400"}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab 1: Orders */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            {orders.length === 0 ? (
              <div className="bg-white rounded-3xl p-16 text-center border border-[#D4A84F]/30 space-y-4">
                <Package className="w-12 h-12 text-stone-300 mx-auto" />
                <h3 className="font-serif text-xl font-bold text-[#174D35]">No orders placed yet</h3>
                <p className="text-xs text-stone-500">Discover our signature spice collections and place a demo order today!</p>
                <Link
                  href="/shop"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#174D35] text-white font-bold text-xs uppercase tracking-wider"
                >
                  Shop Spices Now
                </Link>
              </div>
            ) : (
              orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-6"
                >
                  {/* Order Top Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-serif font-bold text-base text-[#174D35]">
                          Order #{order.orderNumber}
                        </span>
                        <span className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-200">
                          {order.orderStatus}
                        </span>
                      </div>
                      <span className="text-[11px] text-stone-400">
                        Placed on {new Date(order.createdAt).toLocaleDateString("en-IN", { dateStyle: "long" })}
                      </span>
                    </div>

                    <div className="text-left sm:text-right">
                      <span className="text-xs text-stone-500 block">Total Amount:</span>
                      <span className="font-serif font-black text-lg text-[#174D35]">
                        {formatINR(order.total)}
                      </span>
                    </div>
                  </div>

                  {/* Order Tracking Progress Pipeline */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 flex items-center justify-between">
                      <span>Delivery Pipeline</span>
                      {order.trackingNumber && (
                        <span className="text-[10px] font-mono text-[#174D35]">
                          Tracking: {order.trackingNumber} (Delhivery Express)
                        </span>
                      )}
                    </span>

                    <div className="grid grid-cols-4 gap-2 pt-2 text-center text-[11px]">
                      {["Placed", "Processing", "Shipped", "Delivered"].map((st, i) => {
                        const statusMap: Record<string, number> = {
                          Placed: 0,
                          Processing: 1,
                          Shipped: 2,
                          "Out for Delivery": 2,
                          Delivered: 3,
                        };
                        const currentRank = statusMap[order.orderStatus] || 0;
                        const isDone = i <= currentRank;
                        return (
                          <div key={st} className="space-y-1">
                            <div
                              className={`h-2 rounded-full transition-all ${
                                isDone ? "bg-emerald-600" : "bg-stone-200"
                              }`}
                            />
                            <span className={isDone ? "font-bold text-stone-900" : "text-stone-400"}>
                              {st}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="divide-y divide-stone-100 border-t border-stone-100 pt-3 space-y-2">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="pt-2 first:pt-0 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3">
                          <div className="relative w-10 h-10 rounded-lg overflow-hidden bg-stone-100 flex-shrink-0">
                            <Image src={item.product.images[0]} alt={item.product.name} fill className="object-cover" />
                          </div>
                          <div>
                            <span className="font-bold text-stone-900">{item.product.name}</span>
                            <span className="block text-[11px] text-stone-500">{item.variant.size} × {item.quantity}</span>
                          </div>
                        </div>
                        <span className="font-bold text-[#174D35]">
                          {formatINR(item.variant.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 2: Wishlist */}
        {activeTab === "wishlist" && (
          <div className="space-y-6">
            {wishlistProducts.length === 0 ? (
              <div className="bg-white rounded-3xl p-16 text-center border border-[#D4A84F]/30 space-y-4">
                <Heart className="w-12 h-12 text-stone-300 mx-auto" />
                <h3 className="font-serif text-xl font-bold text-[#174D35]">Your Wishlist is Empty</h3>
                <p className="text-xs text-stone-500">Save your favourite whole spices and liquid drops here for future cooking sessions.</p>
                <Link
                  href="/shop"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#174D35] text-white font-bold text-xs uppercase tracking-wider"
                >
                  Discover Spices
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {wishlistProducts.map((prod) => (
                  <div
                    key={prod.id}
                    className="bg-white rounded-2xl p-4 border border-[#D4A84F]/25 shadow-sm space-y-3 flex flex-col justify-between"
                  >
                    <div className="relative aspect-video rounded-xl overflow-hidden bg-stone-100">
                      <Image src={prod.images[0]} alt={prod.name} fill className="object-cover" />
                      <button
                        onClick={() => toggleWishlist(prod)}
                        className="absolute top-2 right-2 p-1.5 rounded-full bg-white text-red-500 shadow"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-bold text-[#27885b]">{prod.categoryName}</span>
                      <h4 className="font-serif font-bold text-sm text-[#174D35] line-clamp-1">{prod.name}</h4>
                      <p className="text-xs font-serif font-bold text-[#D4A84F] mt-1">{formatINR(prod.variants[0].price)}</p>
                    </div>

                    <button
                      onClick={() => addItem(prod, prod.variants[0], 1)}
                      className="w-full py-2 bg-[#174D35] text-white text-xs font-bold rounded-xl hover:bg-[#13422E] flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      Move to Cart
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Saved Addresses */}
        {activeTab === "addresses" && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4">
            <h2 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
              Delivery Addresses
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {user?.addresses.map((addr, idx) => (
                <div key={idx} className="p-4 rounded-2xl border border-stone-200 bg-stone-50 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <strong className="font-bold text-stone-900">{addr.fullName}</strong>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded">
                      Default Shipping
                    </span>
                  </div>
                  <p className="text-stone-600 leading-relaxed">
                    {addr.addressLine1}, {addr.addressLine2 && `${addr.addressLine2}, `}
                    {addr.city}, {addr.state} - {addr.pincode}
                  </p>
                  <p className="text-stone-500">Phone: {addr.phone}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Profile Settings */}
        {activeTab === "profile" && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4 max-w-xl">
            <h2 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
              Profile Details
            </h2>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-500 font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  disabled
                  value={user?.name || "Ramesh Chilla"}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 text-stone-800"
                />
              </div>
              <div>
                <label className="block text-stone-500 font-semibold mb-1">Email Address</label>
                <input
                  type="email"
                  disabled
                  value={user?.email || "ramesh.chilla@spicora.demo"}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 text-stone-800"
                />
              </div>
              <div>
                <label className="block text-stone-500 font-semibold mb-1">Contact Phone</label>
                <input
                  type="tel"
                  disabled
                  value={user?.phone || "+91 98480 12345"}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 text-stone-800"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AccountPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#FCFBF7] flex items-center justify-center">
          <div className="text-center space-y-3">
            <div className="w-10 h-10 border-4 border-[#174D35] border-t-[#D4A84F] rounded-full animate-spin mx-auto" />
            <p className="text-xs font-serif font-bold text-[#174D35] tracking-widest uppercase">
              Loading Customer Portal...
            </p>
          </div>
        </div>
      }
    >
      <AccountContent />
    </Suspense>
  );
}

