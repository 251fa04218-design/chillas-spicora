"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ShieldCheck,
  CreditCard,
  QrCode,
  Truck,
  CheckCircle2,
  Lock,
  ArrowRight,
  ShoppingBag,
  AlertCircle,
  Sparkles,
  Printer
} from "lucide-react";
import confetti from "canvas-confetti";
import { useCart } from "@/context/CartContext";
import { useSpicora } from "@/context/SpicoraContext";
import { formatINR } from "@/lib/utils";
import { OrderCustomer } from "@/types";

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, discount, shipping, total, appliedCoupon, clearCart } = useCart();
  const { addOrder, user, saveAddress } = useSpicora();

  // Customer & Shipping State
  const [formData, setFormData] = useState<OrderCustomer>({
    fullName: user?.addresses[0]?.fullName || user?.name || "Ramesh Chilla",
    email: user?.email || "ramesh.chilla@spicora.demo",
    phone: user?.phone || "+91 98480 12345",
    addressLine1: user?.addresses[0]?.addressLine1 || "Plot 42, Brodipet Main Road",
    addressLine2: user?.addresses[0]?.addressLine2 || "Near Spice Board Market",
    city: user?.addresses[0]?.city || "Guntur",
    state: user?.addresses[0]?.state || "Andhra Pradesh",
    pincode: user?.addresses[0]?.pincode || "522002",
  });

  const [paymentMethod, setPaymentMethod] = useState<"razorpay" | "upi" | "card" | "netbanking" | "cod">("razorpay");
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<any>(null);

  const indianStates = [
    "Andhra Pradesh",
    "Telangana",
    "Tamil Nadu",
    "Karnataka",
    "Kerala",
    "Maharashtra",
    "Delhi",
    "Gujarat",
    "Rajasthan",
    "West Bengal",
    "Uttar Pradesh",
    "Other Indian State",
  ];

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;

    setIsProcessing(true);

    // Simulate payment gateway interaction (Razorpay test mode)
    setTimeout(() => {
      const newOrder = addOrder({
        customer: formData,
        items: items,
        subtotal,
        discount,
        couponCode: appliedCoupon?.code,
        shipping,
        total,
        paymentMethod,
        paymentStatus: paymentMethod === "cod" ? "COD Confirmed" : "Test Mode Completed",
        orderStatus: "Processing",
        trackingNumber: `DEL-GNT-${Math.floor(100000 + Math.random() * 900000)}`,
        notes: "Demo test mode order placed through CHILLA'S SPICORA digital portal.",
      });

      // Save address to user profile
      saveAddress(formData);

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#174D35", "#D4A84F", "#FFF8E9", "#B3862D"],
        });
      } catch (err) {
        console.log("Confetti trigger:", err);
      }

      setCompletedOrder(newOrder);
      clearCart();
      setIsProcessing(false);
    }, 1500);
  };

  // Order Confirmation Success View
  if (completedOrder) {
    return (
      <div className="bg-[#FCFBF7] min-h-screen py-16 px-4">
        <div className="max-w-2xl mx-auto bg-white rounded-3xl p-8 sm:p-12 border border-[#D4A84F]/40 shadow-2xl space-y-6 text-center">
          <div className="w-20 h-20 rounded-full bg-emerald-100 text-[#174D35] flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-12 h-12 stroke-[2.2]" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#D4A84F]">
              NAMASKARAM & THANK YOU!
            </span>
            <h1 className="font-serif text-3xl font-extrabold text-[#174D35]">
              Spice Order Confirmed
            </h1>
            <p className="text-xs sm:text-sm text-[#5E6C65]">
              Your order has been recorded in our Guntur processing hub under test mode.
            </p>
          </div>

          <div className="bg-[#FFF8E9] p-5 rounded-2xl border border-[#D4A84F]/30 text-left space-y-3 text-xs">
            <div className="flex justify-between items-center border-b border-[#D4A84F]/20 pb-2">
              <span className="text-stone-500 font-medium">Order Reference:</span>
              <span className="font-mono font-bold text-sm text-[#174D35]">
                {completedOrder.orderNumber}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500 font-medium">Tracking Number:</span>
              <span className="font-mono font-semibold text-stone-900">
                {completedOrder.trackingNumber}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500 font-medium">Payment Mode:</span>
              <span className="font-semibold text-emerald-800 uppercase">
                {completedOrder.paymentMethod} (Test Mode)
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500 font-medium">Delivery Destination:</span>
              <span className="text-stone-900 text-right max-w-xs font-medium">
                {completedOrder.customer.addressLine1}, {completedOrder.customer.city}, {completedOrder.customer.state} - {completedOrder.customer.pincode}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-[#D4A84F]/20 text-sm font-bold text-[#174D35]">
              <span>Amount Paid:</span>
              <span>{formatINR(completedOrder.total)}</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Link
              href="/account"
              className="flex-1 py-3.5 px-6 rounded-xl bg-[#174D35] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#13422E] transition-colors"
            >
              Track in Customer Portal
            </Link>
            <button
              onClick={() => window.print()}
              className="flex-1 py-3.5 px-6 rounded-xl border border-[#174D35] text-[#174D35] font-bold text-xs uppercase tracking-wider hover:bg-[#174D35]/5 transition-colors flex items-center justify-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              Print Invoice
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-xl mx-auto py-20 px-4 text-center space-y-4">
        <h1 className="font-serif text-3xl font-bold text-[#174D35]">Cart is Empty</h1>
        <p className="text-xs text-stone-600">Please add products to your cart before proceeding to checkout.</p>
        <Link
          href="/shop"
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#174D35] text-white text-xs font-bold uppercase tracking-wider"
        >
          Explore Shop
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-[#FCFBF7] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="border-b border-stone-200 pb-4">
          <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#D4A84F]">
            SECURE ENCRYPTED CHECKOUT
          </span>
          <h1 className="font-serif text-2xl sm:text-3xl font-extrabold text-[#174D35]">
            Complete Your Spice Order
          </h1>
        </div>

        <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Delivery Address & Payment */}
          <div className="lg:col-span-7 space-y-6">
            {/* Contact Details */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4">
              <h2 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3 flex items-center gap-2">
                <span>1. Customer Information</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    placeholder="e.g. Ramesh Chilla"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Mobile Number (WhatsApp updates)</label>
                  <input
                    type="tel"
                    required
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="+91 98480 12345"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="ramesh@example.com"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>
              </div>
            </div>

            {/* Delivery Address */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4">
              <h2 className="font-serif font-bold text-lg text-[#174D35] border-b border-stone-100 pb-3">
                2. Shipping Destination (India)
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">House / Flat / Street Address</label>
                  <input
                    type="text"
                    required
                    name="addressLine1"
                    value={formData.addressLine1}
                    onChange={handleInputChange}
                    placeholder="Plot 42, Heritage Enclave, Brodipet"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">Landmark / Area (Optional)</label>
                  <input
                    type="text"
                    name="addressLine2"
                    value={formData.addressLine2}
                    onChange={handleInputChange}
                    placeholder="Opposite Spice Board Market"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">City / Town</label>
                  <input
                    type="text"
                    required
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    placeholder="Guntur"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">State</label>
                  <select
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  >
                    {indianStates.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">PIN Code</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    name="pincode"
                    value={formData.pincode}
                    onChange={handleInputChange}
                    placeholder="522002"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#174D35]"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <h2 className="font-serif font-bold text-lg text-[#174D35]">
                  3. Payment Method
                </h2>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Razorpay Sandbox Enabled
                </span>
              </div>

              <div className="space-y-2.5">
                {[
                  {
                    id: "razorpay",
                    name: "Razorpay (All-In-One Test Mode)",
                    desc: "Supports UPI, Cards, NetBanking with instant simulated authorization",
                    badge: "Recommended",
                  },
                  {
                    id: "upi",
                    name: "UPI (Google Pay / PhonePe / Paytm / BHIM)",
                    desc: "Instant dynamic QR code scan or VPA",
                  },
                  {
                    id: "card",
                    name: "Credit / Debit Cards",
                    desc: "Visa, Mastercard, RuPay, Amex via 256-bit secure gateway",
                  },
                  {
                    id: "cod",
                    name: "Cash on Delivery (COD)",
                    desc: "Pay in cash upon doorstep delivery in India",
                  },
                ].map((opt) => (
                  <label
                    key={opt.id}
                    className={`flex items-start gap-3 p-3.5 rounded-2xl border cursor-pointer transition-all ${
                      paymentMethod === opt.id
                        ? "border-[#174D35] bg-[#174D35]/5 shadow-sm"
                        : "border-stone-200 hover:border-stone-300"
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value={opt.id}
                      checked={paymentMethod === opt.id}
                      onChange={() => setPaymentMethod(opt.id as any)}
                      className="mt-1 accent-[#174D35]"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-stone-900">{opt.name}</span>
                        {opt.badge && (
                          <span className="text-[10px] bg-[#D4A84F] text-[#174D35] font-extrabold px-1.5 py-0.2 rounded">
                            {opt.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">{opt.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Order Summary & Place Button */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-4">
              <h2 className="font-serif font-bold text-base text-[#174D35] border-b border-stone-100 pb-3">
                Order Review ({items.length} items)
              </h2>

              {/* Items List */}
              <div className="divide-y divide-stone-100 max-h-72 overflow-y-auto pr-1 space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="pt-3 first:pt-0 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-3">
                      <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-stone-100 flex-shrink-0">
                        <Image src={item.product.images[0]} alt={item.product.name} fill className="object-cover" />
                      </div>
                      <div>
                        <div className="font-bold text-stone-900 line-clamp-1">{item.product.name}</div>
                        <div className="text-[11px] text-stone-500">{item.variant.size} × {item.quantity}</div>
                      </div>
                    </div>
                    <div className="font-bold text-[#174D35] text-right">
                      {formatINR(item.variant.price * item.quantity)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Price Calculation */}
              <div className="pt-4 border-t border-stone-100 space-y-2 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-stone-900">{formatINR(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Discount ({appliedCoupon?.code})</span>
                    <span>-{formatINR(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? <strong className="text-emerald-700">FREE</strong> : formatINR(shipping)}</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-stone-200 text-lg font-serif font-black text-[#174D35]">
                  <span>Total Payable</span>
                  <span>{formatINR(total)}</span>
                </div>
              </div>

              {/* Place Order CTA Button */}
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 shadow-xl flex items-center justify-center gap-2 transition-all disabled:opacity-75"
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
                    Simulating Secure Gateway...
                  </span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    Authorize & Place Order ({formatINR(total)})
                  </>
                )}
              </button>

              <div className="text-[10px] text-stone-400 text-center space-y-1 pt-1">
                <p>🔒 256-Bit SSL Encrypted • RBI-compliant sandbox payment processing</p>
                <p>*Demo order test mode. No real bank debits occur.</p>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
