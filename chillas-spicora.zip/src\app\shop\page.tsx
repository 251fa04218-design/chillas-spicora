"use client";

import React, { useState, useMemo, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import {
  Search,
  SlidersHorizontal,
  X,
  Sparkles,
  Filter,
  Check,
  RefreshCw
} from "lucide-react";
import { useSpicora } from "@/context/SpicoraContext";
import { ProductCard } from "@/components/products/ProductCard";
import { CATEGORIES } from "@/data/categories";
import { ProductStatus } from "@/types";

function ShopContent() {
  const { products } = useSpicora();
  const searchParams = useSearchParams();

  // URL query params initialization
  const initialCategory = searchParams.get("category") || "all";
  const initialSearch = searchParams.get("q") || "";
  const initialStatus = searchParams.get("status") || "all";

  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedStatus, setSelectedStatus] = useState<string>(initialStatus);
  const [searchQuery, setSearchQuery] = useState<string>(initialSearch);
  const [sortBy, setSortBy] = useState<string>("featured");
  const [priceRange, setPriceRange] = useState<string>("all");
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  useEffect(() => {
    const cat = searchParams.get("category");
    if (cat) setSelectedCategory(cat);
    const q = searchParams.get("q");
    if (q) setSearchQuery(q);
    const stat = searchParams.get("status");
    if (stat) setSelectedStatus(stat);
  }, [searchParams]);

  // Filter & Sort Logic
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Category filter
      if (selectedCategory !== "all") {
        if (selectedCategory === "signature-liquid-flavours" && product.categoryId !== "liquid-flavours") return false;
        if (selectedCategory === "traditional-masala-powders" && product.categoryId !== "masala-powders") return false;
        if (selectedCategory === "special-spice-blends" && product.categoryId !== "special-blends") return false;
        if (selectedCategory === "whole-spices" && product.categoryId !== "whole-spices") return false;
        if (selectedCategory === "combo-packs" && product.categoryId !== "combo-packs") return false;
      }

      // Status filter
      if (selectedStatus !== "all" && product.status !== selectedStatus) {
        return false;
      }

      // Price filter
      const minPrice = product.variants[0]?.price || 0;
      if (priceRange === "under-150" && minPrice > 150) return false;
      if (priceRange === "150-300" && (minPrice < 150 || minPrice > 300)) return false;
      if (priceRange === "300-600" && (minPrice < 300 || minPrice > 600)) return false;
      if (priceRange === "above-600" && minPrice < 600) return false;

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesDesc = product.shortDescription.toLowerCase().includes(query);
        const matchesOrigin = product.origin.toLowerCase().includes(query);
        const matchesFlavour = product.flavourNotes.some((fn) => fn.toLowerCase().includes(query));
        const matchesIngredient = product.ingredients.some((ing) => ing.toLowerCase().includes(query));
        if (!matchesName && !matchesDesc && !matchesOrigin && !matchesFlavour && !matchesIngredient) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === "price-low") {
        return a.variants[0].price - b.variants[0].price;
      }
      if (sortBy === "price-high") {
        return b.variants[0].price - a.variants[0].price;
      }
      if (sortBy === "rating") {
        return b.rating - a.rating;
      }
      if (sortBy === "name-asc") {
        return a.name.localeCompare(b.name);
      }
      // default: featured
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [products, selectedCategory, selectedStatus, priceRange, searchQuery, sortBy]);

  const handleResetFilters = () => {
    setSelectedCategory("all");
    setSelectedStatus("all");
    setSearchQuery("");
    setPriceRange("all");
    setSortBy("featured");
  };

  const hasActiveFilters =
    selectedCategory !== "all" ||
    selectedStatus !== "all" ||
    searchQuery !== "" ||
    priceRange !== "all" ||
    sortBy !== "featured";

  return (
    <div className="bg-[#080C0A] text-[#F3F4F1] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header Breadcrumbs & Banner */}
        <div className="bg-gradient-to-r from-[#174D35] to-[#0f3424] rounded-3xl p-8 sm:p-10 text-white border border-[#D4A84F]/40 shadow-xl space-y-3 relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-spice-pattern opacity-20 pointer-events-none" />
          <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#D4A84F] block">
            GUNTUR HERITAGE CATALOGUE
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-extrabold text-white">
            The Complete Spice Vault
          </h1>
          <p className="text-sm text-stone-200 max-w-2xl font-light leading-relaxed">
            Browse our full 48-item artisanal catalog: ultrasonic cold-extracted liquid drops, stone-ground generational masalas, hand-sorted Grade-A whole botanicals, and royal festive gift boxes.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-[#101713] p-4 sm:p-6 rounded-3xl border border-[#D4A84F]/30 shadow-md space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Realtime Search Input */}
            <div className="relative w-full md:w-96">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by spice name, aroma note, ingredient..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-full pl-10 pr-4 py-2.5 text-xs text-white placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Sort & Mobile Filter Toggle */}
            <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-400 font-medium hidden sm:inline">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-black/40 border border-white/10 text-white text-xs font-semibold rounded-xl px-3 py-2.5 focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
                >
                  <option value="featured">Featured & Curated</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Customer Rating</option>
                  <option value="name-asc">Name: A to Z</option>
                </select>
              </div>

              <button
                onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
                className="md:hidden flex items-center gap-1.5 px-3.5 py-2.5 bg-[#174D35] text-white text-xs font-bold rounded-xl"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                Filters
              </button>
            </div>
          </div>

          {/* Quick Category Tabs Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 no-scrollbar">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === "all"
                  ? "bg-[#D4A84F] text-stone-950 shadow-md"
                  : "bg-white/5 text-stone-300 border border-white/10 hover:border-[#D4A84F]"
              }`}
            >
              All Products ({products.length})
            </button>
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.slug;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.slug)}
                  className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    isSelected
                      ? "bg-[#D4A84F] text-stone-950 shadow-md font-bold"
                      : "bg-white/5 text-stone-300 border border-white/10 hover:border-[#D4A84F]"
                  }`}
                >
                  {cat.shortName} ({cat.itemCount})
                </button>
              );
            })}
          </div>

          {/* Secondary Sub-Filters (Price & Availability Status) */}
          <div className={`pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 ${mobileFilterOpen ? "block" : "hidden md:flex"}`}>
            {/* Status Filter */}
            <div className="flex items-center gap-2 text-xs">
              <span className="font-medium text-stone-400">Status:</span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: "all", label: "All Statuses" },
                  { id: "Active", label: "Orderable (Demo)" },
                  { id: "Development", label: "In Development" },
                  { id: "Coming Soon", label: "Coming Soon" }
                ].map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStatus(st.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-colors ${
                      selectedStatus === st.id
                        ? "bg-[#D4A84F] text-stone-950 border-[#D4A84F] font-bold"
                        : "bg-black/30 text-stone-300 border-white/10 hover:border-[#D4A84F]"
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Filter */}
            <div className="flex items-center gap-2 text-xs">
              <span className="font-medium text-stone-400">Price:</span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: "all", label: "All Prices" },
                  { id: "under-150", label: "Under ₹150" },
                  { id: "150-300", label: "₹150 - ₹300" },
                  { id: "300-600", label: "₹300 - ₹600" },
                  { id: "above-600", label: "₹600+" }
                ].map((pr) => (
                  <button
                    key={pr.id}
                    onClick={() => setPriceRange(pr.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-colors ${
                      priceRange === pr.id
                        ? "bg-[#D4A84F] text-stone-950 border-[#D4A84F] font-bold"
                        : "bg-black/30 text-stone-300 border-white/10 hover:border-[#D4A84F]"
                    }`}
                  >
                    {pr.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Reset Filters */}
            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="text-xs text-red-400 hover:text-red-300 font-semibold flex items-center gap-1 ml-auto"
              >
                <RefreshCw className="w-3 h-3" />
                Reset All Filters
              </button>
            )}
          </div>
        </div>

        {/* Results Count Bar */}
        <div className="flex items-center justify-between text-xs text-stone-400 px-1">
          <span>
            Showing <strong className="text-white font-bold">{filteredProducts.length}</strong> handcrafted spice formulations
          </span>
          <span className="text-[11px] italic text-[#D4A84F]">
            *All pack sizes configurable prior to commercial dispatch.
          </span>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-[#101713] rounded-3xl p-16 text-center border border-[#D4A84F]/30 space-y-4 shadow-xl">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto text-[#D4A84F]">
              <Search className="w-8 h-8 stroke-[1.5]" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-white">
              No spices matched your filters
            </h3>
            <p className="text-sm text-stone-400 max-w-md mx-auto">
              Try relaxing your search terms, changing the price range, or clearing the status filter.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function ShopPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#080C0A] flex items-center justify-center">
          <div className="text-center space-y-3">
            <div className="w-10 h-10 border-4 border-[#174D35] border-t-[#D4A84F] rounded-full animate-spin mx-auto" />
            <p className="text-xs font-serif font-bold text-[#D4A84F] tracking-widest uppercase">
              Loading Spice Vault...
            </p>
          </div>
        </div>
      }
    >
      <ShopContent />
    </Suspense>
  );
}
