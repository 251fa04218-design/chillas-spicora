"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ShieldCheck,
  Award,
  Sparkles,
  MapPin,
  Heart,
  Globe2,
  Leaf,
  CheckCircle2,
  ArrowRight
} from "lucide-react";
import { Logo } from "@/components/ui/Logo";

export default function AboutPage() {
  return (
    <div className="bg-[#FCFBF7] min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Hero Section */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#D4A84F] bg-[#174D35] px-4 py-1.5 rounded-full inline-block">
            HERITAGE OF GUNTUR, ANDHRA PRADESH
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-extrabold text-[#174D35] leading-tight">
            The Story Behind CHILLA&apos;S SPICORA
          </h1>
          <p className="text-sm sm:text-base text-[#5E6C65] font-light leading-relaxed">
            Founded with an unwavering vision: to elevate India&apos;s sacred spice tradition into an internationally revered culinary art form through pure terroir and breakthrough extraction science.
          </p>
        </div>

        {/* Brand Banner Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-white rounded-3xl p-8 sm:p-12 border border-[#D4A84F]/30 shadow-md">
          <div className="lg:col-span-6 space-y-5">
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#174D35]">
              Born Where Spices Have Defined Empires for Centuries
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-light">
              Guntur in Andhra Pradesh is not simply a spice market—it is the beating heart of the global spice trade. Home to Asia&apos;s largest chilli market yard, the river plains of the Krishna and Godavari cultivate soil enriched with volcanic minerals and river silt, yielding chillies with unrivaled natural color, deep essential oils, and intense floral warmth.
            </p>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-light">
              For generations, the Chilla family lived surrounded by this harvest rhythm. Witnessing the modern market flooded with adulterated powders mixed with sawdust, low-grade spent oils, and artificial red food dyes, <strong>CHILLA&apos;S SPICORA</strong> was born out of a determination to restore absolute integrity to the Indian spice pantry.
            </p>

            <div className="pt-2 flex items-center gap-6 border-t border-stone-100 text-xs">
              <div>
                <span className="font-serif font-bold text-xl text-[#174D35] block">Guntur, AP</span>
                <span className="text-stone-400">Headquarters & Labs</span>
              </div>
              <div className="w-px h-8 bg-stone-200" />
              <div>
                <span className="font-serif font-bold text-xl text-[#174D35] block">48 Formulations</span>
                <span className="text-stone-400">Artisanal Catalog</span>
              </div>
              <div className="w-px h-8 bg-stone-200" />
              <div>
                <span className="font-serif font-bold text-xl text-[#174D35] block">0% Fillers</span>
                <span className="text-stone-400">Pure Botanicals</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-xl border-2 border-[#D4A84F]/40">
              <Image
                src="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1000&q=80"
                alt="Stone grinding Indian spices"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>

        {/* Mission & Vision Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-[#174D35] text-white p-8 rounded-3xl border border-[#D4A84F]/40 shadow-lg space-y-4">
            <div className="w-12 h-12 rounded-full bg-[#D4A84F] text-[#174D35] flex items-center justify-center font-bold">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="font-serif font-bold text-xl text-[#D4A84F]">Our Mission</h3>
            <p className="text-xs sm:text-sm text-stone-200 font-light leading-relaxed">
              To deliver the true, unadulterated aroma and therapeutic volatile oils of Indian spices to domestic kitchens, top chefs, and artisanal tea houses with convenience and zero compromises.
            </p>
          </div>

          <div className="bg-[#0f3424] text-white p-8 rounded-3xl border border-[#D4A84F]/40 shadow-lg space-y-4">
            <div className="w-12 h-12 rounded-full bg-[#D4A84F] text-[#174D35] flex items-center justify-center font-bold">
              <Globe2 className="w-6 h-6" />
            </div>
            <h3 className="font-serif font-bold text-xl text-[#D4A84F]">Our Vision</h3>
            <p className="text-xs sm:text-sm text-stone-200 font-light leading-relaxed">
              To build CHILLA&apos;S SPICORA into a nationally recognized household name in India, expanding into specialized wholesale, HoReCa partnerships, and subsequently establishing high-grade export footprints in the UK, US, and Middle East.
            </p>
          </div>

          <div className="bg-[#174D35] text-white p-8 rounded-3xl border border-[#D4A84F]/40 shadow-lg space-y-4">
            <div className="w-12 h-12 rounded-full bg-[#D4A84F] text-[#174D35] flex items-center justify-center font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-serif font-bold text-xl text-[#D4A84F]">Our Values</h3>
            <p className="text-xs sm:text-sm text-stone-200 font-light leading-relaxed">
              Farm-to-fork traceability, farmer direct pricing, transparent food safety evaluation, and scientific innovation that respects and enhances ancient culinary wisdom.
            </p>
          </div>
        </div>

        {/* Quality Commitment & Food Safety Roadmap */}
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-[#D4A84F]/30 shadow-md space-y-6">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#27885b]">
              RIGOROUS FOOD SAFETY FRAMEWORK
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#174D35]">
              Product Development & Regulatory Validation Roadmap
            </h2>
          </div>

          <p className="text-xs sm:text-sm text-stone-600 font-light leading-relaxed">
            In compliance with responsible food manufacturing best practices, the 48 formulations in this catalog are presented transparently in their development and pilot batch phases. We do not invent arbitrary certification claims or speculative FSSAI license numbers.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <span className="font-bold text-xs text-[#174D35] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Phase 1: Pilot & Taste Panels
              </span>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Formulation optimization, culinary pairing verification, and shelf stability testing across 30ml/50ml liquid vials and 50g–500g pouch packs.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <span className="font-bold text-xs text-[#174D35] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Phase 2: Laboratory Certification
              </span>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Standardized testing for pesticide residues, aflatoxins, moisture content, and GC-MS volatile terpene profiling at accredited Indian food labs.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <span className="font-bold text-xs text-[#174D35] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Phase 3: Statutory FSSAI Rollout
              </span>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Issuance of formal FSSAI food business manufacturing licenses, verified nutritional panel stamping, and barcode registration prior to national commercial retail dispatch.
              </p>
            </div>
          </div>

          <div className="pt-4 text-center">
            <Link
              href="/shop"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#174D35] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#13422E] shadow-md transition-colors"
            >
              Explore the Spice Portfolio
              <ArrowRight className="w-4 h-4 text-[#D4A84F]" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
