"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ShieldCheck,
  Tag,
  ArrowLeft,
  Sparkles
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatINR } from "@/lib/utils";

export default function CartPage() {
  const {
    items,
    removeItem,
    updateQuantity,
    subtotal,
    discount,
    shipping,
    total,
    appliedCoupon,
    couponError,
    applyCoupon,
    removeCoupon,
  } = useCart();

  const [couponCode, setCouponCode] = useState("");

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim()) {
      const ok = applyCoupon(couponCode);
      if (ok) setCouponCode("");
    }
  };

  const freeShippingThreshold = 499;
  const remaining = Math.max(0, freeShippingThreshold - subtotal);
  const progress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  if (items.length === 0) {
    return (
      <div className="bg-[#FCFBF7] min-h-[70vh] flex items-center justify-center py-20 px-4">
        <div className="max-w-md w-full bg-white rounded-3xl p-10 text-center border border-[#D4A84F]/30 shadow-md space-y-5">
          <div className="w-20 h-20 rounded-full bg-[#174D35]/10 flex items-center justify-center mx-auto text-[#174D35]">
            <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#174D35]">
            Your Spice Cart is Empty
          </h1>
          <p className="text-xs sm:text-sm text-[#5E6C65] font-light leading-relaxed">
            Your culinary journey begins with pure aroma. Explore our single-origin Guntur chillies, liquid chai masala drops, and stone-ground heritage blends.
          </p>
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#174D35] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#13422E] shadow-md transition-all"
          >
            Explore Spice Catalog
            <ArrowRight className="w-4 h-4 text-[#D4A84F]" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#FCFBF7] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex items-center justify-between border-b border-stone-200 pb-4">
          <h1 className="font-serif text-2xl sm:text-3xl font-extrabold text-[#174D35]">
            Shopping Cart ({items.reduce((acc, i) => acc + i.quantity, 0)} items)
          </h1>
          <Link
            href="/shop"
            className="text-xs font-bold text-[#174D35] hover:text-[#D4A84F] flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Continue Shopping
          </Link>
        </div>

        {/* Free Shipping Alert Bar */}
        <div className="bg-[#174D35] text-white p-4 rounded-2xl border border-[#D4A84F]/30 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs">
            {remaining > 0 ? (
              <span>
                Add <strong className="text-[#D4A84F]">{formatINR(remaining)}</strong> more to unlock <strong className="text-emerald-300">FREE Shipping</strong> across India!
              </span>
            ) : (
              <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4A84F]" />
                You unlocked FREE shipping across India!
              </span>
            )}
            <span className="font-mono text-[11px] text-stone-300">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-[#D4A84F] to-emerald-400 h-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* 2 Columns: Items List & Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Items Table */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-8 border border-[#D4A84F]/30 shadow-md space-y-6">
            <div className="divide-y divide-stone-100 space-y-4">
              {items.map((item) => (
                <div key={item.id} className="pt-4 first:pt-0 flex flex-col sm:flex-row gap-4 items-center justify-between">
                  <div className="flex items-center gap-4 w-full sm:w-auto">
                    <div className="relative w-20 h-20 rounded-2xl overflow-hidden bg-stone-100 flex-shrink-0 border border-stone-200">
                      <Image
                        src={item.product.images[0]}
                        alt={item.product.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <Link
                        href={`/shop/${item.product.slug}`}
                        className="font-serif font-bold text-base text-[#174D35] hover:text-[#D4A84F] transition-colors line-clamp-1"
                      >
                        {item.product.name}
                      </Link>
                      <p className="text-xs text-[#5E6C65] font-medium mt-0.5">
                        Pack Size: <span className="text-stone-900 font-semibold">{item.variant.size}</span>
                      </p>
                      <span className="text-[10px] text-stone-400 font-mono">SKU: {item.variant.sku}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-none border-stone-100">
                    {/* Stepper */}
                    <div className="flex items-center border border-stone-200 rounded-xl bg-stone-50 overflow-hidden">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1.5 hover:bg-stone-200 text-stone-700"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs font-bold text-stone-800">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1.5 hover:bg-stone-200 text-stone-700"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Price */}
                    <div className="text-right min-w-[80px]">
                      <div className="font-serif font-bold text-base text-[#174D35]">
                        {formatINR(item.variant.price * item.quantity)}
                      </div>
                      <div className="text-[10px] text-stone-400">
                        {formatINR(item.variant.price)} each
                      </div>
                    </div>

                    {/* Delete */}
                    <button
                      onClick={() => removeItem(item.id)}
                      className="p-2 text-stone-400 hover:text-red-600 transition-colors"
                      title="Remove product"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Summary & Coupon Box */}
          <div className="lg:col-span-4 space-y-6">
            {/* Promo Code Card */}
            <div className="bg-white rounded-3xl p-6 border border-[#D4A84F]/30 shadow-md space-y-3">
              <h3 className="font-serif font-bold text-sm text-[#174D35] flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-[#D4A84F]" />
                Have a Promo Coupon?
              </h3>

              {appliedCoupon ? (
                <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-center justify-between text-xs text-emerald-800">
                  <div>
                    <strong className="block font-mono text-sm">{appliedCoupon.code}</strong>
                    <span className="text-[11px]">{appliedCoupon.description}</span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-red-600 hover:underline font-bold text-[11px]"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. SPICORA10"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-[#174D35] uppercase font-mono"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#174D35] text-white font-bold text-xs rounded-xl hover:bg-[#13422E] transition-colors"
                  >
                    Apply
                  </button>
                </form>
              )}

              {couponError && (
                <p className="text-[11px] text-red-600">{couponError}</p>
              )}

              <div className="pt-2 text-[11px] text-stone-500 space-y-1">
                <p>Popular demo codes:</p>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => applyCoupon("SPICORA10")}
                    className="bg-stone-100 hover:bg-stone-200 text-stone-700 font-mono px-2 py-0.5 rounded text-[10px]"
                  >
                    SPICORA10 (10% off &gt; ₹499)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyCoupon("GUNTURFIRST")}
                    className="bg-stone-100 hover:bg-stone-200 text-stone-700 font-mono px-2 py-0.5 rounded text-[10px]"
                  >
                    GUNTURFIRST (15% off &gt; ₹799)
                  </button>
                </div>
              </div>
            </div>

            {/* Calculations Card */}
            <div className="bg-white rounded-3xl p-6 border border-[#D4A84F]/30 shadow-md space-y-4">
              <h3 className="font-serif font-bold text-base text-[#174D35] border-b border-stone-100 pb-3">
                Order Summary
              </h3>

              <div className="space-y-2 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-stone-900">{formatINR(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount ({appliedCoupon?.code})</span>
                    <span className="font-semibold">-{formatINR(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Standard Shipping</span>
                  <span>{shipping === 0 ? <strong className="text-emerald-700">FREE</strong> : formatINR(shipping)}</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-stone-200 text-base font-serif font-extrabold text-[#174D35]">
                  <span>Total Amount</span>
                  <span>{formatINR(total)}</span>
                </div>
                <p className="text-[10px] text-stone-400 text-center pt-1">
                  *All taxes included. Demo order simulation mode.
                </p>
              </div>

              <Link
                href="/checkout"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 shadow-md flex items-center justify-center gap-2 transition-all"
              >
                Proceed to Secure Checkout
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
