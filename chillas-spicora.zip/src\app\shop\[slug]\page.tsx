"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  Star,
  ShoppingBag,
  Heart,
  ShieldCheck,
  Check,
  ArrowRight,
  Sparkles,
  MapPin,
  Clock,
  Plus,
  Minus,
  MessageSquare,
  ShieldAlert,
  Droplets,
  Gift,
  CheckCircle2
} from "lucide-react";
import { useSpicora } from "@/context/SpicoraContext";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { formatINR } from "@/lib/utils";
import { ProductVariant } from "@/types";
import { ProductCard } from "@/components/products/ProductCard";

export default function ProductDetailPage() {
  const { slug } = useParams();
  const router = useRouter();
  const { products, reviews, addReview } = useSpicora();
  const { addItem } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const product = products.find((p) => p.slug === slug);

  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(
    product?.variants[0] || null
  );
  const [selectedImage, setSelectedImage] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<"flavour" | "ingredients" | "safety" | "reviews">("flavour");
  const [addedAnimation, setAddedAnimation] = useState(false);

  // New review form state
  const [reviewAuthor, setReviewAuthor] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState("");
  const [reviewComment, setReviewComment] = useState("");
  const [reviewSuccess, setReviewSuccess] = useState(false);

  if (!product) {
    return (
      <div className="bg-[#080C0A] min-h-screen py-20 px-4 text-center space-y-4 text-white">
        <h1 className="font-serif text-3xl font-bold text-[#D4A84F]">Product Not Found</h1>
        <p className="text-stone-400">The spice formulation you are seeking could not be found.</p>
        <Link
          href="/shop"
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#174D35] text-white text-xs font-bold uppercase tracking-wider"
        >
          Return to Shop
        </Link>
      </div>
    );
  }

  const currentVariant = selectedVariant || product.variants[0];
  const isFavorited = isInWishlist(product.id);
  const productReviews = reviews.filter((r) => r.productId === product.id && r.status === "Approved");
  const relatedProducts = products
    .filter((p) => p.categoryId === product.categoryId && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addItem(product, currentVariant, quantity);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1500);
  };

  const handleBuyNow = () => {
    addItem(product, currentVariant, quantity);
    router.push("/checkout");
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewAuthor || !reviewComment) return;

    addReview({
      productId: product.id,
      author: reviewAuthor,
      rating: reviewRating,
      title: reviewTitle || "Artisanal Spice Review",
      comment: reviewComment,
      verifiedPurchase: true,
    });

    setReviewSuccess(true);
    setReviewAuthor("");
    setReviewTitle("");
    setReviewComment("");
    setTimeout(() => setReviewSuccess(false), 3000);
  };

  return (
    <div className="bg-[#080C0A] text-[#F3F4F1] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-xs text-stone-400">
          <Link href="/" className="hover:text-[#D4A84F]">Home</Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-[#D4A84F]">Shop</Link>
          <span>/</span>
          <Link href={`/shop?category=${product.categoryId}`} className="hover:text-[#D4A84F]">
            {product.categoryName}
          </Link>
          <span>/</span>
          <span className="text-[#D4A84F] font-semibold truncate">{product.name}</span>
        </nav>

        {/* Main Product Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 bg-[#101713] rounded-3xl p-6 sm:p-10 border border-[#D4A84F]/30 shadow-2xl">
          {/* Left: Image Gallery */}
          <div className="lg:col-span-6 space-y-4">
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-black/60 border border-white/10 glow-card-gold">
              <Image
                src={product.images[selectedImage] || product.images[0]}
                alt={product.name}
                fill
                priority
                className="object-cover"
              />
              <button
                onClick={() => toggleWishlist(product)}
                className={`absolute top-4 right-4 z-10 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isFavorited
                    ? "bg-red-600 text-white shadow-lg"
                    : "bg-black/50 text-stone-300 hover:text-red-400 border border-white/20"
                }`}
              >
                <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
              </button>

              <div className="absolute bottom-4 left-4">
                <span className="bg-[#174D35]/90 backdrop-blur-md text-[#D4A84F] text-xs font-bold px-3 py-1 rounded-md shadow-sm border border-[#D4A84F]/30">
                  {product.status === "Active" ? "✓ Pilot Orderable" : product.status}
                </span>
              </div>
            </div>

            {/* Thumbnail selector */}
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                      selectedImage === i ? "border-[#D4A84F] scale-95" : "border-white/10 hover:border-white/40"
                    }`}
                  >
                    <Image src={img} alt="Thumbnail" fill className="object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Product Info & Purchase Options */}
          <div className="lg:col-span-6 space-y-6 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4A84F]">
                  {product.categoryName}
                </span>
                <span className="text-xs text-stone-400 flex items-center gap-1 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-[#D4A84F]" />
                  {product.origin}
                </span>
              </div>

              <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white uppercase tracking-wide">
                {product.name}
              </h1>

              {product.tagline && (
                <p className="font-serif italic text-sm text-[#F4E6BE]/90 font-medium">
                  &ldquo;{product.tagline}&rdquo;
                </p>
              )}

              {/* Rating & Reviews */}
              <div className="flex items-center gap-2 pt-1">
                <div className="flex items-center text-[#D4A84F]">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating) ? "fill-current" : "text-stone-600"
                      }`}
                    />
                  ))}
                </div>
                <span className="font-bold text-xs text-white">{product.rating}</span>
                <span className="text-xs text-stone-400">
                  ({product.reviewCount} verified reviews)
                </span>
              </div>

              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed pt-2 font-light">
                {product.description}
              </p>

              {/* Flagship Liquid Callout */}
              {product.isLiquidFlagship && product.packagingType === "liquid" && (
                <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-[#174D35]/80 via-[#13422E]/80 to-[#0B2016]/80 border border-[#D4A84F]/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#D4A84F] flex items-center gap-1.5">
                      <Droplets className="w-4 h-4 fill-[#D4A84F]" />
                      OUR MAIN HERO INNOVATION: 2-DROP SPICE LIQUID
                    </span>
                    <span className="bg-[#D4A84F] text-stone-950 text-[10px] font-black px-2 py-0.5 rounded-full">
                      1 DROP = 1 SPOON
                    </span>
                  </div>
                  <p className="text-xs text-stone-200 leading-relaxed font-light">
                    Extracted in Guntur using low-temperature acoustic ultrasonic separation. Retains 100% active aromatic terpenes without bitterness. 600+ concentrated drops per 30ml bottle. Zero splattering in hot oil, zero gritty residue in tea or curries.
                  </p>
                </div>
              )}

              {/* Combo Pack Bundle Breakdown */}
              {product.bundleItems && product.bundleItems.length > 0 && (
                <div className="mt-4 p-4 rounded-2xl bg-[#E59E1B]/10 border border-[#E59E1B]/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#E59E1B] flex items-center gap-1.5">
                      <Gift className="w-4 h-4" />
                      CURATED COMBO OFFER ({product.bundleItems.length} ITEMS INCLUDED)
                    </span>
                    {product.savingsAmount && (
                      <span className="bg-[#C83E24] text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase">
                        Save ₹{product.savingsAmount} Instantly
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {product.bundleItems.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-stone-200 bg-black/40 p-2.5 rounded-xl border border-white/5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                  {product.offerDetails && (
                    <p className="text-[11px] text-amber-200/90 italic pt-1">
                      ✦ {product.offerDetails}
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Pack Size Variant Selector */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white">Select Packaging Size:</span>
                <span className="text-[11px] text-[#D4A84F] italic">Proposed options for commercial sale</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {product.variants.map((v) => {
                  const isSelected = currentVariant.id === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariant(v)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        isSelected
                          ? "bg-[#D4A84F] text-stone-950 border-[#D4A84F] shadow-md font-bold"
                          : "bg-black/40 text-stone-300 border-white/10 hover:border-[#D4A84F]/50"
                      }`}
                    >
                      <div className="text-xs font-bold leading-tight">{v.size}</div>
                      <div className={`text-xs mt-1 font-semibold ${isSelected ? "text-stone-950 font-black" : "text-[#D4A84F]"}`}>
                        {formatINR(v.price)}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price & Quantity Box */}
            <div className="pt-4 border-t border-white/10 space-y-4">
              <div className="flex items-baseline gap-3">
                <span className="font-serif font-black text-3xl text-white">
                  {formatINR(currentVariant.price * quantity)}
                </span>
                {currentVariant.compareAtPrice && (
                  <span className="text-sm text-stone-500 line-through">
                    {formatINR(currentVariant.compareAtPrice * quantity)}
                  </span>
                )}
                <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-2.5 py-0.5 rounded-full">
                  All Taxes Included
                </span>
              </div>

              {/* Quantity Stepper & Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <div className="flex items-center border border-white/20 rounded-xl bg-black/40 p-1 w-full sm:w-auto justify-between sm:justify-start">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 hover:bg-white/10 rounded-lg text-stone-300"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 text-sm font-bold text-white">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 hover:bg-white/10 rounded-lg text-stone-300"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className={`flex-1 w-full py-3.5 px-6 rounded-full font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md ${
                    addedAnimation
                      ? "bg-emerald-600 text-white"
                      : "bg-[#174D35] hover:bg-[#13422E] text-white border border-[#D4A84F]/40"
                  }`}
                >
                  {addedAnimation ? (
                    <>
                      <Check className="w-4 h-4" />
                      Added to Cart!
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4 text-[#D4A84F]" />
                      Add to Cart
                    </>
                  )}
                </button>

                <button
                  onClick={handleBuyNow}
                  className="flex-1 w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 font-bold text-xs uppercase tracking-wider hover:brightness-105 shadow-md flex items-center justify-center gap-2 transition-all"
                >
                  Buy Now
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Trust Pills */}
              <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] text-stone-400">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#D4A84F]" />
                  <span>Free Shipping on ₹499+</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[#D4A84F]" />
                  <span>Direct from Guntur, AP</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabbed Details (Flavour, Ingredients, Safety, Reviews) */}
        <div className="bg-[#101713] rounded-3xl p-6 sm:p-10 border border-[#D4A84F]/30 shadow-2xl space-y-6">
          <div className="flex items-center gap-4 border-b border-white/10 overflow-x-auto no-scrollbar">
            {[
              { id: "flavour", label: "Flavour Profile & Terroir" },
              { id: "ingredients", label: "Proposed Ingredients" },
              { id: "safety", label: "Storage & Compliance" },
              { id: "reviews", label: `Customer Reviews (${productReviews.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-2 text-xs sm:text-sm font-bold whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-[#D4A84F] text-[#D4A84F]"
                    : "border-transparent text-stone-400 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab 1: Flavour */}
          {activeTab === "flavour" && (
            <div className="space-y-4">
              <h3 className="font-serif font-bold text-lg text-white">
                Aroma & Volatile Terpene Characteristics
              </h3>
              <div className="flex flex-wrap gap-2">
                {product.flavourNotes.map((note, i) => (
                  <span
                    key={i}
                    className="bg-white/5 border border-[#D4A84F]/40 text-[#D4A84F] text-xs font-semibold px-3 py-1.5 rounded-full"
                  >
                    ✦ {note}
                  </span>
                ))}
              </div>
              {product.suggestedPairings && (
                <div className="pt-4 space-y-2">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-stone-300">
                    Recommended Culinary Pairings:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {product.suggestedPairings.map((pair, idx) => (
                      <span key={idx} className="bg-white/5 text-stone-200 border border-white/10 text-xs px-3 py-1 rounded-md">
                        {pair}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Ingredients */}
          {activeTab === "ingredients" && (
            <div className="space-y-4">
              <h3 className="font-serif font-bold text-lg text-white">
                Clean Label Proposed Ingredients
              </h3>
              <ul className="list-disc pl-5 text-xs sm:text-sm text-stone-300 space-y-1.5">
                {product.ingredients.map((ing, i) => (
                  <li key={i}>{ing}</li>
                ))}
              </ul>
              <div className="bg-amber-950/40 border border-amber-500/40 p-3.5 rounded-xl text-xs text-amber-200 flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Formulation Transparency:</strong> This ingredient declaration reflects our pilot recipe batch. Final statutory labelling including mandatory FSSAI food allergens and nutritional tables will be affirmed upon commercial batch registration.
                </span>
              </div>
            </div>
          )}

          {/* Tab 3: Safety */}
          {activeTab === "safety" && (
            <div className="space-y-4">
              <h3 className="font-serif font-bold text-lg text-white">
                Storage & Handling Instructions
              </h3>
              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-light">
                {product.storageInstructions}
              </p>
              <div className="bg-white/5 border border-white/10 p-4 rounded-xl space-y-2 text-xs text-stone-300">
                <strong className="block font-serif text-sm text-[#D4A84F]">Regulatory Statement:</strong>
                <p className="font-light leading-relaxed">
                  {product.complianceNotice}
                </p>
              </div>
            </div>
          )}

          {/* Tab 4: Reviews */}
          {activeTab === "reviews" && (
            <div className="space-y-8">
              <div className="space-y-4">
                {productReviews.length === 0 ? (
                  <p className="text-xs text-stone-400 italic">
                    Be the first to review this artisanal spice batch!
                  </p>
                ) : (
                  productReviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-white">{rev.author}</span>
                          {rev.verifiedPurchase && (
                            <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-semibold px-2 py-0.5 rounded">
                              Verified Purchase
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-stone-500">{rev.date}</span>
                      </div>
                      <div className="flex items-center text-[#D4A84F]">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${
                              i < rev.rating ? "fill-current" : "text-stone-700"
                            }`}
                          />
                        ))}
                      </div>
                      <h4 className="font-bold text-xs text-white">{rev.title}</h4>
                      <p className="text-xs text-stone-300 leading-relaxed font-light">{rev.comment}</p>
                    </div>
                  ))
                )}
              </div>

              {/* Submit Review Form */}
              <div className="pt-6 border-t border-white/10 space-y-4">
                <h3 className="font-serif font-bold text-base text-[#D4A84F]">
                  Leave a Connoisseur Review
                </h3>
                {reviewSuccess ? (
                  <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs rounded-xl flex items-center gap-2 font-medium">
                    <Check className="w-4 h-4 text-emerald-400" />
                    Thank you! Your tasting review has been recorded.
                  </div>
                ) : (
                  <form onSubmit={handleReviewSubmit} className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                          Your Name
                        </label>
                        <input
                          type="text"
                          required
                          value={reviewAuthor}
                          onChange={(e) => setReviewAuthor(e.target.value)}
                          placeholder="e.g. Radhika V."
                          className="w-full text-xs p-2.5 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                          Rating
                        </label>
                        <select
                          value={reviewRating}
                          onChange={(e) => setReviewRating(Number(e.target.value))}
                          className="w-full text-xs p-2.5 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
                        >
                          <option value={5}>5 Stars - Royal Excellence</option>
                          <option value={4}>4 Stars - Very Good</option>
                          <option value={3}>3 Stars - Average</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                        Review Title
                      </label>
                      <input
                        type="text"
                        value={reviewTitle}
                        onChange={(e) => setReviewTitle(e.target.value)}
                        placeholder="e.g. Unbelievable aroma in biryani"
                        className="w-full text-xs p-2.5 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                        Detailed Tasting Review
                      </label>
                      <textarea
                        required
                        rows={3}
                        value={reviewComment}
                        onChange={(e) => setReviewComment(e.target.value)}
                        placeholder="Share your culinary experience, flavor notes, and recipe results..."
                        className="w-full text-xs p-2.5 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:ring-1 focus:ring-[#D4A84F]"
                      />
                    </div>

                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-full bg-gradient-to-r from-[#D4A84F] to-[#B3862D] text-stone-950 text-xs font-bold uppercase tracking-wider"
                    >
                      Submit Review
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="space-y-6 pt-6">
            <h2 className="font-serif text-2xl font-bold text-white uppercase tracking-wider">
              Related Spice Creations
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
